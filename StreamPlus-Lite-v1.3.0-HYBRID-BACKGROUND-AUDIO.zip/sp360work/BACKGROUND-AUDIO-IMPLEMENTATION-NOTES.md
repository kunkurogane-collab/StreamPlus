StreamPlus Lite v1.3.0 - Background audio handoff

- Hybrid YouTube IFrame remains the foreground video player.
- The WebView reports the current playlist index, playback position, and play state to the Activity.
- When the Hybrid activity goes to background while a video is playing, it pauses the IFrame and sends the same YouTube URL queue to the existing Media3 PlaybackService in audio-only mode.
- PlaybackService resolves audio through the existing Engine/yt-dlp path and exposes its existing MediaSession notification/controls.
- When the app returns to foreground, the native background player is paused and the IFrame resumes near the last reported position.
- CMD_SET_QUEUE now accepts optional startPositionMs; existing callers default to zero.

Important: This is an implementation candidate, not a verified device result. YouTube availability, extraction, and background behavior depend on the video and service environment. Verify on a real device after a successful CI build.
