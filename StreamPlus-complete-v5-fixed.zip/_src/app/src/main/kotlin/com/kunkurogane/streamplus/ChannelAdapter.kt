package com.kunkurogane.streamplus

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.kunkurogane.streamplus.databinding.ItemChannelBinding

class ChannelAdapter(
    private val channels: List<StreamChannel>,
    private val onChannelClick: (StreamChannel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    private var selectedPosition: Int = RecyclerView.NO_POSITION

    inner class ChannelViewHolder(
        private val binding: ItemChannelBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(channel: StreamChannel, isSelected: Boolean) {
            binding.tvChannelName.text = channel.name
            binding.tvChannelCategory.text = channel.category
            binding.root.strokeColor = if (isSelected) 0xFF6366F1.toInt() else 0xFF252A38.toInt()
            binding.root.setCardBackgroundColor(
                if (isSelected) 0xFF1E2235.toInt() else 0xFF161922.toInt()
            )
            binding.root.setOnClickListener {
                val previous = selectedPosition
                selectedPosition = bindingAdapterPosition
                if (previous != RecyclerView.NO_POSITION) notifyItemChanged(previous)
                if (selectedPosition != RecyclerView.NO_POSITION) notifyItemChanged(selectedPosition)
                onChannelClick(channel)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val binding = ItemChannelBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ChannelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        holder.bind(channels[position], position == selectedPosition)
    }

    override fun getItemCount(): Int = channels.size
}
