package com.kunkurogane.streamplus

import android.net.Uri
import android.os.Bundle
import android.util.Patterns
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.kunkurogane.streamplus.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var player: ExoPlayer? = null
    private var currentStreamUrl: String? = null
    private var currentStreamTitle: String? = null

    private val defaultChannels = listOf(
        StreamChannel(
            name = "Big Buck Bunny (HLS 1080p)",
            category = "Animation • Mux Test Stream",
            streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
        ),
        StreamChannel(
            name = "Sintel Open Movie (HLS)",
            category = "Cinema • Bitmovin CDN",
            streamUrl = "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8"
        ),
        StreamChannel(
            name = "Tears of Steel (4K Adaptive)",
            category = "Sci-Fi • Unified Streaming",
            streamUrl = "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8"
        ),
        StreamChannel(
            name = "NASA Public Live Feed",
            category = "Science & Space • Live HLS",
            streamUrl = "https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        savedInstanceState?.let {
            currentStreamUrl = it.getString(KEY_STREAM_URL)
            currentStreamTitle = it.getString(KEY_STREAM_TITLE)
        }

        setupRecyclerView()
        setupCustomUrlInput()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_STREAM_URL, currentStreamUrl)
        outState.putString(KEY_STREAM_TITLE, currentStreamTitle)
    }

    private fun setupRecyclerView() {
        binding.rvChannels.layoutManager = LinearLayoutManager(this)
        binding.rvChannels.adapter = ChannelAdapter(defaultChannels) { channel ->
            binding.etStreamUrl.setText(channel.streamUrl)
            playStream(channel.streamUrl, channel.name)
        }
    }

    private fun setupCustomUrlInput() {
        binding.btnPlayUrl.setOnClickListener { triggerCustomPlay() }
        binding.etStreamUrl.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                triggerCustomPlay()
                true
            } else {
                false
            }
        }
    }

    private fun triggerCustomPlay() {
        val url = binding.etStreamUrl.text.toString().trim()
        if (url.isEmpty() || !Patterns.WEB_URL.matcher(url).matches()) {
            Toast.makeText(this, "Masukkan URL stream (http/https) yang valid", Toast.LENGTH_SHORT).show()
            return
        }
        playStream(url, "Custom Stream")
    }

    private fun initializePlayer() {
        if (player == null) {
            player = ExoPlayer.Builder(this).build().also { exo ->
                binding.playerView.player = exo
                exo.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        val title = currentStreamTitle ?: "Stream"
                        binding.tvNowPlaying.text = when (playbackState) {
                            Player.STATE_BUFFERING -> "Memuat: $title..."
                            Player.STATE_READY -> "Memutar: $title"
                            Player.STATE_ENDED -> "Selesai: $title"
                            else -> binding.tvNowPlaying.text
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        binding.tvNowPlaying.text = "Gagal memutar stream"
                        Toast.makeText(
                            this@MainActivity,
                            "Error stream: ${error.errorCodeName}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                })
            }
        }
        // Pulihkan stream terakhir jika aplikasi kembali dari latar belakang
        currentStreamUrl?.let { savedUrl ->
            if (player?.currentMediaItem == null) {
                playStream(savedUrl, currentStreamTitle ?: "Stream")
            }
        }
    }

    private fun playStream(url: String, title: String) {
        currentStreamUrl = url
        currentStreamTitle = title
        binding.tvNowPlaying.text = "Menghubungkan: $title"
        initializePlayer()

        val mediaItem = MediaItem.fromUri(Uri.parse(url))
        player?.apply {
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
        }
    }

    override fun onStart() {
        super.onStart()
        initializePlayer()
    }

    override fun onStop() {
        super.onStop()
        binding.playerView.player = null
        player?.release()
        player = null
    }

    companion object {
        private const val KEY_STREAM_URL = "stream_url"
        private const val KEY_STREAM_TITLE = "stream_title"
    }
}
