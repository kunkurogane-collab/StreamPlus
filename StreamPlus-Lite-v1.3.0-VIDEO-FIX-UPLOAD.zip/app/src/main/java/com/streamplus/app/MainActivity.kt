package com.streamplus.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

// Warna Sistem iOS / Apple Music
private val IosAccentRed = Color(0xFFFA233B)
private val IosLightBg = Color(0xFFF2F2F7)
private val IosDarkBg = Color(0xFF000000)
private val IosLightCard = Color(0xFFFFFFFF)
private val IosDarkCard = Color(0xFF1C1C1E)
private val IosLightSearchBg = Color(0xFFE3E3E8)
private val IosDarkSearchBg = Color(0xFF2C2C2E)
private val IosSecondaryLabel = Color(0xFF8E8E93)

private data class Now(
    val mediaId: String = "",
    val title: String = "",
    val artist: String = "",
    val art: String? = null,
    val playing: Boolean = false,
    val has: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1.0f,
    val currentIndex: Int = 0
)

private fun toggle(c: MediaController) {
    val st = c.playbackState
    if (c.playWhenReady && st != Player.STATE_IDLE && st != Player.STATE_ENDED) c.pause()
    else {
        if (st == Player.STATE_IDLE) c.prepare()
        if (st == Player.STATE_ENDED) c.seekToDefaultPosition()
        c.play()
    }
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

private fun fmtFreq(hz: Int): String =
    if (hz >= 1000) "${hz / 1000}kHz" else "${hz}Hz"

private fun fmtSizeMb(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb < 0.1) "0 MB" else String.format("%.1f MB", mb)
}

// Preset Equalizer Bergaya Apple Music (dalam millibel: 100 mB = 1 dB)
private val EqPresets: List<Pair<String, List<Int>>> = listOf(
    "Normal" to listOf(0, 0, 0, 0, 0),
    "Bass Booster" to listOf(900, 600, 0, 0, 0),
    "Pop" to listOf(-200, 300, 600, 300, -200),
    "Rock" to listOf(700, 300, -300, 400, 700),
    "Jazz" to listOf(500, 200, -200, 300, 500),
    "Akustik" to listOf(400, 300, 100, 300, 400),
    "Vokal" to listOf(-300, 100, 600, 400, -100),
    "Treble" to listOf(0, 0, 100, 500, 900)
)

// Penyimpanan Favorit Lokal
private object FavoritesStore {
    private const val PREF = "streamplus_favorites"
    private const val KEY = "items_json"

    fun load(ctx: Context): List<Track> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                val url = obj.optString("url")
                if (url.isBlank()) return@mapNotNull null
                Track(
                    url = url,
                    title = obj.optString("title"),
                    artist = obj.optString("artist"),
                    durationSec = obj.optLong("durationSec", 0L),
                    thumb = obj.optString("thumb").takeIf { it.isNotBlank() }
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(ctx: Context, list: List<Track>) {
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(JSONObject().apply {
                put("url", t.url)
                put("title", t.title)
                put("artist", t.artist)
                put("durationSec", t.durationSec)
                put("thumb", t.thumb.orEmpty())
            })
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}

private fun shareTrack(ctx: Context, url: String, title: String) {
    if (url.isBlank()) return
    val text = if (title.isNotBlank()) "$title\n$url" else url
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(intent, "Bagikan Tautan"))
}

private fun copyLink(ctx: Context, url: String) {
    if (url.isBlank()) return
    val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cb.setPrimaryClip(ClipData.newPlainText("StreamPlus URL", url))
    Toast.makeText(ctx, "Tautan disalin", Toast.LENGTH_SHORT).show()
}

@Composable
private fun rememberNow(c: MediaController?): Now {
    var now by remember { mutableStateOf(Now()) }
    DisposableEffect(c) {
        if (c == null) {
            onDispose { }
        } else {
            fun upd() {
                now = Now(
                    mediaId = c.currentMediaItem?.mediaId.orEmpty(),
                    title = c.mediaMetadata.title?.toString().orEmpty(),
                    artist = c.mediaMetadata.artist?.toString().orEmpty(),
                    art = c.mediaMetadata.artworkUri?.toString(),
                    playing = c.playWhenReady && c.playbackState != Player.STATE_IDLE && c.playbackState != Player.STATE_ENDED,
                    has = c.mediaItemCount > 0,
                    durationMs = c.duration.coerceAtLeast(0L),
                    shuffle = c.shuffleModeEnabled,
                    repeatMode = c.repeatMode,
                    speed = c.playbackParameters.speed,
                    currentIndex = c.currentMediaItemIndex
                )
            }
            val l = object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = upd()
            }
            c.addListener(l); upd()
            onDispose { c.removeListener(l) }
        }
    }
    return now
}

@Composable
private fun IosArtwork(url: String?, size: Dp, cornerRadius: Dp = 8.dp, showImage: Boolean = true) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFFA233B), Color(0xFFFB5C74))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.85f),
            modifier = Modifier.size(size * 0.48f)
        )
        if (showImage && !url.isNullOrBlank()) {
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun IosSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    isDark: Boolean
) {
    val searchBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val textColor = if (isDark) Color.White else Color.Black

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(searchBg)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = "Cari",
            tint = IosSecondaryLabel,
            modifier = Modifier
                .size(20.dp)
                .clickable { onSearch() }
        )
        Spacer(modifier = Modifier.width(6.dp))
        Box(modifier = Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text(
                    text = "Cari lagu, video, atau tempel link",
                    color = IosSecondaryLabel,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = TextStyle(
                    color = textColor,
                    fontSize = 15.sp
                ),
                cursorBrush = SolidColor(IosAccentRed),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.isNotEmpty()) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Rounded.Cancel,
                contentDescription = "Hapus",
                tint = IosSecondaryLabel,
                modifier = Modifier
                    .size(18.dp)
                    .clickable { onQueryChange("") }
            )
        }
    }
}

@Composable
private fun IosModeSegmentedControl(
    video: Boolean,
    onMode: (Boolean) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val items = listOf("Audio", "Video")
    val selectedIndex = if (video) 1 else 0
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / items.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "segment_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(7.dp))
                .clip(RoundedCornerShape(7.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            items.forEachIndexed { index, title ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onMode(index == 1) },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (index == 0) Icons.Rounded.Headphones else Icons.Rounded.SmartDisplay,
                            contentDescription = null,
                            tint = if (index == selectedIndex) IosAccentRed else IosSecondaryLabel,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Medium,
                            color = labelColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IosQualitySegmentedControl(
    selectedQuality: Int,
    onSelectQuality: (Int) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val options = listOf(360, 480, 720, 1080)
    val selectedIndex = options.indexOf(selectedQuality).coerceAtLeast(0)
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / options.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "quality_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            options.forEachIndexed { index, q ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectQuality(q) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${q}p",
                        fontSize = 12.sp,
                        fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (index == selectedIndex) IosAccentRed else labelColor
                    )
                }
            }
        }
    }
}

@Composable
private fun IosAudioQualitySegmentedControl(
    audioSaver: Boolean,
    onSelectAudioSaver: (Boolean) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val options = listOf("Hemat Kuota (~48k)", "Audio HD (~128k)")
    val selectedIndex = if (audioSaver) 0 else 1
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / options.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "audio_quality_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            options.forEachIndexed { index, label ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectAudioSaver(index == 0) },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (index == 0) {
                            Icon(
                                imageVector = Icons.Rounded.DataSaverOn,
                                contentDescription = null,
                                tint = if (selectedIndex == 0) IosAccentRed else IosSecondaryLabel,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (index == selectedIndex) IosAccentRed else labelColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IosAutoDownloadSegmentedControl(
    selectedMode: AutoDownloadMode,
    onSelectMode: (AutoDownloadMode) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val options = AutoDownloadMode.entries
    val selectedIndex = options.indexOf(selectedMode).coerceAtLeast(0)
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / options.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "autodl_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            options.forEachIndexed { index, item ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectMode(item) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = item.label,
                        fontSize = 11.sp,
                        fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (index == selectedIndex) IosAccentRed else labelColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun IosTextSegmentedControl(
    labels: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / labels.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex.coerceIn(0, labels.lastIndex),
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "text_seg_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            labels.forEachIndexed { index, text ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = text,
                        fontSize = 12.sp,
                        fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (index == selectedIndex) IosAccentRed else labelColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

// Slider Vertikal untuk 5-Band Equalizer
@Composable
private fun VerticalBandSlider(
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    enabled: Boolean,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = valueRange,
        enabled = enabled,
        colors = SliderDefaults.colors(
            thumbColor = if (enabled) Color.White else IosSecondaryLabel,
            activeTrackColor = if (enabled) IosAccentRed else Color.Gray.copy(alpha = 0.35f),
            inactiveTrackColor = Color.Gray.copy(alpha = 0.25f)
        ),
        modifier = modifier
            .graphicsLayer {
                rotationZ = 270f
                transformOrigin = TransformOrigin(0f, 0f)
            }
            .layout { measurable, constraints ->
                val placeable = measurable.measure(
                    Constraints(
                        minWidth = constraints.minHeight,
                        maxWidth = constraints.maxHeight,
                        minHeight = constraints.minWidth,
                        maxHeight = constraints.maxWidth
                    )
                )
                layout(placeable.height, placeable.width) {
                    placeable.place(-placeable.width, 0)
                }
            }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IosEqualizerSheet(
    eqState: EqState,
    isDark: Boolean,
    onUpdateEq: (
        enabled: Boolean,
        preset: String,
        levels: List<Int>,
        bass: Int,
        loudnessEnabled: Boolean,
        loudnessGainMb: Int,
        skipSilence: Boolean
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val contentColor = if (isDark) Color.White else Color.Black
    val cardBg = if (isDark) IosDarkCard else IosLightCard
    val subBg = if (isDark) IosDarkSearchBg else IosLightSearchBg

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = cardBg,
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Equalizer + Switch Aktif/Nonaktif
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = null,
                        tint = IosAccentRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Equalizer & Suara",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                }
                Switch(
                    checked = eqState.enabled,
                    onCheckedChange = { checked ->
                        onUpdateEq(
                            checked,
                            eqState.presetName,
                            eqState.bandLevelsMb,
                            eqState.bassStrength,
                            eqState.loudnessEnabled,
                            eqState.loudnessGainMb,
                            eqState.skipSilence
                        )
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = IosAccentRed
                    )
                )
            }

            // Preset Chips Horizontal Scroll
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Preset Suara",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = IosSecondaryLabel
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EqPresets.forEach { (presetName, presetLevels) ->
                        val active = eqState.presetName == presetName
                        Surface(
                            modifier = Modifier
                                .height(34.dp)
                                .clickable {
                                    val bandCount = eqState.bandLevelsMb.size.coerceAtLeast(1)
                                    val mapped = (0 until bandCount).map { idx ->
                                        (presetLevels.getOrNull(idx) ?: 0)
                                            .coerceIn(eqState.minLevelMb, eqState.maxLevelMb)
                                    }
                                    onUpdateEq(
                                        true,
                                        presetName,
                                        mapped,
                                        eqState.bassStrength,
                                        eqState.loudnessEnabled,
                                        eqState.loudnessGainMb,
                                        eqState.skipSilence
                                    )
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (active && eqState.enabled) IosAccentRed else subBg
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(horizontal = 14.dp)
                            ) {
                                Text(
                                    text = presetName,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (active && eqState.enabled) Color.White else contentColor
                                )
                            }
                        }
                    }
                }
            }

            // 5-Band Equalizer Sliders
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = subBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val bands = eqState.bandLevelsMb.size
                    for (b in 0 until bands) {
                        val levelMb = eqState.bandLevelsMb.getOrNull(b) ?: 0
                        val freqHz = eqState.bandFreqsHz.getOrNull(b) ?: 1000
                        val dbVal = levelMb / 100
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (dbVal > 0) "+${dbVal}dB" else "${dbVal}dB",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (eqState.enabled) IosAccentRed else IosSecondaryLabel,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            VerticalBandSlider(
                                value = levelMb.toFloat(),
                                valueRange = eqState.minLevelMb.toFloat()..eqState.maxLevelMb.toFloat(),
                                enabled = eqState.enabled,
                                onValueChange = { newVal ->
                                    val updated = eqState.bandLevelsMb.toMutableList()
                                    if (b < updated.size) {
                                        updated[b] = newVal.roundToInt()
                                    }
                                    onUpdateEq(
                                        true,
                                        "Kustom",
                                        updated,
                                        eqState.bassStrength,
                                        eqState.loudnessEnabled,
                                        eqState.loudnessGainMb,
                                        eqState.skipSilence
                                    )
                                },
                                modifier = Modifier
                                    .width(36.dp)
                                    .height(125.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = fmtFreq(freqHz),
                                fontSize = 11.sp,
                                color = IosSecondaryLabel,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Bass Boost Slider
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bass Boost",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = IosSecondaryLabel
                    )
                    Text(
                        text = "${(eqState.bassStrength / 10)}%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (eqState.enabled && eqState.bassStrength > 0) IosAccentRed else IosSecondaryLabel
                    )
                }
                Slider(
                    value = eqState.bassStrength.toFloat(),
                    valueRange = 0f..1000f,
                    enabled = eqState.enabled,
                    onValueChange = { v ->
                        onUpdateEq(
                            true,
                            eqState.presetName,
                            eqState.bandLevelsMb,
                            v.roundToInt(),
                            eqState.loudnessEnabled,
                            eqState.loudnessGainMb,
                            eqState.skipSilence
                        )
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = IosAccentRed,
                        inactiveTrackColor = Color.Gray.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Normalisasi Volume (Loudness Enhancer) & Skip Silence
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = subBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Normalisasi Volume (Loudness)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = contentColor
                            )
                            Text(
                                text = "Perkuat audio yang pelan (+${eqState.loudnessGainMb / 100} dB)",
                                fontSize = 11.sp,
                                color = IosSecondaryLabel
                            )
                        }
                        Switch(
                            checked = eqState.loudnessEnabled,
                            onCheckedChange = { checked ->
                                onUpdateEq(
                                    eqState.enabled,
                                    eqState.presetName,
                                    eqState.bandLevelsMb,
                                    eqState.bassStrength,
                                    checked,
                                    eqState.loudnessGainMb,
                                    eqState.skipSilence
                                )
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = IosAccentRed
                            )
                        )
                    }
                    if (eqState.loudnessEnabled) {
                        Slider(
                            value = eqState.loudnessGainMb.toFloat(),
                            valueRange = 0f..1500f,
                            onValueChange = { g ->
                                onUpdateEq(
                                    eqState.enabled,
                                    eqState.presetName,
                                    eqState.bandLevelsMb,
                                    eqState.bassStrength,
                                    true,
                                    g.roundToInt(),
                                    eqState.skipSilence
                                )
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = IosAccentRed,
                                inactiveTrackColor = Color.Gray.copy(alpha = 0.25f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    HorizontalDivider(thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Lewati Bagian Hening (Skip Silence)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = contentColor
                            )
                            Text(
                                text = "Cocok untuk podcast, ceramah, atau jeda panjang",
                                fontSize = 11.sp,
                                color = IosSecondaryLabel
                            )
                        }
                        Switch(
                            checked = eqState.skipSilence,
                            onCheckedChange = { checked ->
                                onUpdateEq(
                                    eqState.enabled,
                                    eqState.presetName,
                                    eqState.bandLevelsMb,
                                    eqState.bassStrength,
                                    eqState.loudnessEnabled,
                                    eqState.loudnessGainMb,
                                    checked
                                )
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = IosAccentRed
                            )
                        )
                    }
                }
            }

            // Tombol Reset ke Flat
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = {
                        val flat = List(eqState.bandLevelsMb.size.coerceAtLeast(5)) { 0 }
                        onUpdateEq(eqState.enabled, "Normal", flat, 0, false, 600, false)
                    }
                ) {
                    Text("Reset Semua", color = IosAccentRed, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
private fun IosBottomTabBar(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    favCount: Int,
    queueCount: Int,
    isDark: Boolean
) {
    val barBg = if (isDark) Color(0xF5141416) else Color(0xFAF9F9FB)
    val tabs = listOf(
        Triple("Jelajahi", Icons.Rounded.Search, 0),
        Triple("Favorit", Icons.Rounded.Favorite, favCount),
        Triple("Antrean", Icons.Rounded.QueueMusic, queueCount)
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(barBg)
            .navigationBarsPadding()
    ) {
        HorizontalDivider(
            thickness = 0.5.dp,
            color = Color.Gray.copy(alpha = 0.25f)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEachIndexed { index, (label, icon, badgeCount) ->
                val selected = selectedTab == index
                val itemColor = if (selected) IosAccentRed else IosSecondaryLabel
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectTab(index) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = itemColor,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (badgeCount > 0) "$label ($badgeCount)" else label,
                        fontSize = 10.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        color = itemColor
                    )
                }
            }
        }
    }
}

@Composable
private fun IosMiniPlayer(
    now: Now,
    c: MediaController,
    isDark: Boolean,
    showArtwork: Boolean,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val barBg = if (isDark) Color(0xF22C2C2E) else Color(0xFAFFFFFF)
    val contentColor = if (isDark) Color.White else Color.Black

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(60.dp)
            .shadow(14.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onOpen),
        shape = RoundedCornerShape(16.dp),
        color = barBg
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IosArtwork(url = now.art, size = 42.dp, cornerRadius = 8.dp, showImage = showArtwork)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = now.title.ifEmpty { "Memuat…" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = contentColor
                )
                if (now.artist.isNotEmpty()) {
                    Text(
                        text = now.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 12.sp,
                        color = IosSecondaryLabel
                    )
                }
            }
            IconButton(onClick = { toggle(c) }) {
                Icon(
                    imageVector = if (now.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = "Putar/Jeda",
                    tint = contentColor,
                    modifier = Modifier.size(28.dp)
                )
            }
            IconButton(onClick = { c.seekToNextMediaItem() }) {
                Icon(
                    imageVector = Icons.Rounded.FastForward,
                    contentDescription = "Berikutnya",
                    tint = contentColor,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerProgress(posState: State<Long>, durMs: Long, onSeek: (Long) -> Unit) {
    var seeking by remember { mutableStateOf<Float?>(null) }
    val dur = durMs.coerceAtLeast(1L)
    val pos = posState.value

    Slider(
        value = (seeking ?: (pos.toFloat() / dur)).coerceIn(0f, 1f),
        onValueChange = { seeking = it },
        onValueChangeFinished = {
            seeking?.let { onSeek((it * dur).toLong()) }
            seeking = null
        },
        colors = SliderDefaults.colors(
            thumbColor = Color.White,
            activeTrackColor = IosAccentRed,
            inactiveTrackColor = Color.Gray.copy(alpha = 0.25f)
        ),
        modifier = Modifier.fillMaxWidth()
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(fmt(seeking?.let { (it * dur).toLong() } ?: pos), fontSize = 11.sp, color = IosSecondaryLabel)
        Text(fmt(durMs), fontSize = 11.sp, color = IosSecondaryLabel)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IosFullPlayer(
    now: Now,
    c: MediaController,
    video: Boolean,
    videoQuality: Int,
    audioSaver: Boolean,
    showArtwork: Boolean,
    eqState: EqState,
    autoplayRadio: Boolean,
    status: String?,
    isDark: Boolean,
    isFavorite: Boolean,
    sleepRemainingMin: Int?,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onExportMusicFolder: () -> Unit,
    onMode: (Boolean) -> Unit,
    onQualityChange: (Int) -> Unit,
    onAudioSaverChange: (Boolean) -> Unit,
    onToggleAutoplay: (Boolean) -> Unit,
    onSetSleepTimer: (Int?) -> Unit,
    onOpenEq: () -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)
    // Posisi lagu disimpan sebagai State yang TIDAK dibaca di body pemutar (hanya di PlayerProgress &
    // derivedStateOf), supaya tiap ketukan polling tidak menggambar ulang seluruh layar pemutar.
    val posState = remember { mutableLongStateOf(0L) }
    var showOptionsSheet by remember { mutableStateOf(false) }

    // State Lirik Sinkron (LRCLIB)
    var showLyrics by remember { mutableStateOf(false) }
    var lyricsLoading by remember { mutableStateOf(false) }
    var lyricsResult by remember { mutableStateOf<LyricsResult?>(null) }
    val lyricsListState = rememberLazyListState()

    LaunchedEffect(c, showLyrics) {
        while (true) {
            posState.longValue = c.currentPosition.coerceAtLeast(0L)
            delay(if (showLyrics) 300L else if (c.isPlaying) 500L else 1000L)
        }
    }

    LaunchedEffect(showLyrics, now.mediaId, now.title) {
        if (!showLyrics || now.title.isBlank()) return@LaunchedEffect
        lyricsLoading = true
        lyricsResult = withContext(Dispatchers.IO) {
            LyricsClient.fetchLyrics(now.title, now.artist, now.durationMs / 1000L)
        }
        lyricsLoading = false
    }

    // Berubah hanya saat baris lirik aktif berganti (bukan tiap ketukan posisi)
    val activeLyricIndexState = remember {
        derivedStateOf {
            val lines = lyricsResult?.synced.orEmpty()
            if (lines.isEmpty()) -1
            else lines.indexOfLast { it.timeMs <= posState.longValue + 250L }
        }
    }
    val activeLyricIndex = activeLyricIndexState.value

    LaunchedEffect(activeLyricIndex, showLyrics) {
        if (showLyrics && activeLyricIndex >= 0) {
            runCatching {
                lyricsListState.animateScrollToItem((activeLyricIndex - 2).coerceAtLeast(0))
            }
        }
    }

    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    val animatedOffsetY by animateFloatAsState(
        targetValue = dragOffsetY,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "drag_dismiss"
    )

    val artworkScale by animateFloatAsState(
        targetValue = if (now.playing || video || showLyrics) 1.0f else 0.90f,
        animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessLow),
        label = "artwork_scale"
    )

    val sheetBg = if (isDark) Color(0xFF141416) else Color(0xFFFAFAFC)
    val contentColor = if (isDark) Color.White else Color.Black

    Box(
        modifier = Modifier
            .fillMaxSize()
            .offset { IntOffset(0, animatedOffsetY.roundToInt().coerceAtLeast(0)) }
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(sheetBg)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (dragOffsetY > 220f) onClose()
                        dragOffsetY = 0f
                    },
                    onDragCancel = { dragOffsetY = 0f },
                    onVerticalDrag = { change, dragAmount ->
                        change.consume()
                        dragOffsetY = (dragOffsetY + dragAmount).coerceAtLeast(0f)
                    }
                )
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // iOS Grabber Pill
            Box(
                modifier = Modifier
                    .width(38.dp)
                    .height(5.dp)
                    .clip(CircleShape)
                    .background(Color.Gray.copy(alpha = 0.45f))
                    .clickable { onClose() }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Header bar: tombol tutup, segmented mode Audio/Video, dan tombol opsi (...)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.16f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Tutup",
                        tint = contentColor
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                IosModeSegmentedControl(
                    video = video,
                    onMode = onMode,
                    isDark = isDark,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(10.dp))
                IconButton(
                    onClick = { showOptionsSheet = true },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.16f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.MoreHoriz,
                        contentDescription = "Opsi Lainnya",
                        tint = IosAccentRed
                    )
                }
            }

            // Pilihan Kualitas Audio / Video sesuai mode aktif
            Spacer(modifier = Modifier.height(10.dp))
            if (video) {
                IosQualitySegmentedControl(
                    selectedQuality = videoQuality,
                    onSelectQuality = onQualityChange,
                    isDark = isDark,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                IosAudioQualitySegmentedControl(
                    audioSaver = audioSaver,
                    onSelectAudioSaver = onAudioSaverChange,
                    isDark = isDark,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.weight(0.4f))

            // Artwork, Video Surface, atau Lirik Lagu Sinkron
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(if (video && !showLyrics) 16f / 9f else 1f)
                    .scale(artworkScale)
                    .shadow(24.dp, RoundedCornerShape(20.dp))
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (showLyrics) {
                            Brush.verticalGradient(listOf(Color(0xFF1F1F24), Color(0xFF121215)))
                        } else {
                            Brush.linearGradient(listOf(Color(0xFFFA233B), Color(0xFFFF6B81)))
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (showLyrics) {
                    when {
                        lyricsLoading -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = IosAccentRed, modifier = Modifier.size(30.dp))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Mencari lirik lagu…", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                            }
                        }
                        lyricsResult != null && lyricsResult!!.synced.isNotEmpty() -> {
                            val lines = lyricsResult!!.synced
                            LazyColumn(
                                state = lyricsListState,
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 28.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                itemsIndexed(lines) { idx, line ->
                                    val isActive = idx == activeLyricIndex
                                    Text(
                                        text = line.text,
                                        fontSize = if (isActive) 20.sp else 16.sp,
                                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isActive) Color.White else Color.White.copy(alpha = 0.42f),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { c.seekTo(line.timeMs) }
                                    )
                                }
                            }
                        }
                        lyricsResult != null && !lyricsResult!!.plain.isNullOrBlank() -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(20.dp)
                            ) {
                                Text(
                                    text = lyricsResult!!.plain.orEmpty(),
                                    fontSize = 15.sp,
                                    lineHeight = 22.sp,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }
                        }
                        else -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Lyrics,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.4f),
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Lirik tidak ditemukan untuk lagu ini",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else if (video) {
                    AndroidView(
                        factory = { PlayerView(it).apply { useController = false } },
                        update = { it.player = c },
                        onRelease = { it.player = null },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Rounded.MusicNote,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(96.dp)
                    )
                    if (showArtwork && !now.art.isNullOrBlank()) {
                        AsyncImage(
                            model = now.art,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.4f))

            // Judul, Artis, Tombol Lirik, Equalizer, Favorit & Bagikan
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = now.title.ifEmpty { "Memuat…" },
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = now.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = IosAccentRed
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = { showLyrics = !showLyrics },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (showLyrics) IosAccentRed.copy(alpha = 0.18f) else Color.Gray.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lyrics,
                        contentDescription = "Lirik",
                        tint = if (showLyrics) IosAccentRed else contentColor,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = onOpenEq,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (eqState.enabled || eqState.loudnessEnabled) IosAccentRed.copy(alpha = 0.18f) else Color.Gray.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = "Equalizer",
                        tint = if (eqState.enabled || eqState.loudnessEnabled) IosAccentRed else contentColor,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorit",
                        tint = IosAccentRed,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = { shareTrack(ctx, now.mediaId, now.title) },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.IosShare,
                        contentDescription = "Bagikan",
                        tint = IosAccentRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Status / Info EQ / Sleep Timer / Kecepatan
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (eqState.enabled) {
                    AssistChip(
                        onClick = onOpenEq,
                        leadingIcon = {
                            Icon(Icons.Rounded.GraphicEq, contentDescription = null, modifier = Modifier.size(14.dp), tint = IosAccentRed)
                        },
                        label = { Text("EQ: ${eqState.presetName}", fontSize = 11.sp) }
                    )
                }
                if (now.speed != 1.0f) {
                    AssistChip(
                        onClick = { showOptionsSheet = true },
                        label = { Text("${now.speed}x", fontSize = 11.sp) }
                    )
                }
                if (sleepRemainingMin != null) {
                    AssistChip(
                        onClick = { showOptionsSheet = true },
                        leadingIcon = {
                            Icon(Icons.Rounded.Bedtime, contentDescription = null, modifier = Modifier.size(14.dp))
                        },
                        label = { Text("Tidur: ${sleepRemainingMin}m", fontSize = 11.sp) }
                    )
                }
                status?.let {
                    Text(
                        text = it,
                        color = IosSecondaryLabel,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // iOS Slider + label waktu (composable terpisah: hanya bagian ini yang di-recompose tiap detik)
            PlayerProgress(
                posState = posState,
                durMs = now.durationMs,
                onSeek = { ms ->
                    c.seekTo(ms)
                    posState.longValue = ms
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Kontrol Pemutaran Utama: Shuffle - Prev - Play/Pause - Next - Repeat
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { c.shuffleModeEnabled = !now.shuffle },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shuffle,
                        contentDescription = "Acak",
                        tint = if (now.shuffle) IosAccentRed else IosSecondaryLabel,
                        modifier = Modifier.size(22.dp)
                    )
                }

                IconButton(onClick = { c.seekToPrevious() }, modifier = Modifier.size(54.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.FastRewind,
                        contentDescription = "Sebelumnya",
                        tint = contentColor,
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(onClick = { toggle(c) }, modifier = Modifier.size(72.dp)) {
                    Icon(
                        imageVector = if (now.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = "Putar/Jeda",
                        tint = contentColor,
                        modifier = Modifier.size(56.dp)
                    )
                }

                IconButton(onClick = { c.seekToNextMediaItem() }, modifier = Modifier.size(54.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.FastForward,
                        contentDescription = "Berikutnya",
                        tint = contentColor,
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(
                    onClick = {
                        c.repeatMode = when (now.repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                    },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = if (now.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        contentDescription = "Ulangi",
                        tint = if (now.repeatMode != Player.REPEAT_MODE_OFF) IosAccentRed else IosSecondaryLabel,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // iOS Action Sheet untuk Opsi Lanjutan
        if (showOptionsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showOptionsSheet = false },
                containerColor = if (isDark) IosDarkCard else IosLightCard,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Opsi Pemutaran & File",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )

                    // Aksi Cepat: Simpan ke Folder Musik HP & Tambah ke Playlist
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                showOptionsSheet = false
                                onExportMusicFolder()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                        ) {
                            Icon(Icons.Rounded.LibraryMusic, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simpan ke Musik HP", fontSize = 12.sp, maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = {
                                showOptionsSheet = false
                                onAddToPlaylist()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.PlaylistAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ke Playlist", fontSize = 12.sp, maxLines = 1)
                        }
                    }

                    // Mode Radio / Autoplay Lagu Serupa
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isDark) IosDarkSearchBg else IosLightSearchBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Radio,
                                contentDescription = null,
                                tint = IosAccentRed,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Mode Radio (Autoplay Serupa)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = contentColor
                                )
                                Text(
                                    text = "Putar lagu terkait otomatis setelah antrean habis",
                                    fontSize = 11.sp,
                                    color = IosSecondaryLabel
                                )
                            }
                            Switch(
                                checked = autoplayRadio,
                                onCheckedChange = onToggleAutoplay,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = IosAccentRed
                                )
                            )
                        }
                    }

                    // Tombol Buka Menu Equalizer & Normalisasi Volume
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showOptionsSheet = false
                                onOpenEq()
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isDark) IosDarkSearchBg else IosLightSearchBg
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = null,
                                tint = IosAccentRed,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Equalizer, Loudness & Skip Silence",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = contentColor
                                )
                                Text(
                                    text = if (eqState.enabled) "EQ: ${eqState.presetName}" else "Ketuk untuk atur efek suara",
                                    fontSize = 12.sp,
                                    color = IosSecondaryLabel
                                )
                            }
                            Icon(
                                imageVector = Icons.Rounded.ChevronRight,
                                contentDescription = null,
                                tint = IosSecondaryLabel
                            )
                        }
                    }

                    // 1. Kecepatan Pemutaran
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Kecepatan Pemutaran",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosSecondaryLabel
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                                val active = now.speed == spd
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .clickable {
                                            c.playbackParameters = PlaybackParameters(spd)
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (active) IosAccentRed else (if (isDark) IosDarkSearchBg else IosLightSearchBg)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "${spd}x",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (active) Color.White else contentColor
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 2. Sleep Timer
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Sleep Timer (Mati Otomatis)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosSecondaryLabel
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val timers = listOf<Pair<String, Int?>>(
                                "Mati" to null,
                                "15m" to 15,
                                "30m" to 30,
                                "45m" to 45,
                                "60m" to 60
                            )
                            timers.forEach { (label, mins) ->
                                val active = sleepRemainingMin == mins
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .clickable {
                                            onSetSleepTimer(mins)
                                            showOptionsSheet = false
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (active) IosAccentRed else (if (isDark) IosDarkSearchBg else IosLightSearchBg)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = label,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (active) Color.White else contentColor
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 3. Kualitas Audio & Resolusi Video
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Kualitas Audio (Hemat Kuota)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosSecondaryLabel
                        )
                        IosAudioQualitySegmentedControl(
                            audioSaver = audioSaver,
                            onSelectAudioSaver = { saver ->
                                onAudioSaverChange(saver)
                                showOptionsSheet = false
                            },
                            isDark = isDark,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Resolusi Video Maksimal",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosSecondaryLabel
                        )
                        IosQualitySegmentedControl(
                            selectedQuality = videoQuality,
                            onSelectQuality = { q ->
                                onQualityChange(q)
                                showOptionsSheet = false
                            },
                            isDark = isDark,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // 4. Salin & Bagikan Tautan
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                copyLink(ctx, now.mediaId)
                                showOptionsSheet = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Salin Link", fontSize = 13.sp)
                        }
                        Button(
                            onClick = {
                                shareTrack(ctx, now.mediaId, now.title)
                                showOptionsSheet = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                        ) {
                            Icon(Icons.Rounded.IosShare, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bagikan", fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    private var sharedText by mutableStateOf<String?>(null)
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        EqualizerStore.loadPrefs(this)
        PlaybackSettingsStore.init(this)
        sharedText = intent.sharedText()
        setContent {
            val isDark = isSystemInDarkTheme()
            val scheme = if (isDark) {
                darkColorScheme(
                    primary = IosAccentRed,
                    background = IosDarkBg,
                    surface = IosDarkCard,
                    surfaceVariant = IosDarkSearchBg,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            } else {
                lightColorScheme(
                    primary = IosAccentRed,
                    background = IosLightBg,
                    surface = IosLightCard,
                    surfaceVariant = IosLightSearchBg,
                    onBackground = Color.Black,
                    onSurface = Color.Black
                )
            }
            MaterialTheme(colorScheme = scheme) {
                Surface(modifier = Modifier.fillMaxSize(), color = scheme.background) {
                    App(isDark = isDark)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (controllerFuture == null) {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerFuture = MediaController.Builder(this, token).buildAsync().also { f ->
                f.addListener({ controller = f.get().also { setVideo(it, true) } }, ContextCompat.getMainExecutor(this))
            }
        } else controller?.let { setVideo(it, true) }
    }

    override fun onStop() {
        controller?.let { setVideo(it, false) }
        super.onStop()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null; controller = null
        super.onDestroy()
    }

    private fun setVideo(c: MediaController, on: Boolean) {
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !on).build()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        sharedText = intent.sharedText()
    }

    private fun Intent.sharedText() =
        if (action == Intent.ACTION_SEND) getStringExtra(Intent.EXTRA_TEXT) else null

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun App(isDark: Boolean) {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()
        val focus = LocalFocusManager.current
        val c = controller
        val now = rememberNow(c)
        val engineStatus by Engine.status.collectAsState()
        val eqState by EqualizerStore.state.collectAsState()
        val autoDlMode by FavoriteDownloader.mode.collectAsState()
        val offlineUrls by FavoriteDownloader.downloadedUrls.collectAsState()
        val downloadingUrl by FavoriteDownloader.downloadingUrl.collectAsState()
        val offlineBytes by FavoriteDownloader.totalStorageBytes.collectAsState()
        val autoplayRadio by PlaybackSettingsStore.autoplayRadio.collectAsState()
        val liveQueue by PlaybackSettingsStore.liveQueue.collectAsState()
        val radioLoading by PlaybackSettingsStore.radioLoading.collectAsState()

        var selectedTab by remember { mutableIntStateOf(0) } // 0: Jelajahi, 1: Favorit, 2: Antrean
        var favSubTab by remember { mutableIntStateOf(0) } // 0: Lagu Favorit, 1: Playlist, 2: Backup
        var query by remember { mutableStateOf("") }
        var results by remember { mutableStateOf<List<Track>>(emptyList()) }
        var favorites by remember { mutableStateOf<List<Track>>(FavoritesStore.load(ctx)) }
        var recentTracks by remember { mutableStateOf<List<Track>>(RecentlyPlayedStore.load(ctx)) }
        var playlists by remember { mutableStateOf<List<CustomPlaylist>>(PlaylistStore.load(ctx)) }
        var openedPlaylistId by remember { mutableStateOf<String?>(null) }

        // Dialogs & Sheets state
        var trackActionTarget by remember { mutableStateOf<Track?>(null) }
        var playlistPickerTrack by remember { mutableStateOf<Track?>(null) }
        var showCreatePlaylistDialog by remember { mutableStateOf(false) }
        var newPlaylistName by remember { mutableStateOf("") }
        var pendingExportTrack by remember { mutableStateOf<Track?>(null) }

        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
        val storagePerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val t = pendingExportTrack
            pendingExportTrack = null
            if (granted && t != null) {
                scope.launch {
                    Toast.makeText(ctx, "Menyimpan ke Music/StreamPlus…", Toast.LENGTH_SHORT).show()
                    val res = withContext(Dispatchers.IO) { MusicExporter.exportTrackToPublicMusic(ctx, t) }
                    Toast.makeText(ctx, res.getOrElse { "Gagal: ${it.message}" }, Toast.LENGTH_LONG).show()
                }
            }
        }

        // Backup & Restore JSON Launchers
        val exportBackupLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.CreateDocument("application/json")
        ) { uri ->
            if (uri != null) {
                runCatching {
                    val jsonStr = LibraryBackupManager.exportJson(favorites, playlists)
                    ctx.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(jsonStr.toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(ctx, "Backup berhasil disimpan!", Toast.LENGTH_SHORT).show()
                }.onFailure {
                    Toast.makeText(ctx, "Gagal ekspor backup: ${it.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val importBackupLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                runCatching {
                    val raw = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("File tidak dapat dibaca")
                    val (mergedFavs, mergedPls, counts) = LibraryBackupManager.importJson(favorites, playlists, raw)
                    favorites = mergedFavs
                    playlists = mergedPls
                    FavoritesStore.save(ctx, mergedFavs)
                    PlaylistStore.save(ctx, mergedPls)
                    FavoriteDownloader.syncFavorites(ctx, mergedFavs)
                    Toast.makeText(
                        ctx,
                        "Impor selesai: +${counts.first} favorit, +${counts.second} playlist",
                        Toast.LENGTH_LONG
                    ).show()
                }.onFailure {
                    Toast.makeText(ctx, "File backup tidak valid: ${it.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            FavoriteDownloader.init(ctx)
            FavoriteDownloader.syncFavorites(ctx, favorites)
        }

        val appPrefs = remember { ctx.getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE) }
        var loading by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf<String?>(null) }
        var video by remember { mutableStateOf(false) }
        var videoQuality by remember { mutableIntStateOf(720) }
        var audioSaver by remember { mutableStateOf(appPrefs.getBoolean("audio_saver", true)) }
        var expanded by remember { mutableStateOf(false) }
        var showEqSheet by remember { mutableStateOf(false) }

        // Sleep timer state
        var sleepRemainingMin by remember { mutableStateOf<Int?>(null) }

        LaunchedEffect(sleepRemainingMin) {
            val mins = sleepRemainingMin ?: return@LaunchedEffect
            if (mins <= 0) {
                controller?.pause()
                sleepRemainingMin = null
                Toast.makeText(ctx, "Sleep timer selesai — pemutaran dijeda", Toast.LENGTH_SHORT).show()
            } else {
                delay(60_000L)
                sleepRemainingMin = mins - 1
            }
        }

        // Catat Riwayat Putar (Recently Played) setiap kali lagu aktif berganti
        LaunchedEffect(now.mediaId) {
            val id = now.mediaId
            if (id.isBlank()) return@LaunchedEffect
            val found = (liveQueue + results + favorites + recentTracks).firstOrNull { it.url == id }
                ?: Track(id, now.title.ifBlank { "Lagu" }, now.artist, now.durationMs / 1000L, now.art)
            if (found.title.isNotBlank()) {
                recentTracks = RecentlyPlayedStore.record(ctx, found)
            }
        }

        val bgColor = if (isDark) IosDarkBg else IosLightBg
        val cardColor = if (isDark) IosDarkCard else IosLightCard
        val primaryText = if (isDark) Color.White else Color.Black

        fun exportTrackToMusicFolder(track: Track) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) {
                pendingExportTrack = track
                storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                return
            }
            scope.launch {
                Toast.makeText(ctx, "Menyimpan ke Music/StreamPlus…", Toast.LENGTH_SHORT).show()
                val res = withContext(Dispatchers.IO) { MusicExporter.exportTrackToPublicMusic(ctx, track) }
                Toast.makeText(ctx, res.getOrElse { "Gagal: ${it.message}" }, Toast.LENGTH_LONG).show()
            }
        }

        fun updateEqualizer(
            enabled: Boolean,
            preset: String,
            levels: List<Int>,
            bass: Int,
            loudnessEnabled: Boolean,
            loudnessGainMb: Int,
            skipSilence: Boolean
        ) {
            val updated = eqState.copy(
                enabled = enabled,
                presetName = preset,
                bandLevelsMb = levels,
                bassStrength = bass,
                loudnessEnabled = loudnessEnabled,
                loudnessGainMb = loudnessGainMb,
                skipSilence = skipSilence
            )
            EqualizerStore.state.value = updated
            EqualizerStore.applyCurrentState(ctx)
            controller?.sendCustomCommand(
                SessionCommand(CMD_SET_EQ, Bundle.EMPTY),
                Bundle().apply {
                    putBoolean("enabled", enabled)
                    putString("preset", preset)
                    putInt("bass", bass)
                    putIntegerArrayList("levels", ArrayList(levels))
                    putBoolean("loudnessEnabled", loudnessEnabled)
                    putInt("loudnessGain", loudnessGainMb)
                    putBoolean("skipSilence", skipSilence)
                }
            )
        }

        fun setAutoplayRadio(enabled: Boolean) {
            PlaybackSettingsStore.setAutoplayRadio(ctx, enabled)
            controller?.sendCustomCommand(
                SessionCommand(CMD_SET_AUTOPLAY, Bundle.EMPTY),
                Bundle().apply { putBoolean("autoplay", enabled) }
            )
        }

        fun toggleFavorite(track: Track) {
            val exists = favorites.any { it.url == track.url }
            val updated = if (exists) {
                FavoriteDownloader.deleteOfflineForUrl(ctx, track.url)
                favorites.filterNot { it.url == track.url }
            } else {
                listOf(track) + favorites
            }
            favorites = updated
            FavoritesStore.save(ctx, updated)
            FavoriteDownloader.syncFavorites(ctx, updated)
            if (!exists && autoDlMode != AutoDownloadMode.OFF) {
                Toast.makeText(ctx, "Ditambahkan ke Favorit (auto-download antre)", Toast.LENGTH_SHORT).show()
            }
        }

        fun playList(list: List<Track>, startIndex: Int) {
            val ctrl = controller ?: run { message = "Pemutar belum siap, coba lagi sebentar."; return }
            if (list.isEmpty()) return
            PlaybackSettingsStore.liveQueue.value = list
            val args = Bundle().apply {
                putStringArrayList("urls", ArrayList(list.map { it.url }))
                putStringArrayList("titles", ArrayList(list.map { it.title }))
                putStringArrayList("artists", ArrayList(list.map { it.artist }))
                putStringArrayList("thumbs", ArrayList(list.map { it.thumb.orEmpty() }))
                putLongArray("durations", list.map { it.durationSec }.toLongArray())
                putInt("start", startIndex)
                putBoolean("video", video)
                putInt("quality", videoQuality)
                putBoolean("audioSaver", audioSaver)
            }
            ctrl.sendCustomCommand(SessionCommand(CMD_SET_QUEUE, Bundle.EMPTY), args)
        }

        fun search(text: String = query, autoPlay: Boolean = false) {
            val q = text.trim()
            if (q.isEmpty() || loading) return
            focus.clearFocus()
            selectedTab = 0
            loading = true; message = null
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { Engine.query(ctx, q) } }
                    .onSuccess {
                        results = it
                        if (it.isEmpty()) message = "Tidak ada hasil"
                        else if (autoPlay) playList(it, 0)
                    }
                    .onFailure {
                        message = "Gagal: ${it.message?.take(160)}\n(Jika baru dibuka, tunggu sebentar lalu coba lagi.)"
                    }
                loading = false
            }
        }

        fun setMode(v: Boolean) {
            video = v
            controller?.sendCustomCommand(
                SessionCommand(CMD_SET_MODE, Bundle.EMPTY),
                Bundle().apply {
                    putBoolean("video", v)
                    putInt("quality", videoQuality)
                    putBoolean("audioSaver", audioSaver)
                }
            )
        }

        fun setAudioSaver(saver: Boolean) {
            audioSaver = saver
            appPrefs.edit().putBoolean("audio_saver", saver).apply()
            controller?.sendCustomCommand(
                SessionCommand(CMD_SET_AUDIO_SAVER, Bundle.EMPTY),
                Bundle().apply { putBoolean("audioSaver", saver) }
            )
            val label = if (saver) "Mode Hemat Kuota (~48k) aktif" else "Mode Audio HD (~128k) aktif"
            Toast.makeText(ctx, label, Toast.LENGTH_SHORT).show()
        }

        fun setQuality(q: Int) {
            videoQuality = q
            controller?.sendCustomCommand(
                SessionCommand(CMD_SET_QUALITY, Bundle.EMPTY),
                Bundle().apply { putInt("quality", q) }
            )
            Toast.makeText(ctx, "Resolusi video maksimal: ${q}p", Toast.LENGTH_SHORT).show()
        }

        LaunchedEffect(sharedText) {
            val link = sharedText?.let { Regex("https?://\\S+").find(it)?.value }
            if (link != null) { query = link; search(link, autoPlay = true); sharedText = null }
        }

        val currentTrackObj = remember(now.mediaId, results, favorites, liveQueue, recentTracks) {
            (liveQueue + results + favorites + recentTracks).firstOrNull { it.url == now.mediaId }
                ?: if (now.mediaId.isNotBlank()) Track(now.mediaId, now.title, now.artist, now.durationMs / 1000L, now.art) else null
        }
        val isCurrentFavorite = currentTrackObj != null && favorites.any { it.url == currentTrackObj.url }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgColor)
        ) {
            Scaffold(
                containerColor = bgColor,
                bottomBar = {
                    Column {
                        if (now.has && c != null && !expanded) {
                            IosMiniPlayer(
                                now = now,
                                c = c,
                                isDark = isDark,
                                showArtwork = video || !audioSaver,
                                onOpen = { expanded = true },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                        IosBottomTabBar(
                            selectedTab = selectedTab,
                            onSelectTab = { tab -> selectedTab = tab },
                            favCount = favorites.size,
                            queueCount = liveQueue.size,
                            isDark = isDark
                        )
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .padding(bottom = innerPadding.calculateBottomPadding())
                        .padding(horizontal = 16.dp)
                ) {
                    Spacer(modifier = Modifier.height(10.dp))

                    // iOS Large Title Header + Tombol Equalizer + Tombol Update yt-dlp
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val headerTitle = when (selectedTab) {
                            0 -> "Jelajahi"
                            1 -> "Favorit"
                            else -> "Antrean"
                        }
                        Text(
                            text = headerTitle,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.5).sp,
                            color = primaryText,
                            modifier = Modifier.weight(1f)
                        )
                        if (sleepRemainingMin != null) {
                            Surface(
                                shape = CircleShape,
                                color = IosAccentRed.copy(alpha = 0.14f),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Bedtime,
                                        contentDescription = null,
                                        tint = IosAccentRed,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "${sleepRemainingMin}m",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = IosAccentRed
                                    )
                                }
                            }
                        }
                        IconButton(
                            onClick = { showEqSheet = true },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    if (eqState.enabled || eqState.loudnessEnabled) IosAccentRed.copy(alpha = 0.18f)
                                    else if (isDark) IosDarkSearchBg else IosLightSearchBg
                                )
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = "Equalizer",
                                tint = IosAccentRed,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                message = "Memperbarui yt-dlp…"
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) { Engine.update(ctx) }
                                    message = "yt-dlp: $r"
                                }
                            },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(if (isDark) IosDarkSearchBg else IosLightSearchBg)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Update yt-dlp",
                                tint = IosAccentRed,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // ================= TAB 0: JELAJAHI + RIWAYAT PUTAR =================
                    if (selectedTab == 0) {
                        IosSearchBar(
                            query = query,
                            onQueryChange = {
                                query = it
                                if (it.isEmpty()) results = emptyList()
                            },
                            onSearch = { search(autoPlay = query.startsWith("http")) },
                            isDark = isDark
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        IosModeSegmentedControl(
                            video = video,
                            onMode = ::setMode,
                            isDark = isDark,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        if (video) {
                            IosQualitySegmentedControl(
                                selectedQuality = videoQuality,
                                onSelectQuality = ::setQuality,
                                isDark = isDark,
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else {
                            IosAudioQualitySegmentedControl(
                                audioSaver = audioSaver,
                                onSelectAudioSaver = ::setAudioSaver,
                                isDark = isDark,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        if (loading) {
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(CircleShape),
                                color = IosAccentRed
                            )
                        }

                        (message ?: engineStatus)?.let {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = it,
                                color = IosSecondaryLabel,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val showingRecent = results.isEmpty() && recentTracks.isNotEmpty()
                        val listToShow = if (results.isNotEmpty()) results else recentTracks

                        if (showingRecent) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.History,
                                    contentDescription = null,
                                    tint = IosAccentRed,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Baru Diputar (${recentTracks.size})",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = primaryText,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "Putar Semua",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = IosAccentRed,
                                    modifier = Modifier.clickable { playList(recentTracks, 0) }
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Hapus",
                                    fontSize = 12.sp,
                                    color = IosSecondaryLabel,
                                    modifier = Modifier.clickable {
                                        RecentlyPlayedStore.clear(ctx)
                                        recentTracks = emptyList()
                                    }
                                )
                            }
                        }

                        if (listToShow.isEmpty() && !loading) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Rounded.GraphicEq,
                                        contentDescription = null,
                                        tint = IosSecondaryLabel.copy(alpha = 0.5f),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Cari lagu atau tempel tautan YouTube",
                                        color = IosSecondaryLabel,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        } else {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = cardColor
                            ) {
                                LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                    itemsIndexed(listToShow) { i, t ->
                                        TrackRowItem(
                                            track = t,
                                            isCurrent = now.mediaId == t.url,
                                            isPlaying = now.mediaId == t.url && now.playing,
                                            isFav = favorites.any { it.url == t.url },
                                            isOffline = t.url in offlineUrls,
                                            isDownloading = downloadingUrl == t.url,
                                            showArtwork = video || !audioSaver,
                                            primaryText = primaryText,
                                            onClick = { playList(listToShow, i) },
                                            onToggleFav = { toggleFavorite(t) },
                                            onMoreClick = { trackActionTarget = t }
                                        )
                                        if (i < listToShow.lastIndex) {
                                            HorizontalDivider(
                                                modifier = Modifier.padding(start = 76.dp),
                                                thickness = 0.5.dp,
                                                color = Color.Gray.copy(alpha = 0.25f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ================= TAB 1: FAVORIT + PLAYLIST + BACKUP =================
                    else if (selectedTab == 1) {
                        IosTextSegmentedControl(
                            labels = listOf("Lagu (${favorites.size})", "Playlist (${playlists.size})", "Backup"),
                            selectedIndex = favSubTab,
                            onSelect = {
                                favSubTab = it
                                openedPlaylistId = null
                            },
                            isDark = isDark,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        if (favSubTab == 0) {
                            // Kartu Kontrol Auto-Download Favorit
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = cardColor,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.OfflinePin,
                                            contentDescription = null,
                                            tint = IosAccentRed,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Auto-Download Favorit (${offlineUrls.size}/${favorites.size})",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = primaryText,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (offlineBytes > 0L) {
                                            Text(
                                                text = fmtSizeMb(offlineBytes),
                                                fontSize = 11.sp,
                                                color = IosSecondaryLabel
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "Hapus",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = IosAccentRed,
                                                modifier = Modifier.clickable {
                                                    FavoriteDownloader.clearAllOffline(ctx)
                                                    Toast.makeText(ctx, "File offline favorit dihapus", Toast.LENGTH_SHORT).show()
                                                }
                                            )
                                        }
                                    }
                                    IosAutoDownloadSegmentedControl(
                                        selectedMode = autoDlMode,
                                        onSelectMode = { newMode -> FavoriteDownloader.setMode(ctx, newMode) },
                                        isDark = isDark,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            if (favorites.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Rounded.FavoriteBorder,
                                            contentDescription = null,
                                            tint = IosSecondaryLabel.copy(alpha = 0.5f),
                                            modifier = Modifier.size(56.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("Belum ada lagu favorit tersimpan", color = IosSecondaryLabel, fontSize = 14.sp)
                                    }
                                }
                            } else {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f),
                                    shape = RoundedCornerShape(14.dp),
                                    color = cardColor
                                ) {
                                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                        itemsIndexed(favorites) { i, t ->
                                            TrackRowItem(
                                                track = t,
                                                isCurrent = now.mediaId == t.url,
                                                isPlaying = now.mediaId == t.url && now.playing,
                                                isFav = true,
                                                isOffline = t.url in offlineUrls,
                                                isDownloading = downloadingUrl == t.url,
                                                showArtwork = video || !audioSaver,
                                                primaryText = primaryText,
                                                onClick = { playList(favorites, i) },
                                                onToggleFav = { toggleFavorite(t) },
                                                onMoreClick = { trackActionTarget = t }
                                            )
                                            if (i < favorites.lastIndex) {
                                                HorizontalDivider(
                                                    modifier = Modifier.padding(start = 76.dp),
                                                    thickness = 0.5.dp,
                                                    color = Color.Gray.copy(alpha = 0.25f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (favSubTab == 1) {
                            // Sub-Tab Playlist Kustom
                            val openedPl = playlists.firstOrNull { it.id == openedPlaylistId }
                            if (openedPl != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { openedPlaylistId = null }) {
                                        Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Kembali", tint = IosAccentRed)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(openedPl.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = primaryText)
                                        Text("${openedPl.tracks.size} lagu", fontSize = 12.sp, color = IosSecondaryLabel)
                                    }
                                    if (openedPl.tracks.isNotEmpty()) {
                                        Button(
                                            onClick = { playList(openedPl.tracks, 0) },
                                            colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Putar", fontSize = 13.sp)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                if (openedPl.tracks.isEmpty()) {
                                    Box(
                                        modifier = Modifier.fillMaxWidth().weight(1f),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "Playlist masih kosong.\nKetuk ikon titik tiga (⋮) pada lagu mana pun untuk menambahkannya.",
                                            color = IosSecondaryLabel,
                                            fontSize = 13.sp,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                } else {
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                        color = cardColor
                                    ) {
                                        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                            itemsIndexed(openedPl.tracks) { idx, t ->
                                                TrackRowItem(
                                                    track = t,
                                                    isCurrent = now.mediaId == t.url,
                                                    isPlaying = now.mediaId == t.url && now.playing,
                                                    isFav = favorites.any { it.url == t.url },
                                                    isOffline = t.url in offlineUrls,
                                                    isDownloading = downloadingUrl == t.url,
                                                    showArtwork = video || !audioSaver,
                                                    primaryText = primaryText,
                                                    onClick = { playList(openedPl.tracks, idx) },
                                                    onToggleFav = { toggleFavorite(t) },
                                                    onMoreClick = { trackActionTarget = t },
                                                    onRemoveFromPlaylist = {
                                                        playlists = PlaylistStore.removeTrack(ctx, openedPl.id, t.url)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            } else {
                                Button(
                                    onClick = {
                                        newPlaylistName = ""
                                        showCreatePlaylistDialog = true
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                                ) {
                                    Icon(Icons.Rounded.PlaylistAdd, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Buat Playlist Baru", fontWeight = FontWeight.SemiBold)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                if (playlists.isEmpty()) {
                                    Box(
                                        modifier = Modifier.fillMaxWidth().weight(1f),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = Icons.Rounded.LibraryMusic,
                                                contentDescription = null,
                                                tint = IosSecondaryLabel.copy(alpha = 0.5f),
                                                modifier = Modifier.size(56.dp)
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text("Belum ada playlist kustom", color = IosSecondaryLabel, fontSize = 14.sp)
                                        }
                                    }
                                } else {
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                        color = cardColor
                                    ) {
                                        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                            itemsIndexed(playlists) { idx, pl ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable { openedPlaylistId = pl.id }
                                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    IosArtwork(
                                                        url = pl.tracks.firstOrNull()?.thumb,
                                                        size = 48.dp,
                                                        cornerRadius = 10.dp,
                                                        showImage = video || !audioSaver
                                                    )
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = pl.name,
                                                            fontSize = 15.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = primaryText
                                                        )
                                                        Text(
                                                            text = "${pl.tracks.size} lagu",
                                                            fontSize = 12.sp,
                                                            color = IosSecondaryLabel
                                                        )
                                                    }
                                                    if (pl.tracks.isNotEmpty()) {
                                                        IconButton(onClick = { playList(pl.tracks, 0) }) {
                                                            Icon(Icons.Rounded.PlayArrow, contentDescription = "Putar", tint = IosAccentRed)
                                                        }
                                                    }
                                                    IconButton(onClick = {
                                                        playlists = PlaylistStore.deletePlaylist(ctx, pl.id)
                                                        Toast.makeText(ctx, "Playlist dihapus", Toast.LENGTH_SHORT).show()
                                                    }) {
                                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus", tint = IosSecondaryLabel)
                                                    }
                                                }
                                                if (idx < playlists.lastIndex) {
                                                    HorizontalDivider(
                                                        modifier = Modifier.padding(start = 74.dp),
                                                        thickness = 0.5.dp,
                                                        color = Color.Gray.copy(alpha = 0.25f)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            // Sub-Tab Backup & Restore (.json)
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = cardColor,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.SaveAlt,
                                            contentDescription = null,
                                            tint = IosAccentRed,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "Cadangkan & Pulihkan Data",
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = primaryText
                                        )
                                    }
                                    Text(
                                        text = "Simpan seluruh daftar Favorit (${favorites.size} lagu) dan Playlist Kustom (${playlists.size} playlist) ke file JSON agar aman saat update aplikasi atau ganti HP.",
                                        fontSize = 13.sp,
                                        color = IosSecondaryLabel,
                                        lineHeight = 18.sp
                                    )
                                    Button(
                                        onClick = {
                                            exportBackupLauncher.launch("StreamPlus_Backup.json")
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                                    ) {
                                        Icon(Icons.Rounded.UploadFile, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Ekspor Backup (.json)", fontWeight = FontWeight.SemiBold)
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Rounded.DownloadForOffline, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Impor / Pulihkan Backup (.json)", fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }

                    // ================= TAB 2: ANTREAN + MODE RADIO (AUTOPLAY) =================
                    else {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = cardColor,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Radio,
                                    contentDescription = null,
                                    tint = IosAccentRed,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Mode Radio (Autoplay Serupa)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = primaryText
                                    )
                                    Text(
                                        text = if (radioLoading) "Mencari rekomendasi lagu serupa…"
                                        else "Otomatis tambah lagu terkait di akhir antrean",
                                        fontSize = 11.sp,
                                        color = IosSecondaryLabel
                                    )
                                }
                                Switch(
                                    checked = autoplayRadio,
                                    onCheckedChange = ::setAutoplayRadio,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = IosAccentRed
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (liveQueue.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Rounded.QueueMusic,
                                        contentDescription = null,
                                        tint = IosSecondaryLabel.copy(alpha = 0.5f),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Antrean pemutaran masih kosong", color = IosSecondaryLabel, fontSize = 14.sp)
                                }
                            }
                        } else {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = cardColor
                            ) {
                                LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                    itemsIndexed(liveQueue) { i, t ->
                                        TrackRowItem(
                                            track = t,
                                            isCurrent = now.mediaId == t.url,
                                            isPlaying = now.mediaId == t.url && now.playing,
                                            isFav = favorites.any { it.url == t.url },
                                            isOffline = t.url in offlineUrls,
                                            isDownloading = downloadingUrl == t.url,
                                            showArtwork = video || !audioSaver,
                                            primaryText = primaryText,
                                            onClick = {
                                                if (c != null && i < c.mediaItemCount) {
                                                    c.seekToDefaultPosition(i)
                                                    c.play()
                                                } else {
                                                    playList(liveQueue, i)
                                                }
                                            },
                                            onToggleFav = { toggleFavorite(t) },
                                            onMoreClick = { trackActionTarget = t }
                                        )
                                        if (i < liveQueue.lastIndex) {
                                            HorizontalDivider(
                                                modifier = Modifier.padding(start = 76.dp),
                                                thickness = 0.5.dp,
                                                color = Color.Gray.copy(alpha = 0.25f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Full Player Sheet dengan Drag-to-Dismiss, Lirik Sinkron & Opsi Lanjutan
            AnimatedVisibility(
                visible = expanded && now.has && c != null,
                enter = slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)
                ),
                exit = slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMedium)
                )
            ) {
                if (c != null) {
                    IosFullPlayer(
                        now = now,
                        c = c,
                        video = video,
                        videoQuality = videoQuality,
                        audioSaver = audioSaver,
                        showArtwork = video || !audioSaver,
                        eqState = eqState,
                        autoplayRadio = autoplayRadio,
                        status = engineStatus,
                        isDark = isDark,
                        isFavorite = isCurrentFavorite,
                        sleepRemainingMin = sleepRemainingMin,
                        onToggleFavorite = { currentTrackObj?.let { toggleFavorite(it) } },
                        onAddToPlaylist = { currentTrackObj?.let { playlistPickerTrack = it } },
                        onExportMusicFolder = { currentTrackObj?.let { exportTrackToMusicFolder(it) } },
                        onMode = ::setMode,
                        onQualityChange = ::setQuality,
                        onAudioSaverChange = ::setAudioSaver,
                        onToggleAutoplay = ::setAutoplayRadio,
                        onSetSleepTimer = { mins ->
                            sleepRemainingMin = mins
                            val msg = if (mins != null) "Sleep timer diatur: $mins menit" else "Sleep timer dimatikan"
                            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                        },
                        onOpenEq = { showEqSheet = true },
                        onClose = { expanded = false }
                    )
                }
            }

            // Equalizer, Loudness & Skip Silence Bottom Sheet
            if (showEqSheet) {
                IosEqualizerSheet(
                    eqState = eqState,
                    isDark = isDark,
                    onUpdateEq = ::updateEqualizer,
                    onDismiss = { showEqSheet = false }
                )
            }

            // Bottom Sheet Aksi per Lagu (Tambah ke Playlist, Simpan ke Musik HP, Bagikan)
            trackActionTarget?.let { target ->
                ModalBottomSheet(
                    onDismissRequest = { trackActionTarget = null },
                    containerColor = cardColor,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = target.title,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryText,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (target.artist.isNotBlank()) {
                            Text(
                                text = target.artist,
                                fontSize = 13.sp,
                                color = IosSecondaryLabel
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))

                        ListItem(
                            headlineContent = { Text("Simpan ke Folder Musik HP (Music/StreamPlus)") },
                            leadingContent = { Icon(Icons.Rounded.LibraryMusic, contentDescription = null, tint = IosAccentRed) },
                            modifier = Modifier.clickable {
                                trackActionTarget = null
                                exportTrackToMusicFolder(target)
                            }
                        )
                        ListItem(
                            headlineContent = { Text("Tambah ke Playlist Kustom") },
                            leadingContent = { Icon(Icons.Rounded.PlaylistAdd, contentDescription = null, tint = IosAccentRed) },
                            modifier = Modifier.clickable {
                                trackActionTarget = null
                                playlistPickerTrack = target
                            }
                        )
                        ListItem(
                            headlineContent = {
                                val isFav = favorites.any { it.url == target.url }
                                Text(if (isFav) "Hapus dari Favorit" else "Simpan ke Favorit (Auto-Offline)")
                            },
                            leadingContent = { Icon(Icons.Rounded.Favorite, contentDescription = null, tint = IosAccentRed) },
                            modifier = Modifier.clickable {
                                trackActionTarget = null
                                toggleFavorite(target)
                            }
                        )
                        ListItem(
                            headlineContent = { Text("Bagikan Tautan") },
                            leadingContent = { Icon(Icons.Rounded.IosShare, contentDescription = null, tint = IosAccentRed) },
                            modifier = Modifier.clickable {
                                trackActionTarget = null
                                shareTrack(ctx, target.url, target.title)
                            }
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                    }
                }
            }

            // Bottom Sheet Pilih Playlist untuk Menambahkan Lagu
            playlistPickerTrack?.let { trackToAdd ->
                ModalBottomSheet(
                    onDismissRequest = { playlistPickerTrack = null },
                    containerColor = cardColor,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Tambahkan ke Playlist",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryText
                        )
                        Button(
                            onClick = {
                                newPlaylistName = ""
                                showCreatePlaylistDialog = true
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Buat Playlist Baru")
                        }
                        if (playlists.isEmpty()) {
                            Text(
                                text = "Belum ada playlist. Ketuk tombol di atas untuk membuat.",
                                color = IosSecondaryLabel,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            playlists.forEach { pl ->
                                ListItem(
                                    headlineContent = { Text(pl.name, fontWeight = FontWeight.SemiBold) },
                                    supportingContent = { Text("${pl.tracks.size} lagu") },
                                    leadingContent = { Icon(Icons.Rounded.QueueMusic, contentDescription = null, tint = IosAccentRed) },
                                    modifier = Modifier.clickable {
                                        playlists = PlaylistStore.addTrack(ctx, pl.id, trackToAdd)
                                        playlistPickerTrack = null
                                        Toast.makeText(ctx, "Ditambahkan ke ${pl.name}", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }

            // Dialog Buat Playlist Baru
            if (showCreatePlaylistDialog) {
                AlertDialog(
                    onDismissRequest = { showCreatePlaylistDialog = false },
                    title = { Text("Playlist Baru") },
                    text = {
                        OutlinedTextField(
                            value = newPlaylistName,
                            onValueChange = { newPlaylistName = it },
                            singleLine = true,
                            placeholder = { Text("Nama playlist (mis. Santai, Perjalanan)") }
                        )
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                val name = newPlaylistName.trim()
                                if (name.isNotEmpty()) {
                                    playlists = PlaylistStore.createPlaylist(ctx, name)
                                    val pending = playlistPickerTrack
                                    if (pending != null) {
                                        val createdId = playlists.firstOrNull()?.id
                                        if (createdId != null) {
                                            playlists = PlaylistStore.addTrack(ctx, createdId, pending)
                                            Toast.makeText(ctx, "Ditambahkan ke $name", Toast.LENGTH_SHORT).show()
                                        }
                                        playlistPickerTrack = null
                                    }
                                }
                                showCreatePlaylistDialog = false
                            }
                        ) {
                            Text("Simpan", color = IosAccentRed, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showCreatePlaylistDialog = false }) {
                            Text("Batal")
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun TrackRowItem(
    track: Track,
    isCurrent: Boolean,
    isPlaying: Boolean,
    isFav: Boolean,
    isOffline: Boolean,
    isDownloading: Boolean,
    showArtwork: Boolean,
    primaryText: Color,
    onClick: () -> Unit,
    onToggleFav: () -> Unit,
    onMoreClick: () -> Unit,
    onRemoveFromPlaylist: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 14.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IosArtwork(url = track.thumb, size = 50.dp, cornerRadius = 8.dp, showImage = showArtwork)
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = if (isCurrent) IosAccentRed else primaryText
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = listOf(
                    track.artist,
                    if (track.durationSec > 0) fmt(track.durationSec * 1000) else ""
                ).filter { it.isNotEmpty() }.joinToString(" • "),
                fontSize = 12.sp,
                color = IosSecondaryLabel,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (isDownloading) {
            CircularProgressIndicator(
                modifier = Modifier
                    .padding(end = 4.dp)
                    .size(15.dp),
                strokeWidth = 2.dp,
                color = IosAccentRed
            )
        } else if (isOffline) {
            Icon(
                imageVector = Icons.Rounded.DownloadDone,
                contentDescription = "Tersimpan Offline",
                tint = Color(0xFF34C759),
                modifier = Modifier
                    .padding(end = 4.dp)
                    .size(17.dp)
            )
        }
        if (isPlaying) {
            Icon(
                imageVector = Icons.Rounded.GraphicEq,
                contentDescription = null,
                tint = IosAccentRed,
                modifier = Modifier.size(18.dp)
            )
        }
        IconButton(onClick = onToggleFav, modifier = Modifier.size(36.dp)) {
            Icon(
                imageVector = if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = "Favorit",
                tint = if (isFav) IosAccentRed else IosSecondaryLabel,
                modifier = Modifier.size(19.dp)
            )
        }
        if (onRemoveFromPlaylist != null) {
            IconButton(onClick = onRemoveFromPlaylist, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Rounded.RemoveCircleOutline,
                    contentDescription = "Keluarkan",
                    tint = IosSecondaryLabel,
                    modifier = Modifier.size(19.dp)
                )
            }
        } else {
            IconButton(onClick = onMoreClick, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    contentDescription = "Menu",
                    tint = IosSecondaryLabel,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    }
}
