@file:OptIn(UnstableApi::class)

package com.streamplus.app

import android.content.Context
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val CMD_SET_QUEUE = "com.streamplus.app.SET_QUEUE"
const val CMD_SET_MODE = "com.streamplus.app.SET_MODE"
const val CMD_SET_QUALITY = "com.streamplus.app.SET_QUALITY"
const val CMD_SET_AUDIO_SAVER = "com.streamplus.app.SET_AUDIO_SAVER"
const val CMD_SET_EQ = "com.streamplus.app.SET_EQ"
const val CMD_SET_AUTOPLAY = "com.streamplus.app.SET_AUTOPLAY"

data class EqState(
    val enabled: Boolean = false,
    val presetName: String = "Normal",
    val bandFreqsHz: List<Int> = listOf(60, 230, 910, 3600, 14000),
    val bandLevelsMb: List<Int> = listOf(0, 0, 0, 0, 0),
    val minLevelMb: Int = -1500,
    val maxLevelMb: Int = 1500,
    val bassStrength: Int = 0,
    val loudnessEnabled: Boolean = false,
    val loudnessGainMb: Int = 600,
    val skipSilence: Boolean = false
)

object PlaybackSettingsStore {
    private const val PREF = "streamplus_prefs"
    val autoplayRadio = MutableStateFlow(true)
    val liveQueue = MutableStateFlow<List<Track>>(emptyList())
    val radioLoading = MutableStateFlow(false)

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        autoplayRadio.value = p.getBoolean("autoplay_radio", true)
    }

    fun setAutoplayRadio(ctx: Context, enabled: Boolean) {
        autoplayRadio.value = enabled
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putBoolean("autoplay_radio", enabled).apply()
    }
}

object EqualizerStore {
    private const val PREF = "streamplus_eq"
    val state = MutableStateFlow(EqState())

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var boundSessionId: Int = C.AUDIO_SESSION_ID_UNSET

    fun loadPrefs(ctx: Context) {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val enabled = p.getBoolean("enabled", false)
        val preset = p.getString("preset", "Normal") ?: "Normal"
        val bass = p.getInt("bass", 0).coerceIn(0, 1000)
        val loudEn = p.getBoolean("loudness_enabled", false)
        val loudGain = p.getInt("loudness_gain", 600).coerceIn(0, 1500)
        val skipSil = p.getBoolean("skip_silence", false)
        val rawLevels = p.getString("levels", null)
        val levels = rawLevels?.split(",")?.mapNotNull { it.toIntOrNull() }?.takeIf { it.isNotEmpty() }
            ?: listOf(0, 0, 0, 0, 0)
        state.value = state.value.copy(
            enabled = enabled,
            presetName = preset,
            bandLevelsMb = levels,
            bassStrength = bass,
            loudnessEnabled = loudEn,
            loudnessGainMb = loudGain,
            skipSilence = skipSil
        )
    }

    fun savePrefs(ctx: Context, s: EqState) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", s.enabled)
            .putString("preset", s.presetName)
            .putInt("bass", s.bassStrength)
            .putBoolean("loudness_enabled", s.loudnessEnabled)
            .putInt("loudness_gain", s.loudnessGainMb)
            .putBoolean("skip_silence", s.skipSilence)
            .putString("levels", s.bandLevelsMb.joinToString(","))
            .apply()
    }

    @Synchronized
    fun attachToSession(ctx: Context, sessionId: Int) {
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        if (boundSessionId != sessionId) {
            release()
            boundSessionId = sessionId
            runCatching {
                val eq = Equalizer(0, sessionId)
                val bands = eq.numberOfBands.toInt().coerceAtLeast(1)
                val range = eq.bandLevelRange
                val minMb = range.getOrNull(0)?.toInt() ?: -1500
                val maxMb = range.getOrNull(1)?.toInt() ?: 1500
                val freqs = (0 until bands).map { b -> (eq.getCenterFreq(b.toShort()) / 1000) }
                val currentLevels = state.value.bandLevelsMb
                val normalizedLevels = (0 until bands).map { b ->
                    (currentLevels.getOrNull(b) ?: 0).coerceIn(minMb, maxMb)
                }
                state.value = state.value.copy(
                    bandFreqsHz = freqs,
                    bandLevelsMb = normalizedLevels,
                    minLevelMb = minMb,
                    maxLevelMb = maxMb
                )
                equalizer = eq
            }
            runCatching {
                bassBoost = BassBoost(0, sessionId)
            }
            runCatching {
                loudnessEnhancer = LoudnessEnhancer(sessionId)
            }
        }
        applyCurrentState(ctx)
    }

    @Synchronized
    fun applyCurrentState(ctx: Context) {
        val s = state.value
        savePrefs(ctx, s)
        if (!s.enabled && !s.loudnessEnabled) {
            release()
            return
        }
        runCatching {
            equalizer?.let { eq ->
                eq.enabled = s.enabled
                val bands = eq.numberOfBands.toInt()
                for (b in 0 until bands) {
                    val lvl = (s.bandLevelsMb.getOrNull(b) ?: 0)
                        .coerceIn(s.minLevelMb, s.maxLevelMb)
                        .toShort()
                    eq.setBandLevel(b.toShort(), lvl)
                }
            }
        }
        runCatching {
            bassBoost?.let { bb ->
                bb.enabled = s.enabled && s.bassStrength > 0
                if (bb.strengthSupported) {
                    bb.setStrength(s.bassStrength.coerceIn(0, 1000).toShort())
                }
            }
        }
        runCatching {
            loudnessEnhancer?.let { le ->
                le.enabled = s.loudnessEnabled
                le.setTargetGain(s.loudnessGainMb.coerceIn(0, 1500))
            }
        }
    }

    @Synchronized
    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { loudnessEnhancer?.release() }
        equalizer = null
        bassBoost = null
        loudnessEnhancer = null
        boundSessionId = C.AUDIO_SESSION_ID_UNSET
    }
}

private object MediaDiskCache {
    @Volatile private var cache: SimpleCache? = null

    @Synchronized
    fun get(ctx: Context): SimpleCache {
        cache?.let { return it }
        val dir = File(ctx.applicationContext.cacheDir, "media_stream_cache")
        val evictor = LeastRecentlyUsedCacheEvictor(150L * 1024L * 1024L)
        val dbProvider = StandaloneDatabaseProvider(ctx.applicationContext)
        return SimpleCache(dir, evictor, dbProvider).also { cache = it }
    }

    @Synchronized
    fun release() {
        runCatching { cache?.release() }
        cache = null
    }
}

/** Pemutar + antrean hidup di service: tetap jalan di background / layar mati. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var exo: ExoPlayer? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var prefetchJob: Job? = null
    private var radioJob: Job? = null

    @Volatile private var audioOnly = true
    @Volatile private var audioSaver = true
    @Volatile private var maxQuality = 720
    private lateinit var msf: DefaultMediaSourceFactory
    private lateinit var msfVideo: DefaultMediaSourceFactory
    @Volatile private var retryId: String? = null

    /** Mode Video: tiap lagu = video-only + audio digabung (MergingMediaSource). */
    private fun toSource(item: MediaItem): MediaSource {
        if (audioOnly) return msf.createMediaSource(item)
        val target = item.localConfiguration?.uri?.getQueryParameter("u")
            ?: return msf.createMediaSource(item)
        // Video tidak lewat disk cache: tidak membebani I/O & tidak menghapus cache audio
        val audioPart = MediaItem.Builder()
            .setUri(Uri.Builder().scheme("yt").authority("r")
                .appendQueryParameter("u", target).appendQueryParameter("k", "a").build())
            .setMediaId(target)
            .build()
        return MergingMediaSource(msfVideo.createMediaSource(item), msfVideo.createMediaSource(audioPart))
    }

    private fun setQueue(p: ExoPlayer, items: List<MediaItem>, idx: Int, pos: Long) {
        if (audioOnly) p.setMediaItems(items, idx, pos)
        else p.setMediaSources(items.map { toSource(it) }, idx, pos)
    }

    private val resolver = object : ResolvingDataSource.Resolver {
        override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
            if (dataSpec.uri.scheme != "yt") return dataSpec
            val target = dataSpec.uri.getQueryParameter("u") ?: return dataSpec

            if (audioOnly) {
                FavoriteDownloader.getOfflineFile(this@PlaybackService, target)?.let { localFile ->
                    Engine.status.value = null
                    return dataSpec.buildUpon()
                        .setUri(Uri.fromFile(localFile))
                        .build()
                }
            }

            FavoriteDownloader.setPlaybackBusy(this@PlaybackService, true)
            if (!audioOnly) {
                val (vUrl, aUrl) = Engine.resolveVideoPair(this@PlaybackService, target, maxQuality)
                val isAudioPart = dataSpec.uri.getQueryParameter("k") == "a"
                val realV = if (isAudioPart) (aUrl ?: vUrl) else vUrl
                return dataSpec.buildUpon()
                    .setUri(Uri.parse(realV))
                    .setKey((if (isAudioPart) "va" else "v$maxQuality") + ":$target")
                    .build()
            }
            val real = Engine.resolve(this@PlaybackService, target, audioOnly, maxQuality, audioSaver)
            val modeTag = when {
                !audioOnly -> "v$maxQuality"
                audioSaver -> "as"
                else -> "an"
            }
            return dataSpec.buildUpon()
                .setUri(Uri.parse(real))
                .setKey("$modeTag:$target")
                .build()
        }
    }

    private fun schedulePrefetchUpcoming() {
        val p = exo ?: return
        val count = p.mediaItemCount
        if (count <= 1) return
        val currentIdx = p.currentMediaItemIndex
        // Resolve = proses yt-dlp (berat). Video/hemat kuota: cukup 1 lagu ke depan.
        val lookahead = if (audioOnly && !audioSaver) listOf(currentIdx + 1, currentIdx + 2) else listOf(currentIdx + 1)
        val upcomingUrls = lookahead
            .filter { it in 0 until count }
            .mapNotNull { idx -> p.getMediaItemAt(idx).mediaId.takeIf { it.startsWith("http") } }
        if (upcomingUrls.isEmpty()) return

        val isAudio = audioOnly
        val qual = maxQuality
        val saver = audioSaver
        prefetchJob?.cancel()
        prefetchJob = serviceScope.launch {
            delay(1200L)
            for (nextUrl in upcomingUrls) {
                Engine.prefetch(this@PlaybackService, nextUrl, isAudio, qual, saver)
            }
        }
    }

    /** Mode Radio / Autoplay: isi antrean otomatis saat lagu terakhir diputar atau selesai. */
    private fun triggerRadioAutoplayIfNeeded(playImmediately: Boolean) {
        val p = exo ?: return
        if (!PlaybackSettingsStore.autoplayRadio.value) return
        if (p.repeatMode != Player.REPEAT_MODE_OFF) return
        if (p.mediaItemCount == 0) return
        if (p.currentMediaItemIndex < p.mediaItemCount - 1) return
        if (radioJob?.isActive == true) return

        val lastItem = p.currentMediaItem ?: return
        val seedTitle = lastItem.mediaMetadata.title?.toString().orEmpty()
        val seedArtist = lastItem.mediaMetadata.artist?.toString().orEmpty()
        val seedQuery = listOf(seedArtist, seedTitle).filter { it.isNotBlank() }.joinToString(" ").trim()
        if (seedQuery.isBlank()) return

        val existingUrls = (0 until p.mediaItemCount).map { p.getMediaItemAt(it).mediaId }.toSet()

        radioJob = serviceScope.launch {
            PlaybackSettingsStore.radioLoading.value = true
            try {
                val candidates = runCatching { Engine.query(this@PlaybackService, "$seedQuery mix", background = true) }
                    .getOrDefault(emptyList())
                    .filter { it.url !in existingUrls }
                    .take(8)
                if (candidates.isEmpty()) return@launch

                withContext(Dispatchers.Main) {
                    val player = exo ?: return@withContext
                    val newMediaItems = candidates.map { t ->
                        MediaItem.Builder()
                            .setUri(ytUri(t.url))
                            .setMediaId(t.url)
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(t.title)
                                    .setArtist(t.artist)
                                    .setArtworkUri(t.thumb?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) })
                                    .build()
                            ).build()
                    }
                    val insertPos = player.mediaItemCount
                    if (audioOnly) player.addMediaItems(newMediaItems)
                    else player.addMediaSources(newMediaItems.map { toSource(it) })
                    PlaybackSettingsStore.liveQueue.value = PlaybackSettingsStore.liveQueue.value + candidates
                    if (playImmediately && player.playbackState == Player.STATE_ENDED && insertPos < player.mediaItemCount) {
                        player.seekToDefaultPosition(insertPos)
                        player.prepare()
                        player.playWhenReady = true
                    }
                    schedulePrefetchUpcoming()
                }
            } finally {
                PlaybackSettingsStore.radioLoading.value = false
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        EqualizerStore.loadPrefs(this)
        PlaybackSettingsStore.init(this)
        FavoriteDownloader.init(this)
        val prefs = getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE)
        audioSaver = prefs.getBoolean("audio_saver", true)

        val upstreamFactory = DefaultDataSource.Factory(this)
        val cacheFactory = CacheDataSource.Factory()
            .setCache(MediaDiskCache.get(this))
            .setUpstreamDataSourceFactory(upstreamFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        val dsFactory = ResolvingDataSource.Factory(cacheFactory, resolver)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 30_000, 1_000, 2_500)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        msf = DefaultMediaSourceFactory(dsFactory)
        msf.setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(1))

        val videoUpstream = DefaultDataSource.Factory(
            this,
            DefaultHttpDataSource.Factory()
                .setConnectTimeoutMs(8_000)
                .setReadTimeoutMs(15_000)
                .setAllowCrossProtocolRedirects(true)
        )
        msfVideo = DefaultMediaSourceFactory(ResolvingDataSource.Factory(videoUpstream, resolver))
        msfVideo.setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(1))

        val player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(msf)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        player.skipSilenceEnabled = EqualizerStore.state.value.skipSilence
        EqualizerStore.attachToSession(this, player.audioSessionId)

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                EqualizerStore.attachToSession(this@PlaybackService, audioSessionId)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                schedulePrefetchUpcoming()
                if (player.currentMediaItemIndex >= player.mediaItemCount - 1) {
                    triggerRadioAutoplayIfNeeded(playImmediately = false)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> FavoriteDownloader.setPlaybackBusy(this@PlaybackService, true)
                    Player.STATE_READY -> {
                        retryId = null
                        FavoriteDownloader.setPlaybackBusy(this@PlaybackService, false)
                        schedulePrefetchUpcoming()
                        if (player.currentMediaItemIndex >= player.mediaItemCount - 1) {
                            triggerRadioAutoplayIfNeeded(playImmediately = false)
                        }
                    }
                    Player.STATE_ENDED -> {
                        FavoriteDownloader.setPlaybackBusy(this@PlaybackService, false)
                        triggerRadioAutoplayIfNeeded(playImmediately = true)
                    }
                    Player.STATE_IDLE -> {
                        FavoriteDownloader.setPlaybackBusy(this@PlaybackService, false)
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val id = player.currentMediaItem?.mediaId
                // URL CDN dapat kedaluwarsa. Coba resolve ulang satu kali untuk item yang sama.
                if (error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS &&
                    !id.isNullOrEmpty() && retryId != id
                ) {
                    retryId = id
                    Engine.invalidate(this@PlaybackService, id)
                    player.seekTo(player.currentMediaItemIndex, player.currentPosition)
                    player.prepare()
                    return
                }

                // Jangan auto-skip: perilaku lama membuat antrean meloncat terus saat
                // stream video gagal. Hentikan pemutaran dan tampilkan penyebab error.
                FavoriteDownloader.setPlaybackBusy(this@PlaybackService, false)
                val detail = error.message?.takeIf { it.isNotBlank() }
                    ?: "Kode error ExoPlayer: ${error.errorCode}"
                Engine.status.value = "Gagal memutar video: ${detail.take(220)}"
                player.playWhenReady = false
            }
        })
        exo = player
        session = MediaSession.Builder(this, player).setCallback(Callback()).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = exo
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        prefetchJob?.cancel()
        radioJob?.cancel()
        serviceScope.cancel()
        EqualizerStore.release()
        session?.release()
        exo?.release()
        MediaDiskCache.release()
        exo = null; session = null
        super.onDestroy()
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession, controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val own = controller.packageName == packageName
            if (!own && !controller.isTrusted) {
                // App asing: hanya kontrol dasar (play/pause/seek); tidak boleh mengganti antrean / perintah kustom
                val limited = MediaSession.ConnectionResult.DEFAULT_PLAYER_COMMANDS.buildUpon()
                    .remove(Player.COMMAND_SET_MEDIA_ITEM)
                    .remove(Player.COMMAND_CHANGE_MEDIA_ITEMS)
                    .build()
                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailablePlayerCommands(limited).build()
            }
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
            if (own) {
                cmds.add(SessionCommand(CMD_SET_QUEUE, Bundle.EMPTY))
                cmds.add(SessionCommand(CMD_SET_MODE, Bundle.EMPTY))
                cmds.add(SessionCommand(CMD_SET_QUALITY, Bundle.EMPTY))
                cmds.add(SessionCommand(CMD_SET_AUDIO_SAVER, Bundle.EMPTY))
                cmds.add(SessionCommand(CMD_SET_EQ, Bundle.EMPTY))
                cmds.add(SessionCommand(CMD_SET_AUTOPLAY, Bundle.EMPTY))
            }
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(cmds.build()).build()
        }

        override fun onCustomCommand(
            session: MediaSession, controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand, args: Bundle
        ): ListenableFuture<SessionResult> {
            if (controller.packageName != packageName) {
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_PERMISSION_DENIED))
            }
            val p = exo ?: return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_UNKNOWN))
            when (customCommand.customAction) {
                CMD_SET_QUEUE -> {
                    val urls = args.getStringArrayList("urls").orEmpty()
                    val titles = args.getStringArrayList("titles").orEmpty()
                    val artists = args.getStringArrayList("artists").orEmpty()
                    val thumbs = args.getStringArrayList("thumbs").orEmpty()
                    val durations = args.getLongArray("durations") ?: LongArray(urls.size)
                    if (urls.isEmpty()) return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_BAD_VALUE))
                    audioOnly = !args.getBoolean("video")
                    if (args.containsKey("quality")) maxQuality = args.getInt("quality", 720)
                    if (args.containsKey("audioSaver")) audioSaver = args.getBoolean("audioSaver", true)
                    val startIdx = args.getInt("start", 0)

                    val trackList = urls.indices.map { i ->
                        Track(
                            url = urls[i],
                            title = titles.getOrNull(i).orEmpty(),
                            artist = artists.getOrNull(i).orEmpty(),
                            durationSec = durations.getOrNull(i) ?: 0L,
                            thumb = thumbs.getOrNull(i)?.takeIf { it.isNotEmpty() }
                        )
                    }
                    PlaybackSettingsStore.liveQueue.value = trackList

                    val items = urls.indices.map { i ->
                        MediaItem.Builder()
                            .setUri(ytUri(urls[i]))
                            .setMediaId(urls[i])
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(titles.getOrNull(i))
                                    .setArtist(artists.getOrNull(i))
                                    .setArtworkUri(thumbs.getOrNull(i)?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) })
                                    .build()
                            ).build()
                    }
                    setQueue(p, items, startIdx, 0L)
                    p.prepare(); p.playWhenReady = true
                    schedulePrefetchUpcoming()
                }
                CMD_SET_MODE -> {
                    audioOnly = !args.getBoolean("video")
                    if (args.containsKey("quality")) maxQuality = args.getInt("quality", 720)
                    if (args.containsKey("audioSaver")) audioSaver = args.getBoolean("audioSaver", true)
                    val n = p.mediaItemCount
                    if (n > 0) {
                        val items = (0 until n).map { p.getMediaItemAt(it) }
                        setQueue(p, items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                        schedulePrefetchUpcoming()
                    }
                }
                CMD_SET_QUALITY -> {
                    maxQuality = args.getInt("quality", 720)
                    if (!audioOnly && p.mediaItemCount > 0) {
                        val items = (0 until p.mediaItemCount).map { p.getMediaItemAt(it) }
                        setQueue(p, items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                        schedulePrefetchUpcoming()
                    }
                }
                CMD_SET_AUDIO_SAVER -> {
                    audioSaver = args.getBoolean("audioSaver", true)
                    getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE)
                        .edit().putBoolean("audio_saver", audioSaver).apply()
                    if (audioOnly && p.mediaItemCount > 0) {
                        val items = (0 until p.mediaItemCount).map { p.getMediaItemAt(it) }
                        setQueue(p, items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                        schedulePrefetchUpcoming()
                    }
                }
                CMD_SET_EQ -> {
                    val enabled = args.getBoolean("enabled", false)
                    val preset = args.getString("preset", "Normal") ?: "Normal"
                    val bass = args.getInt("bass", 0)
                    val levels = args.getIntegerArrayList("levels")?.toList() ?: EqualizerStore.state.value.bandLevelsMb
                    val loudEn = args.getBoolean("loudnessEnabled", EqualizerStore.state.value.loudnessEnabled)
                    val loudGain = args.getInt("loudnessGain", EqualizerStore.state.value.loudnessGainMb)
                    val skipSil = args.getBoolean("skipSilence", EqualizerStore.state.value.skipSilence)
                    EqualizerStore.state.value = EqualizerStore.state.value.copy(
                        enabled = enabled,
                        presetName = preset,
                        bandLevelsMb = levels,
                        bassStrength = bass,
                        loudnessEnabled = loudEn,
                        loudnessGainMb = loudGain,
                        skipSilence = skipSil
                    )
                    p.skipSilenceEnabled = skipSil
                    EqualizerStore.attachToSession(this@PlaybackService, p.audioSessionId)
                }
                CMD_SET_AUTOPLAY -> {
                    val en = args.getBoolean("autoplay", true)
                    PlaybackSettingsStore.setAutoplayRadio(this@PlaybackService, en)
                    if (en && p.currentMediaItemIndex >= p.mediaItemCount - 1) {
                        triggerRadioAutoplayIfNeeded(playImmediately = p.playbackState == Player.STATE_ENDED)
                    }
                }
                else -> return super.onCustomCommand(session, controller, customCommand, args)
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }
}
