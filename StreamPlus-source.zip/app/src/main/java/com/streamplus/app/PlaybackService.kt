package com.streamplus.app

import android.content.Intent
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

const val CMD_PLAY_URLS = "com.streamplus.app.PLAY_URLS"
const val KEY_URLS = "urls"
const val KEY_TITLE = "title"

/** Pemutar hidup di service, jadi tetap jalan saat app ditutup / layar mati. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)   // jeda saat headset dicabut
            .setWakeMode(C.WAKE_MODE_NETWORK)    // jaga CPU + WiFi saat layar mati
            .build()
        session = MediaSession.Builder(this, player).setCallback(Callback()).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    // App di-swipe dari recent: berhenti kalau tidak sedang memutar
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession, controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_PLAY_URLS, Bundle.EMPTY)).build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(cmds).build()
        }

        override fun onCustomCommand(
            session: MediaSession, controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand, args: Bundle
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == CMD_PLAY_URLS) {
                val urls = args.getStringArrayList(KEY_URLS).orEmpty()
                if (urls.isEmpty()) return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_BAD_VALUE))
                val meta = MediaMetadata.Builder().setTitle(args.getString(KEY_TITLE)).build()
                val factory = DefaultMediaSourceFactory(this@PlaybackService)
                val sources = urls.mapIndexed { i, u ->
                    factory.createMediaSource(
                        MediaItem.Builder().setUri(u).apply { if (i == 0) setMediaMetadata(meta) }.build()
                    )
                }
                session.player.setMediaSource(
                    if (sources.size > 1) MergingMediaSource(*sources.toTypedArray()) else sources[0]
                )
                session.player.prepare()
                session.player.playWhenReady = true
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
            }
            return super.onCustomCommand(session, controller, customCommand, args)
        }
    }
}
