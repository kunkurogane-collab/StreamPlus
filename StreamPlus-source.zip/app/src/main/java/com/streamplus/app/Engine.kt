package com.streamplus.app

import android.content.Context
import android.net.Uri
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

data class Track(val url: String, val title: String, val artist: String, val durationSec: Long, val thumb: String?)

/** URI internal: dipecahkan jadi link stream asli saat pemutar butuh (lazy). */
fun ytUri(url: String): Uri =
    Uri.Builder().scheme("yt").authority("r").appendQueryParameter("u", url).build()

object Engine {
    @Volatile private var ready = false
    private val cache = ConcurrentHashMap<String, Pair<String, Long>>()

    @Synchronized
    fun ensureInit(ctx: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(ctx.applicationContext)
        ready = true
    }

    private fun run(req: YoutubeDLRequest): List<String> =
        YoutubeDL.getInstance().execute(request = req, processId = UUID.randomUUID().toString())
            .out.lines().map { it.trim() }.filter { it.isNotEmpty() }

    /** Kata kunci -> hasil pencarian; link (video/playlist) -> daftar track. */
    fun query(ctx: Context, input: String): List<Track> {
        ensureInit(ctx)
        val isUrl = input.startsWith("http")
        val req = YoutubeDLRequest(if (isUrl) input else "ytsearch20:$input").apply {
            addOption("--flat-playlist")
            addOption("--print", "%(id)s\t%(title)s\t%(uploader,channel)s\t%(duration)s\t%(webpage_url,url)s\t%(thumbnail)s")
        }
        return run(req).mapNotNull { line ->
            val f = line.split('\t')
            if (f.size < 6 || !f[4].startsWith("http")) return@mapNotNull null
            val yt = f[4].contains("youtube.com") || f[4].contains("youtu.be")
            val thumb = f[5].takeIf { it.startsWith("http") }
                ?: if (yt) "https://i.ytimg.com/vi/${f[0]}/mqdefault.jpg" else null
            Track(f[4], f[1], f[2].takeIf { it != "NA" } ?: "", f[3].toDoubleOrNull()?.toLong() ?: 0L, thumb)
        }
    }

    /** Link stream langsung. audioOnly = hanya audio (hemat kuota). */
    fun resolve(ctx: Context, url: String, audioOnly: Boolean): String {
        val key = (if (audioOnly) "a:" else "v:") + url
        cache[key]?.let { if (System.currentTimeMillis() - it.second < 4 * 3600_000L) return it.first }
        try {
            ensureInit(ctx)
            val fmt = if (audioOnly) "ba[ext=m4a]/ba/b" else "b[height<=?720]/b"
            val req = YoutubeDLRequest(url).apply {
                addOption("--no-playlist"); addOption("-f", fmt); addOption("--print", "urls")
            }
            val u = run(req).firstOrNull { it.startsWith("http") } ?: throw IOException("Stream tidak ditemukan")
            cache[key] = u to System.currentTimeMillis()
            return u
        } catch (e: IOException) { throw e
        } catch (e: Exception) { throw IOException(e.message ?: "Gagal mengambil stream", e) }
    }

    fun update(ctx: Context): String = try {
        ensureInit(ctx)
        YoutubeDL.getInstance().updateYoutubeDL(
            appContext = ctx, updateChannel = YoutubeDL.UpdateChannel.STABLE
        ).toString()
    } catch (e: Exception) { "Gagal update: ${e.message}" }
}
