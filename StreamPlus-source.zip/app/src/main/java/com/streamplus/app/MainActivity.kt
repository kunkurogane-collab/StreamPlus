package com.streamplus.app

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.style.TextOverflow
import android.Manifest
import android.content.ComponentName
import android.os.Build
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.media3.common.C
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private class Resolved(val title: String, val urls: List<String>)

/** Ambil link stream langsung via yt-dlp. TIDAK ada file yang diunduh. */
private suspend fun resolve(url: String, maxHeight: Int?): Resolved = withContext(Dispatchers.IO) {
    val fmt = if (maxHeight == null) "bv*+ba/b"
    else "bv*[height<=$maxHeight]+ba/b[height<=$maxHeight]/b"
    val req = YoutubeDLRequest(url).apply {
        addOption("--no-playlist")
        addOption("-f", fmt)
        addOption("--print", "%(title)s") // baris 1: judul
        addOption("--print", "urls")      // baris berikutnya: URL video (+ audio)
    }
    val out = YoutubeDL.getInstance()
        .execute(request = req, processId = UUID.randomUUID().toString())
        .out.lines().map { it.trim() }.filter { it.isNotEmpty() }
    val links = out.filter { it.startsWith("http") }
    require(links.isNotEmpty()) { "Tidak ada link stream ditemukan" }
    Resolved(out.firstOrNull { !it.startsWith("http") } ?: url, links.take(2))
}

class MainActivity : ComponentActivity() {
    private var sharedText by mutableStateOf<String?>(null)
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedText = intent.sharedText()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { Screen() } } }
    }

    override fun onStart() {
        super.onStart()
        if (controllerFuture == null) {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerFuture = MediaController.Builder(this, token).buildAsync().also { f ->
                f.addListener({ controller = f.get().also { setVideoEnabled(it, true) } },
                    ContextCompat.getMainExecutor(this))
            }
        } else controller?.let { setVideoEnabled(it, true) }
    }

    // Layar mati / app di background: matikan track video (hemat baterai & kuota), audio lanjut
    override fun onStop() {
        controller?.let { setVideoEnabled(it, false) }
        super.onStop()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }  // service tetap hidup
        controllerFuture = null; controller = null
        super.onDestroy()
    }

    private fun setVideoEnabled(c: MediaController, on: Boolean) {
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !on).build()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        sharedText = intent.sharedText()
    }

    private fun Intent.sharedText() =
        if (action == Intent.ACTION_SEND) getStringExtra(Intent.EXTRA_TEXT) else null

    @Composable
    private fun Screen() {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()

        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        var input by remember { mutableStateOf("") }
        var title by remember { mutableStateOf<String?>(null) }
        var status by remember { mutableStateOf<String?>(null) }
        var loading by remember { mutableStateOf(false) }
        var quality by remember { mutableStateOf<Int?>(720) }
        val qualities = listOf(360 to "360p", 720 to "720p", 1080 to "1080p", null to "Terbaik")

        fun play() {
            val link = input.trim()
            val c = controller
            if (link.isEmpty() || loading) return
            if (c == null) { status = "Pemutar belum siap, coba lagi sebentar."; return }
            loading = true; status = "Mengambil stream…"
            scope.launch {
                runCatching { resolve(link, quality) }
                    .onSuccess { r ->
                        c.sendCustomCommand(
                            SessionCommand(CMD_PLAY_URLS, Bundle.EMPTY),
                            bundleOf(KEY_URLS to ArrayList(r.urls), KEY_TITLE to r.title)
                        )
                        title = r.title; status = null
                    }
                    .onFailure {
                        status = "Gagal: ${it.message?.take(160)}\n(Jika mesin baru dibuka, tunggu sebentar atau tekan Update yt-dlp.)"
                    }
                loading = false
            }
        }

        LaunchedEffect(sharedText, controller) {
            val t = sharedText
            if (t != null && controller != null) { input = t; play(); sharedText = null }
        }

        Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Stream Plus", style = MaterialTheme.typography.headlineSmall)
            AndroidView(
                factory = { PlayerView(it) },
                update = { it.player = controller },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            )
            title?.let { Text(it, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium) }
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                label = { Text("Tempel link video / audio") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                qualities.forEach { (h, label) ->
                    FilterChip(selected = quality == h, onClick = { quality = h }, label = { Text(label) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.primaryClip?.getItemAt(0)?.text?.let { input = it.toString() }
                }) { Text("Tempel") }
                Button(onClick = ::play, enabled = !loading, modifier = Modifier.weight(1f)) {
                    Text(if (loading) "Memuat…" else "Putar")
                }
            }
            TextButton(onClick = {
                status = "Memperbarui yt-dlp…"
                scope.launch {
                    val msg = withContext(Dispatchers.IO) {
                        runCatching {
                            YoutubeDL.getInstance().updateYoutubeDL(
                                appContext = ctx, updateChannel = YoutubeDL.UpdateChannel.STABLE
                            ).toString()
                        }.getOrElse { "Gagal update: ${it.message}" }
                    }
                    status = "yt-dlp: $msg"
                }
            }) { Text("Update yt-dlp") }
            status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
