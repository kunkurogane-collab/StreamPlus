package com.streamplus.app

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class Now(
    val title: String = "", val artist: String = "", val art: String? = null,
    val playing: Boolean = false, val has: Boolean = false, val durationMs: Long = 0L
)

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun rememberNow(c: MediaController?): Now {
    var now by remember { mutableStateOf(Now()) }
    DisposableEffect(c) {
        if (c == null) {
            onDispose { }
        } else {
            fun upd() {
                now = Now(
                    title = c.mediaMetadata.title?.toString().orEmpty(),
                    artist = c.mediaMetadata.artist?.toString().orEmpty(),
                    art = c.mediaMetadata.artworkUri?.toString(),
                    playing = c.isPlaying || (c.playWhenReady && c.playbackState == Player.STATE_BUFFERING),
                    has = c.mediaItemCount > 0,
                    durationMs = c.duration.coerceAtLeast(0L)
                )
            }
            val l = object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = upd()
            }
            c.addListener(l); upd()
            onDispose { c.removeListener(l) }
        }
    }
    return now
}

@Composable
private fun Thumb(url: String?, size: Dp) {
    AsyncImage(
        model = url, contentDescription = null, contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(RoundedCornerShape(6.dp)).background(Color(0xFF2A2A2A))
    )
}

@Composable
private fun ModeChips(video: Boolean, onMode: (Boolean) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = !video, onClick = { onMode(false) }, label = { Text("Audio") })
        FilterChip(selected = video, onClick = { onMode(true) }, label = { Text("Video") })
    }
}

@Composable
private fun MiniPlayer(now: Now, c: MediaController, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onOpen).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(now.art, 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(now.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
            Text(now.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        }
        TextButton(onClick = { if (c.isPlaying) c.pause() else c.play() }) {
            Text(if (now.playing) "⏸" else "▶", fontSize = 22.sp)
        }
        TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭", fontSize = 22.sp) }
    }
}

@Composable
private fun FullPlayer(
    now: Now, c: MediaController, video: Boolean, onMode: (Boolean) -> Unit, onClose: () -> Unit
) {
    BackHandler(onBack = onClose)
    var pos by remember { mutableStateOf(0L) }
    var seeking by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(c) { while (true) { pos = c.currentPosition.coerceAtLeast(0L); delay(500) } }
    val dur = now.durationMs.coerceAtLeast(1L)

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Tutup") }
            Spacer(Modifier.weight(1f))
            ModeChips(video, onMode)
        }
        Box(Modifier.fillMaxWidth().aspectRatio(if (video) 16f / 9f else 1f).clip(RoundedCornerShape(12.dp))) {
            if (video) {
                AndroidView(
                    factory = { PlayerView(it).apply { useController = false } },
                    update = { it.player = c },
                    onRelease = { it.player = null },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                AsyncImage(
                    model = now.art, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().background(Color(0xFF2A2A2A))
                )
            }
        }
        Text(now.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleLarge)
        Text(now.artist, maxLines = 1, style = MaterialTheme.typography.bodyMedium)
        Slider(
            value = (seeking ?: (pos.toFloat() / dur)).coerceIn(0f, 1f),
            onValueChange = { seeking = it },
            onValueChangeFinished = { seeking?.let { c.seekTo((it * dur).toLong()) }; seeking = null }
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(pos), style = MaterialTheme.typography.bodySmall)
            Text(fmt(now.durationMs), style = MaterialTheme.typography.bodySmall)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { c.seekToPrevious() }) { Text("⏮", fontSize = 32.sp) }
            TextButton(onClick = { if (c.isPlaying) c.pause() else c.play() }) {
                Text(if (now.playing) "⏸" else "▶", fontSize = 44.sp)
            }
            TextButton(onClick = { c.seekToNextMediaItem() }) { Text("⏭", fontSize = 32.sp) }
        }
    }
}

class MainActivity : ComponentActivity() {
    private var sharedText by mutableStateOf<String?>(null)
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedText = intent.sharedText()
        val scheme = darkColorScheme(
            primary = Color(0xFFFF3B3B), background = Color(0xFF0F0F0F),
            surface = Color(0xFF0F0F0F), surfaceVariant = Color(0xFF212121)
        )
        setContent { MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { App() } } }
    }

    override fun onStart() {
        super.onStart()
        if (controllerFuture == null) {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerFuture = MediaController.Builder(this, token).buildAsync().also { f ->
                f.addListener({ controller = f.get().also { setVideo(it, true) } }, ContextCompat.getMainExecutor(this))
            }
        } else controller?.let { setVideo(it, true) }
    }

    // App di background / layar mati: track video dimatikan, audio lanjut
    override fun onStop() {
        controller?.let { setVideo(it, false) }
        super.onStop()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null; controller = null
        super.onDestroy()
    }

    private fun setVideo(c: MediaController, on: Boolean) {
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !on).build()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        sharedText = intent.sharedText()
    }

    private fun Intent.sharedText() =
        if (action == Intent.ACTION_SEND) getStringExtra(Intent.EXTRA_TEXT) else null

    @Composable
    private fun App() {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()
        val focus = LocalFocusManager.current
        val c = controller
        val now = rememberNow(c)

        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        var query by remember { mutableStateOf("") }
        var results by remember { mutableStateOf<List<Track>>(emptyList()) }
        var loading by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf<String?>(null) }
        var video by remember { mutableStateOf(false) }
        var expanded by remember { mutableStateOf(false) }

        fun play(i: Int) {
            val ctrl = controller ?: run { message = "Pemutar belum siap, coba lagi sebentar."; return }
            val args = Bundle().apply {
                putStringArrayList("urls", ArrayList(results.map { it.url }))
                putStringArrayList("titles", ArrayList(results.map { it.title }))
                putStringArrayList("artists", ArrayList(results.map { it.artist }))
                putStringArrayList("thumbs", ArrayList(results.map { it.thumb.orEmpty() }))
                putInt("start", i)
                putBoolean("video", video)
            }
            ctrl.sendCustomCommand(SessionCommand(CMD_SET_QUEUE, Bundle.EMPTY), args)
        }

        fun search(text: String = query, autoPlay: Boolean = false) {
            val q = text.trim()
            if (q.isEmpty() || loading) return
            focus.clearFocus()
            loading = true; message = null
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { Engine.query(ctx, q) } }
                    .onSuccess {
                        results = it
                        if (it.isEmpty()) message = "Tidak ada hasil"
                        else if (autoPlay) play(0)
                    }
                    .onFailure {
                        message = "Gagal: ${it.message?.take(160)}\n(Jika baru dibuka, tunggu sebentar lalu coba lagi.)"
                    }
                loading = false
            }
        }

        fun setMode(v: Boolean) {
            video = v
            controller?.sendCustomCommand(
                SessionCommand(CMD_SET_MODE, Bundle.EMPTY), Bundle().apply { putBoolean("video", v) }
            )
        }

        LaunchedEffect(sharedText) {
            val link = sharedText?.let { Regex("https?://\\S+").find(it)?.value }
            if (link != null) { query = link; search(link, autoPlay = true); sharedText = null }
        }

        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        placeholder = { Text("Cari lagu, video, atau tempel link") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { search(autoPlay = query.startsWith("http")) }),
                        trailingIcon = {
                            IconButton(onClick = { search(autoPlay = query.startsWith("http")) }) {
                                Icon(Icons.Filled.Search, contentDescription = "Cari")
                            }
                        }
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ModeChips(video, ::setMode)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = {
                            message = "Memperbarui yt-dlp…"
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { Engine.update(ctx) }
                                message = "yt-dlp: $r"
                            }
                        }) { Icon(Icons.Filled.Refresh, contentDescription = "Update yt-dlp") }
                    }
                }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                message?.let { Text(it, Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall) }

                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    itemsIndexed(results) { i, t ->
                        Row(
                            Modifier.fillMaxWidth().clickable { play(i) }.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Thumb(t.thumb, 56.dp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(t.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    listOf(t.artist, if (t.durationSec > 0) fmt(t.durationSec * 1000) else "")
                                        .filter { it.isNotEmpty() }.joinToString(" • "),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
                if (now.has && c != null) {
                    Box(Modifier.navigationBarsPadding()) { MiniPlayer(now, c) { expanded = true } }
                } else Spacer(Modifier.navigationBarsPadding())
            }
            if (expanded && now.has && c != null) {
                FullPlayer(now, c, video, ::setMode) { expanded = false }
            }
        }
    }
}
