package com.streamplus.app

import android.app.Application
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class StreamApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Inisialisasi yt-dlp di background (pertama kali agak lama)
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { YoutubeDL.getInstance().init(this@StreamApp) }
        }
    }
}
