# Stream Plus
Pemutar stream-only (yt-dlp + Media3). Tidak menyimpan file apa pun.

- Pemutaran **background** & saat **layar mati** (foreground service + notifikasi/kontrol layar kunci)
- Track video otomatis dimatikan saat app di background (hemat baterai & kuota), audio lanjut
- Pilihan kualitas, Share link dari app lain, Update yt-dlp

## Build di GitHub
1. Upload isi folder ini ke repo GitHub (branch `main`).
2. Tab **Actions** → *Build APK* → **Run workflow** (atau otomatis tiap push).
3. Unduh APK di **Artifacts → StreamPlus-apk**.
4. Ingin rilis di tab Releases? Run workflow lalu centang **release**.

Tanpa secret → APK debug (bisa langsung diinstal).
Untuk APK release bertanda tangan, isi Secrets: `ANDROID_SIGNING_KEY` (keystore base64),
`ANDROID_KEYSTORE_PASSWORD`, `ANDROID_ALIAS`, `ANDROID_KEY_PASSWORD`.

## Build lokal
Android Studio (JDK 17+) → Sync → Run, atau `./gradlew assembleDebug`.
