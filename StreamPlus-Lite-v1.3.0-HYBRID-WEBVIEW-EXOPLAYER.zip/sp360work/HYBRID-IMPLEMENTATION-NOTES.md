# StreamPlus Lite 1.3.0 — Hybrid playback

## Perubahan awal
- Video YouTube saat mode Video dan seluruh antrean berisi URL YouTube diarahkan ke YouTube IFrame Player resmi di WebView.
- Media non-YouTube/direct media tetap menggunakan jalur Media3 ExoPlayer + resolver yang sudah ada.
- Mode Audio HD dan Audio Hemat Kuota tidak diubah.
- Default kualitas 360p pada jalur ExoPlayer tidak diubah.
- Activity WebView menangani fullscreen melalui WebChromeClient dan tombol kembali Android.
- Antrean YouTube mendukung tombol sebelumnya/berikutnya dan lanjut otomatis ketika video selesai.

## Batasan yang perlu diuji
- YouTube embed dapat menolak video tertentu, video privat/terbatas, atau video yang tidak mengizinkan embedding.
- Kualitas dan pemilihan resolusi pada embed dikelola oleh YouTube Player, bukan pengaturan 360p aplikasi.
- WebView membutuhkan koneksi internet aktif dan komponen Android System WebView/Chrome yang berfungsi.
- Antrean campuran YouTube dan media langsung tetap memakai jalur ExoPlayer lama; antrean tersebut tidak otomatis berpindah antar-engine.

## Pengujian wajib sebelum rilis
1. Build `:app:assembleDebug` di GitHub Actions.
2. Mode Video: buka video YouTube publik yang mengizinkan embed; pastikan audio/video berjalan.
3. Uji tombol fullscreen, rotasi landscape, tombol kembali, dan antrean berikut/sebelumnya.
4. Uji video yang menolak embed; aplikasi harus menampilkan pesan, bukan macet atau melompat tanpa penjelasan.
5. Mode media langsung: pastikan tetap menggunakan ExoPlayer.
6. Audio HD dan Audio Hemat Kuota: uji keduanya untuk memastikan tidak regresi.
7. Periksa thumbnail dan jumlah views di hasil pencarian.

Status: ZIP sumber dibuat dan diperiksa integritasnya. Build Gradle belum terverifikasi di lingkungan ini karena Gradle Wrapper memerlukan unduhan `services.gradle.org`, yang tidak dapat dijangkau dari sesi ini.
