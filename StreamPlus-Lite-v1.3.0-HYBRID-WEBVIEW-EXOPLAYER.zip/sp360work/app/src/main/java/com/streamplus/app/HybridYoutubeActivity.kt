package com.streamplus.app

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import org.json.JSONArray
import org.json.JSONObject

/** YouTube playback through the official YouTube IFrame player embedded in WebView. */
class HybridYoutubeActivity : ComponentActivity() {
    private var webView: WebView? = null
    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var originalOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = AndroidColor.BLACK
        window.navigationBarColor = AndroidColor.BLACK
        window.decorView.keepScreenOn = true

        val urls = intent.getStringArrayListExtra(EXTRA_URLS).orEmpty()
        val titles = intent.getStringArrayListExtra(EXTRA_TITLES).orEmpty()
        val start = intent.getIntExtra(EXTRA_START, 0).coerceIn(0, (urls.size - 1).coerceAtLeast(0))
        val tracks = urls.mapIndexedNotNull { index, url ->
            val id = youtubeId(url) ?: return@mapIndexedNotNull null
            JSONObject().put("id", id).put("title", titles.getOrNull(index).orEmpty())
        }
        if (tracks.isEmpty()) {
            Toast.makeText(this, "Tautan YouTube tidak valid", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val startId = urls.take(start).count { youtubeId(it) != null }.coerceIn(0, tracks.lastIndex)

        val root = FrameLayout(this).apply { setBackgroundColor(AndroidColor.BLACK) }
        val web = WebView(this)
        web.setBackgroundColor(AndroidColor.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.settings.loadsImagesAutomatically = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) Toast.makeText(this@HybridYoutubeActivity, "Gagal memuat pemutar: ${error.description}", Toast.LENGTH_LONG).show()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (fullscreenView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                originalOrientation = requestedOrientation
                fullscreenView = view
                fullscreenCallback = callback
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                web.visibility = View.GONE
            }

            override fun onHideCustomView() {
                val view = fullscreenView ?: return
                root.removeView(view)
                fullscreenView = null
                fullscreenCallback?.onCustomViewHidden()
                fullscreenCallback = null
                requestedOrientation = originalOrientation
                web.visibility = View.VISIBLE
            }
        }
        webView = web
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        web.loadDataWithBaseURL("https://streamplus.local/", buildPlayerHtml(tracks, startId), "text/html", "UTF-8", null)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (fullscreenView != null) {
                    val view = fullscreenView
                    if (view != null) root.removeView(view)
                    fullscreenView = null
                    fullscreenCallback?.onCustomViewHidden()
                    fullscreenCallback = null
                    requestedOrientation = originalOrientation
                    web.visibility = View.VISIBLE
                } else finish()
            }
        })
    }

    override fun onDestroy() {
        webView?.apply {
            stopLoading()
            loadUrl("about:blank")
            webChromeClient = null
            webViewClient = null
            removeAllViews()
            destroy()
        }
        webView = null
        super.onDestroy()
    }

    private fun buildPlayerHtml(tracks: List<JSONObject>, start: Int): String {
        val json = JSONArray(tracks).toString()
        return """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
            <meta name="referrer" content="strict-origin-when-cross-origin"><style>
            *{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;background:#000;color:#fff;font-family:Arial,sans-serif;overflow:hidden}
            #top{height:48px;display:flex;align-items:center;gap:12px;padding:0 14px;background:#101010}
            #top button{border:0;border-radius:8px;background:#292929;color:#fff;padding:8px 13px;font-size:16px}
            #title{font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}
            #frame{position:absolute;top:48px;left:0;width:100%;height:calc(100% - 48px);background:#000}
            #player{width:100%;height:100%}#status{position:absolute;bottom:8px;left:10px;right:10px;color:#bbb;font-size:11px;text-align:center;pointer-events:none}
            </style></head><body>
            <div id="top"><button onclick="prev()">‹</button><div id="title">Memuat video…</div><button onclick="next()">›</button></div>
            <div id="frame"><div id="player"></div></div><div id="status">Pemutar YouTube resmi</div>
            <script>
            const tracks=$json; let index=$start; let player=null;
            function setTitle(){document.getElementById('title').textContent=(index+1)+'/'+tracks.length+' · '+(tracks[index].title||'Video YouTube');}
            function load(i){index=(i+tracks.length)%tracks.length;setTitle();if(player)player.loadVideoById(tracks[index].id);}
            function prev(){load(index-1)} function next(){load(index+1)}
            function onYouTubeIframeAPIReady(){player=new YT.Player('player',{width:'100%',height:'100%',videoId:tracks[index].id,playerVars:{autoplay:1,controls:1,rel:0,playsinline:0,fs:1,enablejsapi:1,origin:location.origin},events:{onReady:function(e){e.target.playVideo();document.getElementById('status').textContent='';},onError:function(e){document.getElementById('status').textContent='Video ini tidak dapat diputar melalui embed (kode '+e.data+'). Kembali dan pilih video lain.';},onStateChange:function(e){if(e.data===0 && tracks.length>1)next();}}});}
            setTitle();let s=document.createElement('script');s.src='https://www.youtube.com/iframe_api';document.head.appendChild(s);
            </script></body></html>
        """.trimIndent()
    }

    private fun youtubeId(value: String): String? = runCatching {
        val uri = android.net.Uri.parse(value)
        val host = (uri.host ?: "").lowercase()
        val id = when {
            host == "youtu.be" -> uri.pathSegments.firstOrNull()
            host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com") -> when {
                uri.path?.startsWith("/shorts/") == true -> uri.pathSegments.getOrNull(1)
                uri.path?.startsWith("/embed/") == true -> uri.pathSegments.getOrNull(1)
                uri.path?.startsWith("/live/") == true -> uri.pathSegments.getOrNull(1)
                else -> uri.getQueryParameter("v")
            }
            else -> null
        }
        id?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
    }.getOrNull()

    companion object {
        const val EXTRA_URLS = "hybrid_urls"
        const val EXTRA_TITLES = "hybrid_titles"
        const val EXTRA_START = "hybrid_start"
    }
}
