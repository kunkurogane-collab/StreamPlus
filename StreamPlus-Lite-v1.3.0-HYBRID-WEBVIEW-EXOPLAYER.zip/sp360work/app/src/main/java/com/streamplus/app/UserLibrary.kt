package com.streamplus.app

import android.content.Context
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

data class CustomPlaylist(
    val id: String,
    val name: String,
    val tracks: List<Track>
)

private fun Track.toJson(): JSONObject = JSONObject().apply {
    put("url", url)
    put("title", title)
    put("artist", artist)
    put("durationSec", durationSec)
    put("thumb", thumb.orEmpty())
}

private fun jsonToTrack(obj: JSONObject): Track? {
    val url = obj.optString("url")
    if (url.isBlank()) return null
    return Track(
        url = url,
        title = obj.optString("title"),
        artist = obj.optString("artist"),
        durationSec = obj.optLong("durationSec", 0L),
        thumb = obj.optString("thumb").takeIf { it.isNotBlank() }
    )
}

object RecentlyPlayedStore {
    private const val PREF = "streamplus_history"
    private const val KEY = "recent_json"
    private const val MAX_ITEMS = 40

    fun load(ctx: Context): List<Track> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let(::jsonToTrack) }
        }.getOrDefault(emptyList())
    }

    fun record(ctx: Context, track: Track): List<Track> {
        if (track.url.isBlank()) return load(ctx)
        val current = load(ctx)
        val updated = (listOf(track) + current.filterNot { it.url == track.url }).take(MAX_ITEMS)
        val arr = JSONArray()
        updated.forEach { arr.put(it.toJson()) }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
        return updated
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}

object PlaylistStore {
    private const val PREF = "streamplus_playlists"
    private const val KEY = "playlists_json"

    fun load(ctx: Context): List<CustomPlaylist> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                val id = obj.optString("id").ifBlank { UUID.randomUUID().toString() }
                val name = obj.optString("name").ifBlank { "Playlist" }
                val tracksArr = obj.optJSONArray("tracks") ?: JSONArray()
                val tracks = (0 until tracksArr.length()).mapNotNull { j ->
                    tracksArr.optJSONObject(j)?.let(::jsonToTrack)
                }
                CustomPlaylist(id, name, tracks)
            }
        }.getOrDefault(emptyList())
    }

    fun save(ctx: Context, playlists: List<CustomPlaylist>) {
        val arr = JSONArray()
        playlists.forEach { pl ->
            val tArr = JSONArray()
            pl.tracks.forEach { tArr.put(it.toJson()) }
            arr.put(JSONObject().apply {
                put("id", pl.id)
                put("name", pl.name)
                put("tracks", tArr)
            })
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun createPlaylist(ctx: Context, name: String): List<CustomPlaylist> {
        val clean = name.trim()
        if (clean.isEmpty()) return load(ctx)
        val updated = listOf(CustomPlaylist(UUID.randomUUID().toString(), clean, emptyList())) + load(ctx)
        save(ctx, updated)
        return updated
    }

    fun deletePlaylist(ctx: Context, playlistId: String): List<CustomPlaylist> {
        val updated = load(ctx).filterNot { it.id == playlistId }
        save(ctx, updated)
        return updated
    }

    fun addTrack(ctx: Context, playlistId: String, track: Track): List<CustomPlaylist> {
        val updated = load(ctx).map { pl ->
            if (pl.id != playlistId) pl
            else if (pl.tracks.any { it.url == track.url }) pl
            else pl.copy(tracks = pl.tracks + track)
        }
        save(ctx, updated)
        return updated
    }

    fun removeTrack(ctx: Context, playlistId: String, trackUrl: String): List<CustomPlaylist> {
        val updated = load(ctx).map { pl ->
            if (pl.id != playlistId) pl
            else pl.copy(tracks = pl.tracks.filterNot { it.url == trackUrl })
        }
        save(ctx, updated)
        return updated
    }
}

object LibraryBackupManager {
    fun exportJson(favorites: List<Track>, playlists: List<CustomPlaylist>): String {
        val root = JSONObject()
        root.put("app", "StreamPlus")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val favArr = JSONArray()
        favorites.forEach { favArr.put(it.toJson()) }
        root.put("favorites", favArr)

        val plArr = JSONArray()
        playlists.forEach { pl ->
            val tArr = JSONArray()
            pl.tracks.forEach { tArr.put(it.toJson()) }
            plArr.put(JSONObject().apply {
                put("id", pl.id)
                put("name", pl.name)
                put("tracks", tArr)
            })
        }
        root.put("playlists", plArr)
        return root.toString(2)
    }

    fun importJson(
        currentFavorites: List<Track>,
        currentPlaylists: List<CustomPlaylist>,
        rawJson: String
    ): Triple<List<Track>, List<CustomPlaylist>, Pair<Int, Int>> {
        val root = JSONObject(rawJson)
        val favArr = root.optJSONArray("favorites") ?: JSONArray()
        val importedFavs = (0 until favArr.length()).mapNotNull { i ->
            favArr.optJSONObject(i)?.let(::jsonToTrack)
        }
        val existingFavUrls = currentFavorites.map { it.url }.toSet()
        val newFavs = importedFavs.filterNot { it.url in existingFavUrls }
        val mergedFavs = currentFavorites + newFavs

        val plArr = root.optJSONArray("playlists") ?: JSONArray()
        val importedPls = (0 until plArr.length()).mapNotNull { i ->
            val obj = plArr.optJSONObject(i) ?: return@mapNotNull null
            val id = obj.optString("id").ifBlank { UUID.randomUUID().toString() }
            val name = obj.optString("name").ifBlank { "Playlist" }
            val tArr = obj.optJSONArray("tracks") ?: JSONArray()
            val tracks = (0 until tArr.length()).mapNotNull { j ->
                tArr.optJSONObject(j)?.let(::jsonToTrack)
            }
            CustomPlaylist(id, name, tracks)
        }

        val existingPlNames = currentPlaylists.map { it.name.lowercase() }.toSet()
        val newPls = importedPls.filterNot { it.name.lowercase() in existingPlNames }
        val mergedPls = currentPlaylists + newPls

        return Triple(mergedFavs, mergedPls, newFavs.size to newPls.size)
    }
}
