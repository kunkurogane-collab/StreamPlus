package com.streamplus.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class StreamApp : Application(), ImageLoaderFactory {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        appScope.launch {
            runCatching { Engine.ensureInit(this@StreamApp) }
            // Tunda autoUpdate 8 detik agar startup awal & render UI langsung ringan
            delay(8_000L)
            runCatching { Engine.autoUpdate(this@StreamApp) }
        }
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.10) // Batasi RAM cache thumbnail maksimal 10%
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(cacheDir, "image_thumb_cache"))
                    .maxSizeBytes(25L * 1024L * 1024L) // Maksimal 25 MB cache gambar
                    .build()
            }
            .crossfade(false)
            .build()
    }
}
