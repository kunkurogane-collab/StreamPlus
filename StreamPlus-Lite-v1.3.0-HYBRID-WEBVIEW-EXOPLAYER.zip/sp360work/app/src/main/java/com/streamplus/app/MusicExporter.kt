package com.streamplus.app

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object MusicExporter {
    private fun detectFormat(file: File): Pair<String, String> {
        val header = ByteArray(12)
        runCatching {
            FileInputStream(file).use { it.read(header) }
        }
        val ascii4to8 = String(header.sliceArray(4..7), Charsets.US_ASCII)
        return when {
            ascii4to8 == "ftyp" -> "m4a" to "audio/mp4"
            header[0] == 0x1A.toByte() && header[1] == 0x45.toByte() -> "webm" to "audio/webm"
            String(header.sliceArray(0..3), Charsets.US_ASCII) == "OggS" -> "ogg" to "audio/ogg"
            else -> "m4a" to "audio/mp4"
        }
    }

    private fun sanitizeFileName(raw: String): String =
        raw.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(80)
            .ifBlank { "StreamPlus_Audio" }

    fun exportTrackToPublicMusic(ctx: Context, track: Track): Result<String> = runCatching {
        val appCtx = ctx.applicationContext
        val sourceFile = FavoriteDownloader.ensureDownloadedNow(appCtx, track.url)
            ?: error("Gagal mengunduh file audio untuk diekspor")

        val (ext, mime) = detectFormat(sourceFile)
        val baseTitle = listOf(track.title, track.artist)
            .filter { it.isNotBlank() }
            .joinToString(" - ")
        val fileName = "${sanitizeFileName(baseTitle)}.$ext"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = appCtx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Audio.Media.TITLE, track.title.ifBlank { fileName })
                put(MediaStore.Audio.Media.ARTIST, track.artist.ifBlank { "StreamPlus" })
                put(MediaStore.Audio.Media.MIME_TYPE, mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/StreamPlus")
                put(MediaStore.Audio.Media.IS_MUSIC, 1)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Gagal membuat entri MediaStore")
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(sourceFile).use { inp -> inp.copyTo(out) }
            } ?: error("Gagal menulis file ke folder Musik")

            values.clear()
            values.put(MediaStore.Audio.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "Tersimpan di Music/StreamPlus/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val musicRoot = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            val targetDir = File(musicRoot, "StreamPlus").apply { if (!exists()) mkdirs() }
            val outFile = File(targetDir, fileName)
            FileInputStream(sourceFile).use { inp ->
                FileOutputStream(outFile).use { out -> inp.copyTo(out) }
            }
            MediaScannerConnection.scanFile(appCtx, arrayOf(outFile.absolutePath), arrayOf(mime), null)
            "Tersimpan di Music/StreamPlus/$fileName"
        }
    }
}
