package com.streamplus.app

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONArray
import org.json.JSONObject

data class LyricLine(val timeMs: Long, val text: String)

data class LyricsResult(
    val synced: List<LyricLine>,
    val plain: String?,
    val trackName: String,
    val artistName: String
)

object LyricsClient {
    private val cache = ConcurrentHashMap<String, LyricsResult>()
    private val notFoundCache = ConcurrentHashMap<String, Long>()

    private fun cleanMetadata(rawTitle: String, rawArtist: String): Pair<String, String> {
        var title = rawTitle
            .replace(Regex("\\([^)]*(official|video|audio|lyrics|lirik|mv|hd|4k|live|remix|cover)[^)]*\\)", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\[[^\\]]*(official|video|audio|lyrics|lirik|mv|hd|4k|live|remix|cover)[^\\]]*\\]", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s+"), " ")
            .trim()

        var artist = rawArtist
            .replace(Regex("\\s*-\\s*Topic$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("VEVO$", RegexOption.IGNORE_CASE), "")
            .trim()

        if (title.contains(" - ")) {
            val parts = title.split(" - ", limit = 2)
            if (parts[0].isNotBlank() && parts[1].isNotBlank()) {
                artist = parts[0].trim()
                title = parts[1].trim()
            }
        }
        return artist to title
    }

    fun fetchLyrics(rawTitle: String, rawArtist: String, durationSec: Long): LyricsResult? {
        if (rawTitle.isBlank()) return null
        val key = "${rawTitle.lowercase()}|${rawArtist.lowercase()}"
        cache[key]?.let { return it }
        notFoundCache[key]?.let { ts ->
            if (System.currentTimeMillis() - ts < 10 * 60_000L) return null
        }

        val (artist, title) = cleanMetadata(rawTitle, rawArtist)
        val encTitle = URLEncoder.encode(title, "UTF-8")
        val encArtist = URLEncoder.encode(artist, "UTF-8")

        // 1. Coba endpoint exact match /api/get
        val getUrl = buildString {
            append("https://lrclib.net/api/get?track_name=").append(encTitle)
            if (artist.isNotBlank()) append("&artist_name=").append(encArtist)
            if (durationSec > 0) append("&duration=").append(durationSec)
        }
        val direct = runCatching { parseObjectResponse(httpGet(getUrl)) }.getOrNull()
        if (direct != null) {
            cache[key] = direct
            return direct
        }

        // 2. Fallback ke /api/search
        val q = URLEncoder.encode(listOf(artist, title).filter { it.isNotBlank() }.joinToString(" "), "UTF-8")
        val searchUrl = "https://lrclib.net/api/search?q=$q"
        val searched = runCatching { parseArrayResponse(httpGet(searchUrl)) }.getOrNull()
        if (searched != null) {
            cache[key] = searched
            return searched
        }

        notFoundCache[key] = System.currentTimeMillis()
        return null
    }

    private fun httpGet(urlStr: String): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8_000
            readTimeout = 8_000
            setRequestProperty("User-Agent", "StreamPlus/1.3 (Android)")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            if (conn.responseCode !in 200..299) ""
            else conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parseObjectResponse(raw: String): LyricsResult? {
        if (raw.isBlank()) return null
        val obj = JSONObject(raw)
        return jsonToLyricsResult(obj)
    }

    private fun parseArrayResponse(raw: String): LyricsResult? {
        if (raw.isBlank()) return null
        val arr = JSONArray(raw)
        var fallbackPlain: LyricsResult? = null
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val res = jsonToLyricsResult(obj) ?: continue
            if (res.synced.isNotEmpty()) return res
            if (fallbackPlain == null) fallbackPlain = res
        }
        return fallbackPlain
    }

    private fun jsonToLyricsResult(obj: JSONObject): LyricsResult? {
        val syncedRaw = obj.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
        val plainRaw = obj.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
        val syncedLines = if (syncedRaw != null) parseLrc(syncedRaw) else emptyList()
        if (syncedLines.isEmpty() && plainRaw.isNullOrBlank()) return null
        return LyricsResult(
            synced = syncedLines,
            plain = plainRaw,
            trackName = obj.optString("trackName"),
            artistName = obj.optString("artistName")
        )
    }

    private fun parseLrc(lrc: String): List<LyricLine> {
        val regex = Regex("^\\[(\\d{1,3}):(\\d{2})(?:\\.(\\d{1,3}))?\\](.*)$")
        val list = mutableListOf<LyricLine>()
        for (rawLine in lrc.lines()) {
            val m = regex.find(rawLine.trim()) ?: continue
            val min = m.groupValues[1].toLongOrNull() ?: 0L
            val sec = m.groupValues[2].toLongOrNull() ?: 0L
            val fracStr = m.groupValues[3]
            val msPart = when (fracStr.length) {
                0 -> 0L
                1 -> (fracStr.toLongOrNull() ?: 0L) * 100L
                2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                else -> fracStr.take(3).toLongOrNull() ?: 0L
            }
            val text = m.groupValues[4].trim()
            if (text.isNotEmpty()) {
                list.add(LyricLine(min * 60_000L + sec * 1000L + msPart, text))
            }
        }
        return list.sortedBy { it.timeMs }
    }
}
