# StreamPlus Lite - Fullscreen Video & Search Thumbnails

Perubahan pada MainActivity.kt:
- Menambahkan tombol layar penuh pada permukaan video di pemutar.
- Mode layar penuh membuka PlayerView dengan kontrol pemutaran bawaan dan tombol keluar layar penuh.
- Thumbnail pada daftar hasil pencarian/riwayat di tab Jelajahi selalu ditampilkan, termasuk saat Audio Hemat Kuota aktif.

Catatan pengujian:
- Source ZIP berhasil dibuat dan struktur arsip diperiksa.
- Kompilasi Gradle belum dapat diverifikasi dari lingkungan ini karena akses DNS ke services.gradle.org tidak tersedia.
- Build melalui GitHub Actions lalu uji di perangkat tetap diperlukan.
