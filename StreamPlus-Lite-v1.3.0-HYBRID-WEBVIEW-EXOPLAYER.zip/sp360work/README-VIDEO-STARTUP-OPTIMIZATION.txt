StreamPlus Lite v1.3.0 - Video startup optimization (interim)

Change in this revision:
- Video stream resolution attempt is capped at 12 seconds per yt-dlp attempt instead of the generic 30-second watchdog.
- Existing 360p default remains unchanged.
- Existing two-stream video/audio merge is preserved to avoid regressions in playback.
- Audio HD, Audio Hemat Kuota, search thumbnails, views metadata, and fullscreen code are unchanged.

Important limitation:
- This revision does NOT yet implement the single progressive MP4 (muxed) path.
- The current PlaybackService constructs MergingMediaSource before stream resolution and assumes separate video/audio URLs. Supporting a one-URL muxed stream safely requires refactoring queue/source preparation to choose a single MediaSource or a merged pair after resolving the format.
- This ZIP has not been Gradle-compiled. Build and test via GitHub Actions before installing.
