# Stream Plus
Pemutar bergaya YouTube Music (yt-dlp + Media3). Tidak menyimpan file apa pun.

- Cari lagu/video, atau tempel link video/playlist
- Mode **Audio** (hemat kuota) atau **Video**, bisa diganti saat memutar
- Mini player + pemutar layar penuh, antrean (next/prev)
- Putar di background & saat layar mati, kontrol di notifikasi / layar kunci
- Share link dari app lain langsung diputar
- Tombol refresh = update yt-dlp (jika situs berhenti bekerja)

Build di GitHub: jalankan workflow *Build APK* (lihat .github/workflows/android.yml).
Build lokal: Android Studio (JDK 17+) → Sync → Run.
