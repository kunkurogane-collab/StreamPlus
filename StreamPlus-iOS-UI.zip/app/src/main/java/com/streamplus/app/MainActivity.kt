package com.streamplus.app

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// Warna Sistem iOS / Apple Music
private val IosAccentRed = Color(0xFFFA233B)
private val IosLightBg = Color(0xFFF2F2F7)
private val IosDarkBg = Color(0xFF000000)
private val IosLightCard = Color(0xFFFFFFFF)
private val IosDarkCard = Color(0xFF1C1C1E)
private val IosLightSearchBg = Color(0xFFE3E3E8)
private val IosDarkSearchBg = Color(0xFF2C2C2E)
private val IosSecondaryLabel = Color(0xFF8E8E93)

private data class Now(
    val mediaId: String = "",
    val title: String = "",
    val artist: String = "",
    val art: String? = null,
    val playing: Boolean = false,
    val has: Boolean = false,
    val durationMs: Long = 0L
)

private fun toggle(c: MediaController) {
    val st = c.playbackState
    if (c.playWhenReady && st != Player.STATE_IDLE && st != Player.STATE_ENDED) c.pause()
    else {
        if (st == Player.STATE_IDLE) c.prepare()
        if (st == Player.STATE_ENDED) c.seekToDefaultPosition()
        c.play()
    }
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun rememberNow(c: MediaController?): Now {
    var now by remember { mutableStateOf(Now()) }
    DisposableEffect(c) {
        if (c == null) {
            onDispose { }
        } else {
            fun upd() {
                now = Now(
                    mediaId = c.currentMediaItem?.mediaId.orEmpty(),
                    title = c.mediaMetadata.title?.toString().orEmpty(),
                    artist = c.mediaMetadata.artist?.toString().orEmpty(),
                    art = c.mediaMetadata.artworkUri?.toString(),
                    playing = c.playWhenReady && c.playbackState != Player.STATE_IDLE && c.playbackState != Player.STATE_ENDED,
                    has = c.mediaItemCount > 0,
                    durationMs = c.duration.coerceAtLeast(0L)
                )
            }
            val l = object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = upd()
            }
            c.addListener(l); upd()
            onDispose { c.removeListener(l) }
        }
    }
    return now
}

@Composable
private fun IosArtwork(url: String?, size: Dp, cornerRadius: Dp = 8.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFFA233B), Color(0xFFFB5C74))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.85f),
            modifier = Modifier.size(size * 0.48f)
        )
        if (!url.isNullOrBlank()) {
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun IosSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    isDark: Boolean
) {
    val searchBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val textColor = if (isDark) Color.White else Color.Black

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(searchBg)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = "Cari",
            tint = IosSecondaryLabel,
            modifier = Modifier
                .size(20.dp)
                .clickable { onSearch() }
        )
        Spacer(modifier = Modifier.width(6.dp))
        Box(modifier = Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text(
                    text = "Cari lagu, video, atau tempel link",
                    color = IosSecondaryLabel,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = TextStyle(
                    color = textColor,
                    fontSize = 15.sp
                ),
                cursorBrush = SolidColor(IosAccentRed),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.isNotEmpty()) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Rounded.Cancel,
                contentDescription = "Hapus",
                tint = IosSecondaryLabel,
                modifier = Modifier
                    .size(18.dp)
                    .clickable { onQueryChange("") }
            )
        }
    }
}

@Composable
private fun IosModeSegmentedControl(
    video: Boolean,
    onMode: (Boolean) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val items = listOf("Audio", "Video")
    val selectedIndex = if (video) 1 else 0
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / items.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "segment_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(7.dp))
                .clip(RoundedCornerShape(7.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            items.forEachIndexed { index, title ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onMode(index == 1) },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (index == 0) Icons.Rounded.Headphones else Icons.Rounded.SmartDisplay,
                            contentDescription = null,
                            tint = if (index == selectedIndex) IosAccentRed else IosSecondaryLabel,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Medium,
                            color = labelColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IosMiniPlayer(
    now: Now,
    c: MediaController,
    isDark: Boolean,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val barBg = if (isDark) Color(0xF02C2C2E) else Color(0xFAFFFFFF)
    val contentColor = if (isDark) Color.White else Color.Black

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp)
            .shadow(14.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onOpen),
        shape = RoundedCornerShape(16.dp),
        color = barBg
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IosArtwork(url = now.art, size = 44.dp, cornerRadius = 8.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = now.title.ifEmpty { "Memuat…" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = contentColor
                )
                if (now.artist.isNotEmpty()) {
                    Text(
                        text = now.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 12.sp,
                        color = IosSecondaryLabel
                    )
                }
            }
            IconButton(onClick = { toggle(c) }) {
                Icon(
                    imageVector = if (now.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = "Putar/Jeda",
                    tint = contentColor,
                    modifier = Modifier.size(28.dp)
                )
            }
            IconButton(onClick = { c.seekToNextMediaItem() }) {
                Icon(
                    imageVector = Icons.Rounded.FastForward,
                    contentDescription = "Berikutnya",
                    tint = contentColor,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IosFullPlayer(
    now: Now,
    c: MediaController,
    video: Boolean,
    status: String?,
    isDark: Boolean,
    onMode: (Boolean) -> Unit,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)
    var pos by remember { mutableLongStateOf(0L) }
    var seeking by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(c) {
        while (true) {
            pos = c.currentPosition.coerceAtLeast(0L)
            delay(400)
        }
    }
    val dur = now.durationMs.coerceAtLeast(1L)

    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    val animatedOffsetY by animateFloatAsState(
        targetValue = dragOffsetY,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "drag_dismiss"
    )

    val artworkScale by animateFloatAsState(
        targetValue = if (now.playing || video) 1.0f else 0.88f,
        animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessLow),
        label = "artwork_scale"
    )

    val sheetBg = if (isDark) Color(0xFF141416) else Color(0xFFFAFAFC)
    val contentColor = if (isDark) Color.White else Color.Black

    Box(
        modifier = Modifier
            .fillMaxSize()
            .offset { IntOffset(0, animatedOffsetY.roundToInt().coerceAtLeast(0)) }
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(sheetBg)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (dragOffsetY > 220f) onClose()
                        dragOffsetY = 0f
                    },
                    onDragCancel = { dragOffsetY = 0f },
                    onVerticalDrag = { change, dragAmount ->
                        change.consume()
                        dragOffsetY = (dragOffsetY + dragAmount).coerceAtLeast(0f)
                    }
                )
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // iOS Grabber Pill
            Box(
                modifier = Modifier
                    .width(38.dp)
                    .height(5.dp)
                    .clip(CircleShape)
                    .background(Color.Gray.copy(alpha = 0.45f))
                    .clickable { onClose() }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Header bar: tombol tutup & segmented mode Audio/Video
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.16f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Tutup",
                        tint = contentColor
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                IosModeSegmentedControl(
                    video = video,
                    onMode = onMode,
                    isDark = isDark,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.weight(0.6f))

            // Artwork atau Video Surface
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(if (video) 16f / 9f else 1f)
                    .scale(artworkScale)
                    .shadow(24.dp, RoundedCornerShape(20.dp))
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFFFA233B), Color(0xFFFF6B81))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (video) {
                    AndroidView(
                        factory = { PlayerView(it).apply { useController = false } },
                        update = { it.player = c },
                        onRelease = { it.player = null },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Rounded.MusicNote,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(96.dp)
                    )
                    if (!now.art.isNullOrBlank()) {
                        AsyncImage(
                            model = now.art,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.6f))

            // Judul & Artis
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = now.title.ifEmpty { "Memuat…" },
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    color = contentColor
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = now.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = IosAccentRed
                )
                status?.let {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = it,
                        color = IosSecondaryLabel,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // iOS Slider
            Slider(
                value = (seeking ?: (pos.toFloat() / dur)).coerceIn(0f, 1f),
                onValueChange = { seeking = it },
                onValueChangeFinished = {
                    seeking?.let { c.seekTo((it * dur).toLong()) }
                    seeking = null
                },
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = IosAccentRed,
                    inactiveTrackColor = Color.Gray.copy(alpha = 0.25f)
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(fmt(pos), fontSize = 11.sp, color = IosSecondaryLabel)
                Text(fmt(now.durationMs), fontSize = 11.sp, color = IosSecondaryLabel)
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Kontrol Pemutaran Utama
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { c.seekToPrevious() }, modifier = Modifier.size(56.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.FastRewind,
                        contentDescription = "Sebelumnya",
                        tint = contentColor,
                        modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = { toggle(c) }, modifier = Modifier.size(76.dp)) {
                    Icon(
                        imageVector = if (now.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = "Putar/Jeda",
                        tint = contentColor,
                        modifier = Modifier.size(58.dp)
                    )
                }
                IconButton(onClick = { c.seekToNextMediaItem() }, modifier = Modifier.size(56.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.FastForward,
                        contentDescription = "Berikutnya",
                        tint = contentColor,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

class MainActivity : ComponentActivity() {
    private var sharedText by mutableStateOf<String?>(null)
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        sharedText = intent.sharedText()
        setContent {
            val isDark = isSystemInDarkTheme()
            val scheme = if (isDark) {
                darkColorScheme(
                    primary = IosAccentRed,
                    background = IosDarkBg,
                    surface = IosDarkCard,
                    surfaceVariant = IosDarkSearchBg,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            } else {
                lightColorScheme(
                    primary = IosAccentRed,
                    background = IosLightBg,
                    surface = IosLightCard,
                    surfaceVariant = IosLightSearchBg,
                    onBackground = Color.Black,
                    onSurface = Color.Black
                )
            }
            MaterialTheme(colorScheme = scheme) {
                Surface(modifier = Modifier.fillMaxSize(), color = scheme.background) {
                    App(isDark = isDark)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (controllerFuture == null) {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerFuture = MediaController.Builder(this, token).buildAsync().also { f ->
                f.addListener({ controller = f.get().also { setVideo(it, true) } }, ContextCompat.getMainExecutor(this))
            }
        } else controller?.let { setVideo(it, true) }
    }

    // App di background / layar mati: track video dimatikan, audio lanjut
    override fun onStop() {
        controller?.let { setVideo(it, false) }
        super.onStop()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null; controller = null
        super.onDestroy()
    }

    private fun setVideo(c: MediaController, on: Boolean) {
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !on).build()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        sharedText = intent.sharedText()
    }

    private fun Intent.sharedText() =
        if (action == Intent.ACTION_SEND) getStringExtra(Intent.EXTRA_TEXT) else null

    @Composable
    private fun App(isDark: Boolean) {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()
        val focus = LocalFocusManager.current
        val c = controller
        val now = rememberNow(c)
        val engineStatus by Engine.status.collectAsState()

        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        var query by remember { mutableStateOf("") }
        var results by remember { mutableStateOf<List<Track>>(emptyList()) }
        var loading by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf<String?>(null) }
        var video by remember { mutableStateOf(false) }
        var expanded by remember { mutableStateOf(false) }

        val bgColor = if (isDark) IosDarkBg else IosLightBg
        val cardColor = if (isDark) IosDarkCard else IosLightCard
        val primaryText = if (isDark) Color.White else Color.Black

        fun play(i: Int) {
            val ctrl = controller ?: run { message = "Pemutar belum siap, coba lagi sebentar."; return }
            val args = Bundle().apply {
                putStringArrayList("urls", ArrayList(results.map { it.url }))
                putStringArrayList("titles", ArrayList(results.map { it.title }))
                putStringArrayList("artists", ArrayList(results.map { it.artist }))
                putStringArrayList("thumbs", ArrayList(results.map { it.thumb.orEmpty() }))
                putInt("start", i)
                putBoolean("video", video)
            }
            ctrl.sendCustomCommand(SessionCommand(CMD_SET_QUEUE, Bundle.EMPTY), args)
        }

        fun search(text: String = query, autoPlay: Boolean = false) {
            val q = text.trim()
            if (q.isEmpty() || loading) return
            focus.clearFocus()
            loading = true; message = null
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { Engine.query(ctx, q) } }
                    .onSuccess {
                        results = it
                        if (it.isEmpty()) message = "Tidak ada hasil"
                        else if (autoPlay) play(0)
                    }
                    .onFailure {
                        message = "Gagal: ${it.message?.take(160)}
(Jika baru dibuka, tunggu sebentar lalu coba lagi.)"
                    }
                loading = false
            }
        }

        fun setMode(v: Boolean) {
            video = v
            controller?.sendCustomCommand(
                SessionCommand(CMD_SET_MODE, Bundle.EMPTY), Bundle().apply { putBoolean("video", v) }
            )
        }

        LaunchedEffect(sharedText) {
            val link = sharedText?.let { Regex("https?://\S+").find(it)?.value }
            if (link != null) { query = link; search(link, autoPlay = true); sharedText = null }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgColor)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(10.dp))

                // iOS Large Title Header + Tombol Update yt-dlp
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Stream Plus",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp,
                        color = primaryText,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            message = "Memperbarui yt-dlp…"
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { Engine.update(ctx) }
                                message = "yt-dlp: $r"
                            }
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(if (isDark) IosDarkSearchBg else IosLightSearchBg)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Update yt-dlp",
                            tint = IosAccentRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // iOS Search Bar
                IosSearchBar(
                    query = query,
                    onQueryChange = { query = it },
                    onSearch = { search(autoPlay = query.startsWith("http")) },
                    isDark = isDark
                )

                Spacer(modifier = Modifier.height(12.dp))

                // iOS Segmented Control (Audio / Video)
                IosModeSegmentedControl(
                    video = video,
                    onMode = ::setMode,
                    isDark = isDark,
                    modifier = Modifier.fillMaxWidth()
                )

                if (loading) {
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(CircleShape),
                        color = IosAccentRed
                    )
                }

                (message ?: engineStatus)?.let {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = it,
                        color = IosSecondaryLabel,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // iOS Inset Grouped List
                if (results.isEmpty() && !loading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = null,
                                tint = IosSecondaryLabel.copy(alpha = 0.5f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Cari lagu atau tempel tautan YouTube",
                                color = IosSecondaryLabel,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        color = cardColor
                    ) {
                        LazyColumn(
                            contentPadding = PaddingValues(bottom = if (now.has) 88.dp else 20.dp)
                        ) {
                            itemsIndexed(results) { i, t ->
                                val isCurrent = now.mediaId == t.url
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { play(i) }
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IosArtwork(url = t.thumb, size = 50.dp, cornerRadius = 8.dp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = t.title,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = if (isCurrent) IosAccentRed else primaryText
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = listOf(
                                                t.artist,
                                                if (t.durationSec > 0) fmt(t.durationSec * 1000) else ""
                                            ).filter { it.isNotEmpty() }.joinToString(" • "),
                                            fontSize = 12.sp,
                                            color = IosSecondaryLabel,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (isCurrent && now.playing) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(
                                            imageVector = Icons.Rounded.GraphicEq,
                                            contentDescription = null,
                                            tint = IosAccentRed,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                if (i < results.lastIndex) {
                                    HorizontalDivider(
                                        modifier = Modifier.padding(start = 76.dp),
                                        thickness = 0.5.dp,
                                        color = Color.Gray.copy(alpha = 0.25f)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Floating iOS Mini Player
            if (now.has && c != null && !expanded) {
                IosMiniPlayer(
                    now = now,
                    c = c,
                    isDark = isDark,
                    onOpen = { expanded = true },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                )
            }

            // Full Player Sheet dengan Drag-to-Dismiss
            AnimatedVisibility(
                visible = expanded && now.has && c != null,
                enter = slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)
                ),
                exit = slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMedium)
                )
            ) {
                if (c != null) {
                    IosFullPlayer(
                        now = now,
                        c = c,
                        video = video,
                        status = engineStatus,
                        isDark = isDark,
                        onMode = ::setMode,
                        onClose = { expanded = false }
                    )
                }
            }
        }
    }
}
