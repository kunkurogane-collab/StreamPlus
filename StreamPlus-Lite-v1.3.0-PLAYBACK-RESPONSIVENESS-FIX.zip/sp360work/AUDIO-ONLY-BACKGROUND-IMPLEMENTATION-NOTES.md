StreamPlus Lite v1.3.0 — Audio-only background playback

- Removed the Audio/Video mode selector from the main search screen and full player.
- Removed video resolution controls from the user-facing options.
- Removed the Hybrid YouTube WebView video activity and its manifest registration.
- Search results and queues are played as audio through the existing Media3 PlaybackService.
- Queue commands explicitly pass video=false, so PlaybackService resolves audio-only streams.
- Audio quality selector (Hemat Kuota / Audio HD) remains available.
- PlaybackService remains a MediaSessionService with foreground media playback support for notification controls and background playback.

Verification status: source ZIP integrity can be checked locally; Gradle compilation requires downloading Gradle 8.13, which is unavailable in this environment. Build with GitHub Actions, then test Home, screen lock, notification controls, Audio HD, and Hemat Kuota on-device.
