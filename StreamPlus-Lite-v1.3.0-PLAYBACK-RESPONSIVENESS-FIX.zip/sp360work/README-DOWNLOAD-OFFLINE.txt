STREAMPLUS LITE v1.3.0 - DOWNLOAD OFFLINE

Fitur:
- Tambahkan aksi "Download Offline" dari opsi lagu pada daftar lagu.
- Pemutar layar penuh menyediakan tombol "Download Offline" pada Opsi Pemutaran & File.
- Audio diunduh ke penyimpanan privat aplikasi (files/offline_favorites), bukan sekadar cache sementara.
- Metadata unduhan disimpan agar daftar Unduhan tetap tersedia setelah aplikasi ditutup/dibuka ulang.
- Tab "Unduhan" menampilkan lagu tersimpan; ketuk lagu untuk memutar file lokal tanpa internet.
- Hapus per lagu melalui menu ⋮ atau hapus semua dari tab Unduhan.
- Kualitas unduhan manual mengikuti pilihan Audio HD / Hemat Kuota saat diunduh.
- Auto-download favorit yang sudah ada tetap dipertahankan.

Catatan:
- File privat aplikasi tidak terlihat langsung di file manager dan akan terhapus bila aplikasi di-uninstall atau data aplikasi dihapus.
- Untuk salinan yang terlihat di aplikasi Musik/file manager, gunakan opsi "Simpan ke Folder Musik HP".
- ZIP ini perlu dibangun melalui GitHub Actions dan diuji di perangkat. Pemeriksaan ZIP tidak sama dengan kompilasi Gradle.
