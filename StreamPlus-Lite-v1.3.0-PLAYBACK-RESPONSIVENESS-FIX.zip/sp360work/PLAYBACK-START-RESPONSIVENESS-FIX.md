StreamPlus Lite - Playback Start Responsiveness Fix

- PlaybackService marks playback busy before queue prepare, so automatic favorite downloads pause before a newly selected track resolves.
- FavoriteDownloader checks playbackBusy before starting Engine.resolve for an automatic download.
- Manual downloads remain available; only automatic background download work is deferred while playback starts/buffers.
- PlaybackBusy is released by the existing Player.STATE_READY cooldown logic.

Build/device test status: source change packaged; compile and device playback latency still require GitHub Actions and on-device verification.
