StreamPlus Lite DSP Visualizer

- Adds RECORD_AUDIO runtime permission for Android Visualizer API.
- Uses the playback service's ExoPlayer audio session ID, not global output mix.
- FFT data drives a 36-bar spectrum overlay on the full player artwork only.
- Visualizer instance is enabled while full-player composable is active and released on dispose.
- No microphone recording or audio file storage is implemented.
- Mini-player and search UI are unchanged.

Permission is requested when the full player opens. If permission is denied, the spectrum is hidden and playback continues normally.
