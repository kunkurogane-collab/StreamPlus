# StreamPlus Lite — Favorit dan Download Offline

## Perbedaan fungsi
- Favorit menyimpan metadata/daftar lagu. Menambahkan atau menghapus tanda favorit tidak otomatis menghapus file audio lokal.
- Download Offline menyimpan file audio di penyimpanan privat aplikasi. File yang tersimpan dipakai langsung oleh PlaybackService ketika lagu diputar, termasuk tanpa internet.
- Download Semua pada tab Favorit mengunduh seluruh lagu favorit satu per satu, mengikuti pilihan kualitas audio saat ini. Fitur ini tetap bisa dijalankan walaupun mode unduh otomatis disetel Mati.
- Mode unduh otomatis opsional: Mati, Wi-Fi Saja, atau Semua Jaringan. Mode ini hanya mengatur pengunduhan otomatis setelah daftar favorit berubah.

## Indikator
- Ikon cloud-download abu-abu pada daftar Favorit: belum ada file lokal.
- Ikon download hijau: file audio tersedia secara lokal.
- Spinner: lagu sedang diunduh.

## Perlindungan data
Menghapus lagu dari Favorit hanya menghapus tanda/entri favorit. File audio yang sudah diunduh tetap ada dan tetap muncul pada tab Unduhan Offline. Menghapus file dilakukan secara terpisah dari tab Unduhan Offline atau kontrol hapus file offline.
