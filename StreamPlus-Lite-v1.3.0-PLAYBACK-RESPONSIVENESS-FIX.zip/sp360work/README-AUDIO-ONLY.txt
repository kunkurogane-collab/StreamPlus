StreamPlus Lite v1.3.0 — Audio-only background playback

This build removes the Video mode from the user interface. Search results and playlists are played as audio using the existing Media3 PlaybackService. The Audio HD / Hemat Kuota selector remains available.

Build: upload this project ZIP to GitHub and run the Android workflow. After a successful build, test playback while pressing Home, locking the screen, and using the media notification controls.
