package com.kunkurogane.streamplus

data class StreamChannel(
    val name: String,
    val url: String
)
