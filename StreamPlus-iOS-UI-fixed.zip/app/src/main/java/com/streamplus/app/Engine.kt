package com.streamplus.app

import android.content.Context
import android.net.Uri
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.flow.MutableStateFlow

data class Track(val url: String, val title: String, val artist: String, val durationSec: Long, val thumb: String?)

/** URI internal: dipecahkan jadi link stream asli saat pemutar butuh (lazy). */
fun ytUri(url: String): Uri =
    Uri.Builder().scheme("yt").authority("r").appendQueryParameter("u", url).build()

object Engine {
    @Volatile private var ready = false
    private val cache = ConcurrentHashMap<String, Pair<String, Long>>()

    /** Status yang tampil di UI: "Mengambil stream…" / pesan error. */
    val status = MutableStateFlow<String?>(null)

    @Synchronized
    fun ensureInit(ctx: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(ctx.applicationContext)
        ready = true
    }

    private fun run(req: YoutubeDLRequest): List<String> =
        YoutubeDL.getInstance().execute(request = req, processId = UUID.randomUUID().toString())
            .out.lines().map { it.trim() }.filter { it.isNotEmpty() }

    /** Kata kunci -> hasil pencarian; link (video/playlist) -> daftar track. */
    fun query(ctx: Context, input: String): List<Track> {
        ensureInit(ctx)
        val isUrl = input.startsWith("http")
        val req = YoutubeDLRequest(if (isUrl) input else "ytsearch20:$input").apply {
            addOption("--flat-playlist")
            addOption("--print", "%(id)s\t%(title)s\t%(uploader,channel)s\t%(duration)s\t%(webpage_url,url)s\t%(thumbnail)s")
        }
        return run(req).mapNotNull { line ->
            val f = line.split('\t')
            if (f.size < 6 || !f[4].startsWith("http")) return@mapNotNull null
            val yt = f[4].contains("youtube.com") || f[4].contains("youtu.be")
            val thumb = f[5].takeIf { it.startsWith("http") }
                ?: if (yt) "https://i.ytimg.com/vi/${f[0]}/mqdefault.jpg" else null
            Track(f[4], f[1], f[2].takeIf { it != "NA" } ?: "", f[3].toDoubleOrNull()?.toLong() ?: 0L, thumb)
        }
    }

    /** Link stream langsung. audioOnly = hanya audio (hemat kuota). */
    fun resolve(ctx: Context, url: String, audioOnly: Boolean): String {
        val key = (if (audioOnly) "a:" else "v:") + url
        cache[key]?.let { if (System.currentTimeMillis() - it.second < 4 * 3600_000L) return it.first }
        status.value = "Mengambil stream…"
        ensureInitSafe(ctx)
        val fmt = if (audioOnly) "ba[ext=m4a]/ba/b" else "b[height<=?720]/b"
        val yt = url.contains("youtube.com") || url.contains("youtu.be")
        // Percobaan 1: bawaan; lalu klien alternatif (tanpa JS/PO token) khusus YouTube
        val attempts = if (yt) listOf(null, "youtube:player_client=android_vr", "youtube:player_client=ios") else listOf(null)
        var last: Exception? = null
        for (ea in attempts) {
            try {
                val req = YoutubeDLRequest(url).apply {
                    addOption("--no-playlist"); addOption("-f", fmt); addOption("--print", "urls")
                    if (ea != null) addOption("--extractor-args", ea)
                }
                val u = run(req).firstOrNull { it.startsWith("http") }
                if (u != null) {
                    cache[key] = u to System.currentTimeMillis()
                    status.value = null
                    return u
                }
            } catch (e: Exception) { last = e }
        }
        val msg = last?.message?.lines()?.lastOrNull { it.contains("ERROR") }
            ?: last?.message?.take(200) ?: "Stream tidak ditemukan"
        status.value = "Gagal memutar: ${msg.take(220)}"
        throw IOException(msg)
    }

    private fun ensureInitSafe(ctx: Context) {
        try { ensureInit(ctx) } catch (e: Exception) {
            status.value = "Mesin yt-dlp belum siap: ${e.message?.take(120)}"
            throw IOException(e.message, e)
        }
    }

    /** Update yt-dlp otomatis maksimal 1x per hari (YouTube sering berubah). */
    fun autoUpdate(ctx: Context) {
        val prefs = ctx.getSharedPreferences("engine", Context.MODE_PRIVATE)
        if (System.currentTimeMillis() - prefs.getLong("last_update", 0L) < 24 * 3600_000L) return
        update(ctx)
        prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
    }

    fun update(ctx: Context): String = try {
        ensureInit(ctx)
        YoutubeDL.getInstance().updateYoutubeDL(
            appContext = ctx, updateChannel = YoutubeDL.UpdateChannel.STABLE
        ).toString()
    } catch (e: Exception) { "Gagal update: ${e.message}" }
}
