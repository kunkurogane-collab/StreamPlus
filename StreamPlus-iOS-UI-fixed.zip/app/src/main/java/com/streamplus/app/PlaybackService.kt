@file:OptIn(UnstableApi::class)

package com.streamplus.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

const val CMD_SET_QUEUE = "com.streamplus.app.SET_QUEUE"
const val CMD_SET_MODE = "com.streamplus.app.SET_MODE"

/** Pemutar + antrean hidup di service: tetap jalan di background / layar mati. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var exo: ExoPlayer? = null
    @Volatile private var audioOnly = true

    private val resolver = object : ResolvingDataSource.Resolver {
        override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
            if (dataSpec.uri.scheme != "yt") return dataSpec
            val target = dataSpec.uri.getQueryParameter("u") ?: return dataSpec
            val real = Engine.resolve(this@PlaybackService, target, audioOnly)
            return dataSpec.withUri(Uri.parse(real))
        }
    }

    override fun onCreate() {
        super.onCreate()
        val dsFactory = ResolvingDataSource.Factory(DefaultDataSource.Factory(this), resolver)
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(
                DefaultMediaSourceFactory(dsFactory).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(1))
            )
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        // Lagu gagal dimuat -> lompat ke berikutnya
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (player.hasNextMediaItem()) { player.seekToNextMediaItem(); player.prepare() }
            }
        })
        exo = player
        session = MediaSession.Builder(this, player).setCallback(Callback()).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = exo
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.release()
        exo?.release()
        exo = null; session = null
        super.onDestroy()
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession, controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_SET_QUEUE, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_MODE, Bundle.EMPTY)).build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(cmds).build()
        }

        override fun onCustomCommand(
            session: MediaSession, controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand, args: Bundle
        ): ListenableFuture<SessionResult> {
            val p = exo ?: return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_UNKNOWN))
            when (customCommand.customAction) {
                CMD_SET_QUEUE -> {
                    val urls = args.getStringArrayList("urls").orEmpty()
                    val titles = args.getStringArrayList("titles").orEmpty()
                    val artists = args.getStringArrayList("artists").orEmpty()
                    val thumbs = args.getStringArrayList("thumbs").orEmpty()
                    if (urls.isEmpty()) return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_BAD_VALUE))
                    audioOnly = !args.getBoolean("video")
                    val items = urls.indices.map { i ->
                        MediaItem.Builder()
                            .setUri(ytUri(urls[i]))
                            .setMediaId(urls[i])
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(titles.getOrNull(i))
                                    .setArtist(artists.getOrNull(i))
                                    .setArtworkUri(thumbs.getOrNull(i)?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) })
                                    .build()
                            ).build()
                    }
                    p.setMediaItems(items, args.getInt("start", 0), 0L)
                    p.prepare(); p.playWhenReady = true
                }
                CMD_SET_MODE -> {
                    audioOnly = !args.getBoolean("video")
                    val n = p.mediaItemCount
                    if (n > 0) {
                        val items = (0 until n).map { p.getMediaItemAt(it) }
                        p.setMediaItems(items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                    }
                }
                else -> return super.onCustomCommand(session, controller, customCommand, args)
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }
}
