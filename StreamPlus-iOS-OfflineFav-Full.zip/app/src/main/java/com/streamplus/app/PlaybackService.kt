@file:OptIn(UnstableApi::class)

package com.streamplus.app

import android.content.Context
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

const val CMD_SET_QUEUE = "com.streamplus.app.SET_QUEUE"
const val CMD_SET_MODE = "com.streamplus.app.SET_MODE"
const val CMD_SET_QUALITY = "com.streamplus.app.SET_QUALITY"
const val CMD_SET_AUDIO_SAVER = "com.streamplus.app.SET_AUDIO_SAVER"
const val CMD_SET_EQ = "com.streamplus.app.SET_EQ"

data class EqState(
    val enabled: Boolean = false,
    val presetName: String = "Normal",
    val bandFreqsHz: List<Int> = listOf(60, 230, 910, 3600, 14000),
    val bandLevelsMb: List<Int> = listOf(0, 0, 0, 0, 0),
    val minLevelMb: Int = -1500,
    val maxLevelMb: Int = 1500,
    val bassStrength: Int = 0
)

object EqualizerStore {
    private const val PREF = "streamplus_eq"
    val state = MutableStateFlow(EqState())

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var boundSessionId: Int = C.AUDIO_SESSION_ID_UNSET

    fun loadPrefs(ctx: Context) {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val enabled = p.getBoolean("enabled", false)
        val preset = p.getString("preset", "Normal") ?: "Normal"
        val bass = p.getInt("bass", 0).coerceIn(0, 1000)
        val rawLevels = p.getString("levels", null)
        val levels = rawLevels?.split(",")?.mapNotNull { it.toIntOrNull() }?.takeIf { it.isNotEmpty() }
            ?: listOf(0, 0, 0, 0, 0)
        state.value = state.value.copy(
            enabled = enabled,
            presetName = preset,
            bandLevelsMb = levels,
            bassStrength = bass
        )
    }

    fun savePrefs(ctx: Context, s: EqState) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", s.enabled)
            .putString("preset", s.presetName)
            .putInt("bass", s.bassStrength)
            .putString("levels", s.bandLevelsMb.joinToString(","))
            .apply()
    }

    @Synchronized
    fun attachToSession(ctx: Context, sessionId: Int) {
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        if (boundSessionId != sessionId) {
            release()
            boundSessionId = sessionId
            runCatching {
                val eq = Equalizer(0, sessionId)
                val bands = eq.numberOfBands.toInt().coerceAtLeast(1)
                val range = eq.bandLevelRange
                val minMb = range.getOrNull(0)?.toInt() ?: -1500
                val maxMb = range.getOrNull(1)?.toInt() ?: 1500
                val freqs = (0 until bands).map { b -> (eq.getCenterFreq(b.toShort()) / 1000) }
                val currentLevels = state.value.bandLevelsMb
                val normalizedLevels = (0 until bands).map { b ->
                    (currentLevels.getOrNull(b) ?: 0).coerceIn(minMb, maxMb)
                }
                state.value = state.value.copy(
                    bandFreqsHz = freqs,
                    bandLevelsMb = normalizedLevels,
                    minLevelMb = minMb,
                    maxLevelMb = maxMb
                )
                equalizer = eq
            }
            runCatching {
                bassBoost = BassBoost(0, sessionId)
            }
        }
        applyCurrentState(ctx)
    }

    @Synchronized
    fun applyCurrentState(ctx: Context) {
        val s = state.value
        savePrefs(ctx, s)
        runCatching {
            equalizer?.let { eq ->
                eq.enabled = s.enabled
                val bands = eq.numberOfBands.toInt()
                for (b in 0 until bands) {
                    val lvl = (s.bandLevelsMb.getOrNull(b) ?: 0)
                        .coerceIn(s.minLevelMb, s.maxLevelMb)
                        .toShort()
                    eq.setBandLevel(b.toShort(), lvl)
                }
            }
        }
        runCatching {
            bassBoost?.let { bb ->
                bb.enabled = s.enabled && s.bassStrength > 0
                if (bb.strengthSupported) {
                    bb.setStrength(s.bassStrength.coerceIn(0, 1000).toShort())
                }
            }
        }
    }

    @Synchronized
    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        equalizer = null
        bassBoost = null
        boundSessionId = C.AUDIO_SESSION_ID_UNSET
    }
}

private object MediaDiskCache {
    @Volatile private var cache: SimpleCache? = null

    @Synchronized
    fun get(ctx: Context): SimpleCache {
        cache?.let { return it }
        val dir = File(ctx.applicationContext.cacheDir, "media_stream_cache")
        // Maksimal 150 MB LRU cache agar lagu yang diputar berulang tidak menyedot kuota
        val evictor = LeastRecentlyUsedCacheEvictor(150L * 1024L * 1024L)
        val dbProvider = StandaloneDatabaseProvider(ctx.applicationContext)
        return SimpleCache(dir, evictor, dbProvider).also { cache = it }
    }

    @Synchronized
    fun release() {
        runCatching { cache?.release() }
        cache = null
    }
}

/** Pemutar + antrean hidup di service: tetap jalan di background / layar mati. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var exo: ExoPlayer? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var prefetchJob: Job? = null

    @Volatile private var audioOnly = true
    @Volatile private var audioSaver = true
    @Volatile private var maxQuality = 720

    private val resolver = object : ResolvingDataSource.Resolver {
        override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
            if (dataSpec.uri.scheme != "yt") return dataSpec
            val target = dataSpec.uri.getQueryParameter("u") ?: return dataSpec

            // Jika lagu favorit sudah ter-download offline dan sedang mode Audio, putar langsung dari file lokal (0 kuota & instan)
            if (audioOnly) {
                FavoriteDownloader.getOfflineFile(this@PlaybackService, target)?.let { localFile ->
                    Engine.status.value = null
                    return dataSpec.buildUpon()
                        .setUri(Uri.fromFile(localFile))
                        .build()
                }
            }

            FavoriteDownloader.setPlaybackBusy(this@PlaybackService, true)
            val real = Engine.resolve(this@PlaybackService, target, audioOnly, maxQuality, audioSaver)
            // Gunakan custom cache key berdasarkan video URL + mode kualitas agar lagu berulang hemat kuota
            val modeTag = when {
                !audioOnly -> "v$maxQuality"
                audioSaver -> "as"
                else -> "an"
            }
            return dataSpec.buildUpon()
                .setUri(Uri.parse(real))
                .setKey("$modeTag:$target")
                .build()
        }
    }

    private fun schedulePrefetchUpcoming() {
        val p = exo ?: return
        val count = p.mediaItemCount
        if (count <= 1) return
        val currentIdx = p.currentMediaItemIndex
        // Di mode Hemat Kuota cukup prefetch 1 lagu berikutnya (hanya URL metadata, bukan unduh audio)
        val lookahead = if (audioOnly && audioSaver) listOf(currentIdx + 1) else listOf(currentIdx + 1, currentIdx + 2)
        val upcomingUrls = lookahead
            .filter { it in 0 until count }
            .mapNotNull { idx -> p.getMediaItemAt(idx).mediaId.takeIf { it.startsWith("http") } }
        if (upcomingUrls.isEmpty()) return

        val isAudio = audioOnly
        val qual = maxQuality
        val saver = audioSaver
        prefetchJob?.cancel()
        prefetchJob = serviceScope.launch {
            delay(1200L)
            for (nextUrl in upcomingUrls) {
                Engine.prefetch(this@PlaybackService, nextUrl, isAudio, qual, saver)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        EqualizerStore.loadPrefs(this)
        FavoriteDownloader.init(this)
        val prefs = getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE)
        audioSaver = prefs.getBoolean("audio_saver", true)

        val upstreamFactory = DefaultDataSource.Factory(this)
        val cacheFactory = CacheDataSource.Factory()
            .setCache(MediaDiskCache.get(this))
            .setUpstreamDataSourceFactory(upstreamFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        val dsFactory = ResolvingDataSource.Factory(cacheFactory, resolver)

        // Buffer hemat kuota (maks 12 detik ke depan) sekaligus mulai cepat (750 ms)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                8_000,  // minBufferMs
                12_000, // maxBufferMs (mencegah pemborosan data jika lagu di-skip)
                750,    // bufferForPlaybackMs
                1_500   // bufferForPlaybackAfterRebufferMs
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(
                DefaultMediaSourceFactory(dsFactory).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(1))
            )
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        EqualizerStore.attachToSession(this, player.audioSessionId)

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                EqualizerStore.attachToSession(this@PlaybackService, audioSessionId)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                schedulePrefetchUpcoming()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> FavoriteDownloader.setPlaybackBusy(this@PlaybackService, true)
                    Player.STATE_READY -> {
                        FavoriteDownloader.setPlaybackBusy(this@PlaybackService, false)
                        schedulePrefetchUpcoming()
                    }
                    Player.STATE_IDLE, Player.STATE_ENDED -> {
                        FavoriteDownloader.setPlaybackBusy(this@PlaybackService, false)
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (player.hasNextMediaItem()) { player.seekToNextMediaItem(); player.prepare() }
            }
        })
        exo = player
        session = MediaSession.Builder(this, player).setCallback(Callback()).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = exo
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        prefetchJob?.cancel()
        serviceScope.cancel()
        EqualizerStore.release()
        session?.release()
        exo?.release()
        MediaDiskCache.release()
        exo = null; session = null
        super.onDestroy()
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession, controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_SET_QUEUE, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_MODE, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_QUALITY, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_AUDIO_SAVER, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_EQ, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(cmds).build()
        }

        override fun onCustomCommand(
            session: MediaSession, controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand, args: Bundle
        ): ListenableFuture<SessionResult> {
            val p = exo ?: return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_UNKNOWN))
            when (customCommand.customAction) {
                CMD_SET_QUEUE -> {
                    val urls = args.getStringArrayList("urls").orEmpty()
                    val titles = args.getStringArrayList("titles").orEmpty()
                    val artists = args.getStringArrayList("artists").orEmpty()
                    val thumbs = args.getStringArrayList("thumbs").orEmpty()
                    if (urls.isEmpty()) return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_BAD_VALUE))
                    audioOnly = !args.getBoolean("video")
                    if (args.containsKey("quality")) {
                        maxQuality = args.getInt("quality", 720)
                    }
                    if (args.containsKey("audioSaver")) {
                        audioSaver = args.getBoolean("audioSaver", true)
                    }
                    val startIdx = args.getInt("start", 0)
                    val items = urls.indices.map { i ->
                        MediaItem.Builder()
                            .setUri(ytUri(urls[i]))
                            .setMediaId(urls[i])
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(titles.getOrNull(i))
                                    .setArtist(artists.getOrNull(i))
                                    .setArtworkUri(thumbs.getOrNull(i)?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) })
                                    .build()
                            ).build()
                    }
                    p.setMediaItems(items, startIdx, 0L)
                    p.prepare(); p.playWhenReady = true
                    schedulePrefetchUpcoming()
                }
                CMD_SET_MODE -> {
                    audioOnly = !args.getBoolean("video")
                    if (args.containsKey("quality")) {
                        maxQuality = args.getInt("quality", 720)
                    }
                    if (args.containsKey("audioSaver")) {
                        audioSaver = args.getBoolean("audioSaver", true)
                    }
                    val n = p.mediaItemCount
                    if (n > 0) {
                        val items = (0 until n).map { p.getMediaItemAt(it) }
                        p.setMediaItems(items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                        schedulePrefetchUpcoming()
                    }
                }
                CMD_SET_QUALITY -> {
                    maxQuality = args.getInt("quality", 720)
                    if (!audioOnly && p.mediaItemCount > 0) {
                        val items = (0 until p.mediaItemCount).map { p.getMediaItemAt(it) }
                        p.setMediaItems(items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                        schedulePrefetchUpcoming()
                    }
                }
                CMD_SET_AUDIO_SAVER -> {
                    audioSaver = args.getBoolean("audioSaver", true)
                    getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE)
                        .edit().putBoolean("audio_saver", audioSaver).apply()
                    if (audioOnly && p.mediaItemCount > 0) {
                        val items = (0 until p.mediaItemCount).map { p.getMediaItemAt(it) }
                        p.setMediaItems(items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                        schedulePrefetchUpcoming()
                    }
                }
                CMD_SET_EQ -> {
                    val enabled = args.getBoolean("enabled", false)
                    val preset = args.getString("preset", "Normal") ?: "Normal"
                    val bass = args.getInt("bass", 0)
                    val levels = args.getIntegerArrayList("levels")?.toList() ?: EqualizerStore.state.value.bandLevelsMb
                    EqualizerStore.state.value = EqualizerStore.state.value.copy(
                        enabled = enabled,
                        presetName = preset,
                        bandLevelsMb = levels,
                        bassStrength = bass
                    )
                    EqualizerStore.attachToSession(this@PlaybackService, p.audioSessionId)
                }
                else -> return super.onCustomCommand(session, controller, customCommand, args)
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }
}
