# Keep youtubedl-android JNI & reflection callbacks
-keep class com.yausername.** { *; }
-dontwarn com.yausername.**

# Keep Media3 / ExoPlayer reflection classes
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep app data models
-keep class com.streamplus.app.** { *; }
