package com.streamplus.app

import android.content.Context
import android.net.Uri
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

data class Track(val url: String, val title: String, val artist: String, val durationSec: Long, val thumb: String?)

/** URI internal: dipecahkan jadi link stream asli saat pemutar butuh (lazy). */
fun ytUri(url: String): Uri =
    Uri.Builder().scheme("yt").authority("r").appendQueryParameter("u", url).build()

object Engine {
    private const val CACHE_PREF = "streamplus_stream_cache"
    private const val CACHE_KEY = "url_entries_json"
    private const val VIDEO_KEY = "video_entries_json"
    private const val CACHE_TTL_MS = 3 * 3600_000L + 30 * 60_000L // 3.5 jam

    @Volatile private var ready = false
    @Volatile private var diskLoaded = false
    private val cache = ConcurrentHashMap<String, Pair<String, Long>>()
    private val inFlight = ConcurrentHashMap<String, Any>()
    /** Video: pasangan (URL video-only, URL audio) agar bisa digabung di pemutar. */
    private val videoCache = ConcurrentHashMap<String, Triple<String, String?, Long>>()

    /** Status yang tampil di UI: "Mengambil stream…" / pesan error. */
    val status = MutableStateFlow<String?>(null)

    @Synchronized
    fun ensureInit(ctx: Context) {
        loadDiskCache(ctx)
        if (ready) return
        YoutubeDL.getInstance().init(ctx.applicationContext)
        ready = true
    }

    @Synchronized
    private fun loadDiskCache(ctx: Context) {
        if (diskLoaded) return
        diskLoaded = true
        loadVideoDisk(ctx)
        runCatching {
            val raw = ctx.applicationContext.getSharedPreferences(CACHE_PREF, Context.MODE_PRIVATE)
                .getString(CACHE_KEY, null) ?: return
            val obj = JSONObject(raw)
            val now = System.currentTimeMillis()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val entry = obj.optJSONObject(k) ?: continue
                val streamUrl = entry.optString("u")
                val ts = entry.optLong("t", 0L)
                if (streamUrl.startsWith("http") && now - ts < CACHE_TTL_MS) {
                    cache[k] = streamUrl to ts
                }
            }
        }
    }

    /** Cache video (pasangan video+audio) ikut disimpan ke disk: buka ulang app tetap instan. */
    private fun loadVideoDisk(ctx: Context) {
        runCatching {
            val raw = ctx.applicationContext.getSharedPreferences(CACHE_PREF, Context.MODE_PRIVATE)
                .getString(VIDEO_KEY, null) ?: return
            val obj = JSONObject(raw)
            val now = System.currentTimeMillis()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val e = obj.optJSONObject(k) ?: continue
                val u = e.optString("u")
                val a = e.optString("a").takeIf { it.startsWith("http") }
                val t = e.optLong("t", 0L)
                if (u.startsWith("http") && now - t < CACHE_TTL_MS) videoCache[k] = Triple(u, a, t)
            }
        }
    }

    private fun saveVideoDisk(ctx: Context) {
        runCatching {
            val now = System.currentTimeMillis()
            val obj = JSONObject()
            var count = 0
            for ((k, v) in videoCache.entries) {
                if (now - v.third < CACHE_TTL_MS && count < 40) {
                    obj.put(k, JSONObject().apply {
                        put("u", v.first); put("a", v.second ?: ""); put("t", v.third)
                    })
                    count++
                }
            }
            ctx.applicationContext.getSharedPreferences(CACHE_PREF, Context.MODE_PRIVATE)
                .edit().putString(VIDEO_KEY, obj.toString()).apply()
        }
    }

    /** Buang link yang sudah kedaluwarsa (HTTP 403/410) agar diambil ulang. */
    fun invalidate(ctx: Context, url: String) {
        cache.keys.removeAll { it.endsWith(":$url") }
        videoCache.keys.removeAll { it.endsWith(":$url") }
        saveDiskCache(ctx)
        saveVideoDisk(ctx)
    }

    private fun saveDiskCache(ctx: Context) {
        runCatching {
            val now = System.currentTimeMillis()
            val obj = JSONObject()
            var count = 0
            for ((k, v) in cache.entries) {
                if (now - v.second < CACHE_TTL_MS && count < 120) {
                    obj.put(k, JSONObject().apply {
                        put("u", v.first)
                        put("t", v.second)
                    })
                    count++
                }
            }
            ctx.applicationContext.getSharedPreferences(CACHE_PREF, Context.MODE_PRIVATE)
                .edit().putString(CACHE_KEY, obj.toString()).apply()
        }
    }

    private fun cacheKey(url: String, audioOnly: Boolean, maxHeight: Int, audioSaver: Boolean): String =
        when {
            !audioOnly -> "v${maxHeight}:$url"
            audioSaver -> "as:$url"
            else -> "an:$url"
        }

    fun isCached(
        ctx: Context,
        url: String,
        audioOnly: Boolean,
        maxHeight: Int = 720,
        audioSaver: Boolean = true
    ): Boolean {
        loadDiskCache(ctx)
        if (!audioOnly) {
            val v = videoCache["$maxHeight:$url"] ?: return false
            return System.currentTimeMillis() - v.third < CACHE_TTL_MS
        }
        val hit = cache[cacheKey(url, audioOnly, maxHeight, audioSaver)] ?: return false
        return System.currentTimeMillis() - hit.second < CACHE_TTL_MS
    }

    // Batas proses yt-dlp (Python, berat RAM): maks 2 sekaligus; tugas latar (prefetch/radio/unduh)
    // maks 1 sehingga selalu ada slot untuk lagu yang sedang diputar / pencarian pengguna.
    private val fgSlots = Semaphore(2, true)
    private val bgSlot = Semaphore(1, true)
    private val watchdog = Executors.newScheduledThreadPool(1) { r ->
        Thread(r, "ytdlp-watchdog").apply { isDaemon = true }
    }

    /** Jalankan yt-dlp dengan batas paralel + batas waktu (proses yang menggantung dimatikan). */
    private fun run(req: YoutubeDLRequest, background: Boolean = false, timeoutMs: Long = 30_000L): List<String> {
        if (background) bgSlot.acquireUninterruptibly()
        try {
            fgSlots.acquireUninterruptibly()
            try {
                val pid = UUID.randomUUID().toString()
                val timer = watchdog.schedule(
                    Runnable { runCatching { YoutubeDL.destroyProcessById(pid) } },
                    timeoutMs, TimeUnit.MILLISECONDS
                )
                try {
                    return YoutubeDL.getInstance().execute(request = req, processId = pid)
                        .out.lines().map { it.trim() }.filter { it.isNotEmpty() }
                } finally {
                    timer.cancel(false)
                }
            } finally {
                fgSlots.release()
            }
        } finally {
            if (background) bgSlot.release()
        }
    }

    /** Kata kunci -> hasil pencarian; link (video/playlist) -> daftar track. */
    fun query(ctx: Context, input: String, background: Boolean = false): List<Track> {
        ensureInit(ctx)
        val isUrl = input.startsWith("http")
        val req = YoutubeDLRequest(if (isUrl) input else "ytsearch20:$input").apply {
            addOption("--flat-playlist")
            addOption("--no-warnings")
            addOption("--no-check-certificates")
            addOption("--no-call-home")
            addOption("--print", "%(id)s	%(title)s	%(uploader,channel)s	%(duration)s	%(webpage_url,url)s	%(thumbnail)s")
        }
        return run(req, background).mapNotNull { line ->
            val f = line.split('	')
            if (f.size < 6 || !f[4].startsWith("http")) return@mapNotNull null
            val yt = f[4].contains("youtube.com") || f[4].contains("youtu.be")
            val thumb = f[5].takeIf { it.startsWith("http") }
                ?: if (yt) "https://i.ytimg.com/vi/${f[0]}/mqdefault.jpg" else null
            Track(f[4], f[1], f[2].takeIf { it != "NA" } ?: "", f[3].toDoubleOrNull()?.toLong() ?: 0L, thumb)
        }
    }

    /** Pre-resolve URL di latar belakang tanpa mengganggu status UI utama. */
    fun prefetch(
        ctx: Context,
        url: String,
        audioOnly: Boolean,
        maxHeight: Int = 720,
        audioSaver: Boolean = true
    ) {
        if (url.isBlank()) return
        if (isCached(ctx, url, audioOnly, maxHeight, audioSaver)) return
        runCatching { resolveInternal(ctx, url, audioOnly, maxHeight, audioSaver, silent = true) }
    }

    /** Link stream langsung. audioOnly = hanya audio; audioSaver = bitrate rendah hemat kuota; maxHeight = resolusi video. */
    fun resolve(
        ctx: Context,
        url: String,
        audioOnly: Boolean,
        maxHeight: Int = 720,
        audioSaver: Boolean = true,
        silent: Boolean = false
    ): String = resolveInternal(ctx, url, audioOnly, maxHeight, audioSaver, silent = silent)

    private fun resolveInternal(
        ctx: Context,
        url: String,
        audioOnly: Boolean,
        maxHeight: Int,
        audioSaver: Boolean,
        silent: Boolean
    ): String {
        if (!audioOnly) return resolveVideoPair(ctx, url, maxHeight, silent).first
        loadDiskCache(ctx)
        val key = cacheKey(url, audioOnly, maxHeight, audioSaver)
        cache[key]?.let {
            if (System.currentTimeMillis() - it.second < CACHE_TTL_MS) {
                if (!silent) status.value = null
                return it.first
            }
        }

        val lock = inFlight.computeIfAbsent(key) { Any() }
        synchronized(lock) {
            try {
                cache[key]?.let {
                    if (System.currentTimeMillis() - it.second < CACHE_TTL_MS) {
                        if (!silent) status.value = null
                        return it.first
                    }
                }
                if (!silent) {
                    status.value = when {
                        !audioOnly -> "Mengambil video ${maxHeight}p…"
                        audioSaver -> "Mengambil audio hemat kuota…"
                        else -> "Mengambil audio HD…"
                    }
                }
                ensureInitSafe(ctx, silent)
                val fmt = when {
                    !audioOnly -> "b[height<=?$maxHeight][ext=mp4]/b[height<=?$maxHeight]/b"
                    // Hemat kuota: prioritaskan Opus/M4A bitrate <= 70 kbps, tanpa fallback video (/b)
                    audioSaver -> "ba[abr<=70]/ba[ext=webm]/ba[ext=m4a]/ba"
                    // Audio HD/Normal: prioritaskan bitrate terbaik khusus audio saja
                    else -> "ba[ext=m4a]/ba[ext=webm]/ba"
                }
                val yt = url.contains("youtube.com") || url.contains("youtu.be")
                val attempts = if (yt) {
                    listOf(
                        "youtube:player_client=android_vr;skip=dash,hls,translated_subs",
                        "youtube:player_client=ios;skip=dash,hls,translated_subs",
                        null
                    )
                } else {
                    listOf(null)
                }
                var last: Exception? = null
                for (ea in attempts) {
                    try {
                        val req = YoutubeDLRequest(url).apply {
                            addOption("--no-playlist")
                            addOption("--no-warnings")
                            addOption("--no-check-certificates")
                            addOption("--no-call-home")
                            addOption("-f", fmt)
                            addOption("--print", "urls")
                            if (ea != null) addOption("--extractor-args", ea)
                        }
                        val u = run(req, silent).firstOrNull { it.startsWith("http") }
                        if (u != null) {
                            cache[key] = u to System.currentTimeMillis()
                            saveDiskCache(ctx)
                            if (!silent) status.value = null
                            return u
                        }
                    } catch (e: Exception) {
                        last = e
                    }
                }
                val msg = last?.message?.lines()?.lastOrNull { it.contains("ERROR") }
                    ?: last?.message?.take(200) ?: "Stream tidak ditemukan"
                if (!silent) status.value = "Gagal memutar: ${msg.take(220)}"
                throw IOException(msg)
            } finally {
                inFlight.remove(key)
            }
        }
    }

    /**
     * Mode Video: ambil video-only + audio terpisah (adaptive) lalu digabung di pemutar.
     * Format gabungan (muxed) hampir tidak tersedia di klien YouTube yang tanpa PO token,
     * itu penyebab video tidak mau jalan.
     */
    fun resolveVideoPair(ctx: Context, url: String, maxHeight: Int, silent: Boolean = false): Pair<String, String?> {
        val key = "$maxHeight:$url"
        fun cached(): Pair<String, String?>? = videoCache[key]?.let {
            if (System.currentTimeMillis() - it.third < CACHE_TTL_MS) it.first to it.second else null
        }
        cached()?.let { if (!silent) status.value = null; return it }

        val lock = inFlight.computeIfAbsent("pair:$key") { Any() }
        synchronized(lock) {
            try {
                cached()?.let { if (!silent) status.value = null; return it }
                if (!silent) status.value = "Mengambil video ${maxHeight}p…"
                ensureInitSafe(ctx, silent)
                val h = maxHeight
                val fmt = "bv[height<=?$h][vcodec^=avc1]+ba[ext=m4a]/" +
                    "bv[height<=?$h][vcodec^=avc1]+ba/" +
                    "bv[height<=?$h]+ba/" +
                    "b[height<=?$h][ext=mp4]/b[height<=?$h]/b"
                val yt = url.contains("youtube.com") || url.contains("youtu.be")
                val attempts = if (yt) {
                    listOf("youtube:player_client=android_vr", "youtube:player_client=ios", null)
                } else listOf(null)
                var last: Exception? = null
                for (ea in attempts) {
                    try {
                        val req = YoutubeDLRequest(url).apply {
                            addOption("--no-playlist")
                            addOption("--no-warnings")
                            addOption("--no-check-certificates")
                            addOption("--socket-timeout", "10")
                            addOption("-f", fmt)
                            addOption("--print", "urls")
                            if (ea != null) addOption("--extractor-args", ea)
                        }
                        val urls = run(req, silent).filter { it.startsWith("http") }
                        if (urls.isNotEmpty()) {
                            videoCache[key] = Triple(urls[0], urls.getOrNull(1), System.currentTimeMillis())
                            saveVideoDisk(ctx)
                            if (!silent) status.value = null
                            return urls[0] to urls.getOrNull(1)
                        }
                    } catch (e: Exception) { last = e }
                }
                val msg = last?.message?.lines()?.lastOrNull { it.contains("ERROR") }
                    ?: last?.message?.take(200) ?: "Video tidak ditemukan"
                if (!silent) status.value = "Gagal memutar video: ${msg.take(200)}"
                throw IOException(msg)
            } finally {
                inFlight.remove("pair:$key")
            }
        }
    }

    private fun ensureInitSafe(ctx: Context, silent: Boolean) {
        try {
            ensureInit(ctx)
        } catch (e: Exception) {
            if (!silent) status.value = "Mesin yt-dlp belum siap: ${e.message?.take(120)}"
            throw IOException(e.message, e)
        }
    }

    /** Update yt-dlp otomatis maksimal 1x per hari (YouTube sering berubah). */
    fun autoUpdate(ctx: Context) {
        val prefs = ctx.getSharedPreferences("engine", Context.MODE_PRIVATE)
        if (System.currentTimeMillis() - prefs.getLong("last_update", 0L) < 24 * 3600_000L) return
        update(ctx)
        prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
    }

    fun update(ctx: Context): String = try {
        ensureInit(ctx)
        YoutubeDL.getInstance().updateYoutubeDL(
            appContext = ctx, updateChannel = YoutubeDL.UpdateChannel.STABLE
        ).toString()
    } catch (e: Exception) { "Gagal update: ${e.message}" }
}
