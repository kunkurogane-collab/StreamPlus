# StreamPlus Android Lite

Aplikasi pemutar musik dan video Android native berbasis Kotlin, Jetpack Compose, dan Media3/yt-dlp.

## Fitur Utama
- Pemutaran audio & video streaming (mode hemat kuota & audio HD / resolusi video 360p–1080p)
- Lirik tersinkronisasi (LRCLIB) & layar pemutar penuh dengan gestur geser
- Equalizer multi-band, Bass Boost, Normalisasi Volume (*Loudness*), dan *Skip Silence*
- Daftar Favorit, Playlist kustom, Riwayat Putar, unduhan offline otomatis, serta ekspor ke `Music/StreamPlus`
- Cadangkan & pulihkan pustaka (`.json`)

## Struktur Paket
- `com.streamplus.app` — `MainActivity`, `PlaybackService`, `Engine`, `FavoriteDownloader`, `LyricsClient`, `MusicExporter`, `UserLibrary`, `StreamApp`
- `com.streamplus.app.data` — `FavoritesStore`
- `com.streamplus.app.ui.theme` — `IosTheme`
- `com.streamplus.app.ui.viewmodel` — `MainViewModel`
- `com.streamplus.app.ui.components` — `IosControls`
- `com.streamplus.app.ui.player` — `IosFullPlayer`, `IosEqualizerSheet`
- `com.streamplus.app.ui.screens` — `MainScreen`
