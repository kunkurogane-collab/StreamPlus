package com.streamplus.app.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.session.MediaController
import coil.compose.AsyncImage
import com.streamplus.app.AutoDownloadMode
import com.streamplus.app.Track
import com.streamplus.app.ui.theme.IosAccentRed
import com.streamplus.app.ui.theme.IosDarkSearchBg
import com.streamplus.app.ui.theme.IosLightSearchBg
import com.streamplus.app.ui.theme.IosSecondaryLabel
import com.streamplus.app.ui.theme.fmt
import com.streamplus.app.ui.viewmodel.NowPlayingState
import com.streamplus.app.ui.viewmodel.togglePlayback

@Composable
fun IosArtwork(url: String?, size: Dp, cornerRadius: Dp = 8.dp, showImage: Boolean = true) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(Brush.linearGradient(listOf(Color(0xFFFA233B), Color(0xFFFB5C74)))),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.85f),
            modifier = Modifier.size(size * 0.48f)
        )
        if (showImage && !url.isNullOrBlank()) {
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun IosSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    isDark: Boolean
) {
    val searchBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val textColor = if (isDark) Color.White else Color.Black

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(searchBg)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = "Cari",
            tint = IosSecondaryLabel,
            modifier = Modifier
                .size(20.dp)
                .clickable { onSearch() }
        )
        Spacer(modifier = Modifier.width(6.dp))
        Box(modifier = Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text(
                    text = "Cari lagu, video, atau tempel link",
                    color = IosSecondaryLabel,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = TextStyle(color = textColor, fontSize = 15.sp),
                cursorBrush = SolidColor(IosAccentRed),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.isNotEmpty()) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Rounded.Cancel,
                contentDescription = "Hapus",
                tint = IosSecondaryLabel,
                modifier = Modifier
                    .size(18.dp)
                    .clickable { onQueryChange("") }
            )
        }
    }
}

@Composable
fun IosModeSegmentedControl(
    video: Boolean,
    onMode: (Boolean) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val items = listOf("Audio", "Video")
    val selectedIndex = if (video) 1 else 0
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / items.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "segment_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(7.dp))
                .clip(RoundedCornerShape(7.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            items.forEachIndexed { index, title ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onMode(index == 1) },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (index == 0) Icons.Rounded.Headphones else Icons.Rounded.SmartDisplay,
                            contentDescription = null,
                            tint = if (index == selectedIndex) IosAccentRed else IosSecondaryLabel,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Medium,
                            color = labelColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IosQualitySegmentedControl(
    selectedQuality: Int,
    onSelectQuality: (Int) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val options = listOf(360, 480, 720, 1080)
    val selectedIndex = options.indexOf(selectedQuality).coerceAtLeast(0)
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / options.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "quality_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            options.forEachIndexed { index, q ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectQuality(q) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${q}p",
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (index == selectedIndex) IosAccentRed else labelColor
                    )
                }
            }
        }
    }
}

@Composable
fun IosAudioQualitySegmentedControl(
    audioSaver: Boolean,
    onSelectAudioSaver: (Boolean) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val options = listOf("Hemat (~48k)", "Audio HD (~128k)")
    val selectedIndex = if (audioSaver) 0 else 1
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / options.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "audio_quality_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            options.forEachIndexed { index, label ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectAudioSaver(index == 0) },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        if (index == 0) {
                            Icon(
                                imageVector = Icons.Rounded.DataSaverOn,
                                contentDescription = null,
                                tint = if (selectedIndex == 0) IosAccentRed else IosSecondaryLabel,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (index == selectedIndex) IosAccentRed else labelColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IosAutoDownloadSegmentedControl(
    selectedMode: AutoDownloadMode,
    onSelectMode: (AutoDownloadMode) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val options = AutoDownloadMode.entries
    val selectedIndex = options.indexOf(selectedMode).coerceAtLeast(0)
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / options.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "autodl_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            options.forEachIndexed { index, item ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectMode(item) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = item.label,
                        fontSize = 11.sp,
                        fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (index == selectedIndex) IosAccentRed else labelColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun IosTextSegmentedControl(
    labels: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val containerBg = if (isDark) IosDarkSearchBg else IosLightSearchBg
    val thumbBg = if (isDark) Color(0xFF636366) else Color.White
    val labelColor = if (isDark) Color.White else Color.Black

    BoxWithConstraints(
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerBg)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / labels.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex.coerceIn(0, labels.lastIndex),
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium),
            label = "text_seg_offset"
        )

        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(thumbBg)
        )

        Row(modifier = Modifier.fillMaxSize()) {
            labels.forEachIndexed { index, text ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = text,
                        fontSize = 12.sp,
                        fontWeight = if (index == selectedIndex) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (index == selectedIndex) IosAccentRed else labelColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun VerticalBandSlider(
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    enabled: Boolean,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = valueRange,
        enabled = enabled,
        colors = SliderDefaults.colors(
            thumbColor = if (enabled) Color.White else IosSecondaryLabel,
            activeTrackColor = if (enabled) IosAccentRed else Color.Gray.copy(alpha = 0.35f),
            inactiveTrackColor = Color.Gray.copy(alpha = 0.25f)
        ),
        modifier = modifier
            .graphicsLayer {
                rotationZ = 270f
                transformOrigin = TransformOrigin(0f, 0f)
            }
            .layout { measurable, constraints ->
                val placeable = measurable.measure(
                    Constraints(
                        minWidth = constraints.minHeight,
                        maxWidth = constraints.maxHeight,
                        minHeight = constraints.minWidth,
                        maxHeight = constraints.maxWidth
                    )
                )
                layout(placeable.height, placeable.width) {
                    placeable.place(-placeable.width, 0)
                }
            }
    )
}

@Composable
fun IosBottomTabBar(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    favCount: Int,
    queueCount: Int,
    isDark: Boolean
) {
    val barBg = if (isDark) Color(0xF5141416) else Color(0xFAF9F9FB)
    val tabs = listOf(
        Triple("Jelajahi", Icons.Rounded.Search, 0),
        Triple("Favorit", Icons.Rounded.Favorite, favCount),
        Triple("Antrean", Icons.Rounded.QueueMusic, queueCount)
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(barBg)
            .navigationBarsPadding()
    ) {
        HorizontalDivider(thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEachIndexed { index, (label, icon, badgeCount) ->
                val selected = selectedTab == index
                val itemColor = if (selected) IosAccentRed else IosSecondaryLabel
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectTab(index) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = itemColor,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (badgeCount > 0) "$label ($badgeCount)" else label,
                        fontSize = 10.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        color = itemColor
                    )
                }
            }
        }
    }
}

@Composable
fun IosMiniPlayer(
    now: NowPlayingState,
    c: MediaController,
    isDark: Boolean,
    showArtwork: Boolean,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val barBg = if (isDark) Color(0xF22C2C2E) else Color(0xFAFFFFFF)
    val contentColor = if (isDark) Color.White else Color.Black

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(60.dp)
            .shadow(14.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onOpen),
        shape = RoundedCornerShape(16.dp),
        color = barBg
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IosArtwork(url = now.art, size = 42.dp, cornerRadius = 8.dp, showImage = showArtwork)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = now.title.ifEmpty { "Memuat…" },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = contentColor
                )
                if (now.artist.isNotEmpty()) {
                    Text(
                        text = now.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 12.sp,
                        color = IosSecondaryLabel
                    )
                }
            }
            IconButton(onClick = { togglePlayback(c) }) {
                Icon(
                    imageVector = if (now.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = "Putar/Jeda",
                    tint = contentColor,
                    modifier = Modifier.size(28.dp)
                )
            }
            IconButton(onClick = { c.seekToNextMediaItem() }) {
                Icon(
                    imageVector = Icons.Rounded.FastForward,
                    contentDescription = "Berikutnya",
                    tint = contentColor,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

@Composable
fun TrackRowItem(
    track: Track,
    isCurrent: Boolean,
    isPlaying: Boolean,
    isFav: Boolean,
    isOffline: Boolean,
    isDownloading: Boolean,
    showArtwork: Boolean,
    primaryText: Color,
    onClick: () -> Unit,
    onToggleFav: () -> Unit,
    onMoreClick: () -> Unit,
    onRemoveFromPlaylist: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 14.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IosArtwork(url = track.thumb, size = 50.dp, cornerRadius = 8.dp, showImage = showArtwork)
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = if (isCurrent) IosAccentRed else primaryText
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = listOf(
                    track.artist,
                    if (track.durationSec > 0) fmt(track.durationSec * 1000) else ""
                ).filter { it.isNotEmpty() }.joinToString(" • "),
                fontSize = 12.sp,
                color = IosSecondaryLabel,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (isDownloading) {
            CircularProgressIndicator(
                modifier = Modifier
                    .padding(end = 4.dp)
                    .size(15.dp),
                strokeWidth = 2.dp,
                color = IosAccentRed
            )
        } else if (isOffline) {
            Icon(
                imageVector = Icons.Rounded.DownloadDone,
                contentDescription = "Tersimpan Offline",
                tint = Color(0xFF34C759),
                modifier = Modifier
                    .padding(end = 4.dp)
                    .size(17.dp)
            )
        }
        if (isPlaying) {
            Icon(
                imageVector = Icons.Rounded.GraphicEq,
                contentDescription = null,
                tint = IosAccentRed,
                modifier = Modifier.size(18.dp)
            )
        }
        IconButton(onClick = onToggleFav, modifier = Modifier.size(34.dp)) {
            Icon(
                imageVector = if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = "Favorit",
                tint = if (isFav) IosAccentRed else IosSecondaryLabel,
                modifier = Modifier.size(19.dp)
            )
        }
        if (onRemoveFromPlaylist != null) {
            IconButton(onClick = onRemoveFromPlaylist, modifier = Modifier.size(34.dp)) {
                Icon(
                    imageVector = Icons.Rounded.RemoveCircleOutline,
                    contentDescription = "Keluarkan dari Playlist",
                    tint = IosSecondaryLabel,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
        IconButton(onClick = onMoreClick, modifier = Modifier.size(34.dp)) {
            Icon(
                imageVector = Icons.Rounded.MoreVert,
                contentDescription = "Menu",
                tint = IosSecondaryLabel,
                modifier = Modifier.size(19.dp)
            )
        }
    }
}
