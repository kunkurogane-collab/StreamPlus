package com.streamplus.app.data

import android.content.Context
import com.streamplus.app.Track
import org.json.JSONArray
import org.json.JSONObject

object FavoritesStore {
    private const val PREF = "streamplus_favorites"
    private const val KEY = "items_json"

    fun load(ctx: Context): List<Track> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                val url = obj.optString("url")
                if (url.isBlank()) return@mapNotNull null
                Track(
                    url = url,
                    title = obj.optString("title"),
                    artist = obj.optString("artist"),
                    durationSec = obj.optLong("durationSec", 0L),
                    thumb = obj.optString("thumb").takeIf { it.isNotBlank() }
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(ctx: Context, list: List<Track>) {
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(JSONObject().apply {
                put("url", t.url)
                put("title", t.title)
                put("artist", t.artist)
                put("durationSec", t.durationSec)
                put("thumb", t.thumb.orEmpty())
            })
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }
}
