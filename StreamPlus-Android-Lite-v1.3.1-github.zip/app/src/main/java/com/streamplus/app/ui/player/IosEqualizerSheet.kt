package com.streamplus.app.ui.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.streamplus.app.EqState
import com.streamplus.app.ui.components.VerticalBandSlider
import com.streamplus.app.ui.theme.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IosEqualizerSheet(
    eqState: EqState,
    isDark: Boolean,
    onUpdateEq: (
        enabled: Boolean,
        preset: String,
        levels: List<Int>,
        bass: Int,
        loudnessEnabled: Boolean,
        loudnessGainMb: Int,
        skipSilence: Boolean
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val contentColor = if (isDark) Color.White else Color.Black
    val cardBg = if (isDark) IosDarkCard else IosLightCard
    val subBg = if (isDark) IosDarkSearchBg else IosLightSearchBg

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = cardBg,
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = null,
                        tint = IosAccentRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Equalizer & Suara",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                }
                Switch(
                    checked = eqState.enabled,
                    onCheckedChange = { checked ->
                        onUpdateEq(
                            checked,
                            eqState.presetName,
                            eqState.bandLevelsMb,
                            eqState.bassStrength,
                            eqState.loudnessEnabled,
                            eqState.loudnessGainMb,
                            eqState.skipSilence
                        )
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = IosAccentRed
                    )
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Preset Suara",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = IosSecondaryLabel
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EqPresets.forEach { (presetName, presetLevels) ->
                        val active = eqState.presetName == presetName
                        Surface(
                            modifier = Modifier
                                .height(34.dp)
                                .clickable {
                                    val bandCount = eqState.bandLevelsMb.size.coerceAtLeast(1)
                                    val mapped = (0 until bandCount).map { idx ->
                                        (presetLevels.getOrNull(idx) ?: 0)
                                            .coerceIn(eqState.minLevelMb, eqState.maxLevelMb)
                                    }
                                    onUpdateEq(
                                        true,
                                        presetName,
                                        mapped,
                                        eqState.bassStrength,
                                        eqState.loudnessEnabled,
                                        eqState.loudnessGainMb,
                                        eqState.skipSilence
                                    )
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (active && eqState.enabled) IosAccentRed else subBg
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(horizontal = 14.dp)
                            ) {
                                Text(
                                    text = presetName,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (active && eqState.enabled) Color.White else contentColor
                                )
                            }
                        }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = subBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val bands = eqState.bandLevelsMb.size
                    for (b in 0 until bands) {
                        val levelMb = eqState.bandLevelsMb.getOrNull(b) ?: 0
                        val freqHz = eqState.bandFreqsHz.getOrNull(b) ?: 1000
                        val dbVal = levelMb / 100
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (dbVal > 0) "+${dbVal}dB" else "${dbVal}dB",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (eqState.enabled) IosAccentRed else IosSecondaryLabel,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            VerticalBandSlider(
                                value = levelMb.toFloat(),
                                valueRange = eqState.minLevelMb.toFloat()..eqState.maxLevelMb.toFloat(),
                                enabled = eqState.enabled,
                                onValueChange = { newVal ->
                                    val updated = eqState.bandLevelsMb.toMutableList()
                                    if (b < updated.size) updated[b] = newVal.roundToInt()
                                    onUpdateEq(
                                        true,
                                        "Kustom",
                                        updated,
                                        eqState.bassStrength,
                                        eqState.loudnessEnabled,
                                        eqState.loudnessGainMb,
                                        eqState.skipSilence
                                    )
                                },
                                modifier = Modifier
                                    .width(36.dp)
                                    .height(125.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = fmtFreq(freqHz),
                                fontSize = 11.sp,
                                color = IosSecondaryLabel,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bass Boost",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = IosSecondaryLabel
                    )
                    Text(
                        text = "${(eqState.bassStrength / 10)}%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (eqState.enabled && eqState.bassStrength > 0) IosAccentRed else IosSecondaryLabel
                    )
                }
                Slider(
                    value = eqState.bassStrength.toFloat(),
                    valueRange = 0f..1000f,
                    enabled = eqState.enabled,
                    onValueChange = { v ->
                        onUpdateEq(
                            true,
                            eqState.presetName,
                            eqState.bandLevelsMb,
                            v.roundToInt(),
                            eqState.loudnessEnabled,
                            eqState.loudnessGainMb,
                            eqState.skipSilence
                        )
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = IosAccentRed,
                        inactiveTrackColor = Color.Gray.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = subBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Normalisasi Volume (Loudness)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = contentColor
                            )
                            Text(
                                text = "Perkuat audio yang pelan (+${eqState.loudnessGainMb / 100} dB)",
                                fontSize = 11.sp,
                                color = IosSecondaryLabel
                            )
                        }
                        Switch(
                            checked = eqState.loudnessEnabled,
                            onCheckedChange = { checked ->
                                onUpdateEq(
                                    eqState.enabled,
                                    eqState.presetName,
                                    eqState.bandLevelsMb,
                                    eqState.bassStrength,
                                    checked,
                                    eqState.loudnessGainMb,
                                    eqState.skipSilence
                                )
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = IosAccentRed
                            )
                        )
                    }
                    if (eqState.loudnessEnabled) {
                        Slider(
                            value = eqState.loudnessGainMb.toFloat(),
                            valueRange = 0f..1500f,
                            onValueChange = { g ->
                                onUpdateEq(
                                    eqState.enabled,
                                    eqState.presetName,
                                    eqState.bandLevelsMb,
                                    eqState.bassStrength,
                                    true,
                                    g.roundToInt(),
                                    eqState.skipSilence
                                )
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = IosAccentRed,
                                inactiveTrackColor = Color.Gray.copy(alpha = 0.25f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    HorizontalDivider(thickness = 0.5.dp, color = Color.Gray.copy(alpha = 0.25f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Lewati Bagian Hening (Skip Silence)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = contentColor
                            )
                            Text(
                                text = "Cocok untuk podcast, ceramah, atau jeda panjang",
                                fontSize = 11.sp,
                                color = IosSecondaryLabel
                            )
                        }
                        Switch(
                            checked = eqState.skipSilence,
                            onCheckedChange = { checked ->
                                onUpdateEq(
                                    eqState.enabled,
                                    eqState.presetName,
                                    eqState.bandLevelsMb,
                                    eqState.bassStrength,
                                    eqState.loudnessEnabled,
                                    eqState.loudnessGainMb,
                                    checked
                                )
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = IosAccentRed
                            )
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = {
                        val flat = List(eqState.bandLevelsMb.size.coerceAtLeast(5)) { 0 }
                        onUpdateEq(eqState.enabled, "Normal", flat, 0, false, 600, false)
                    }
                ) {
                    Text("Reset Semua", color = IosAccentRed, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
