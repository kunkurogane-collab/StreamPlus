package com.streamplus.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.session.MediaController
import com.streamplus.app.*
import com.streamplus.app.ui.components.*
import com.streamplus.app.ui.player.IosEqualizerSheet
import com.streamplus.app.ui.player.IosFullPlayer
import com.streamplus.app.ui.theme.*
import com.streamplus.app.ui.viewmodel.MainViewModel
import com.streamplus.app.ui.viewmodel.rememberNowPlaying

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    controller: MediaController?,
    sharedText: String?,
    onClearSharedText: () -> Unit,
    onVideoModeChanged: (Boolean) -> Unit,
    isDark: Boolean,
    vm: MainViewModel = viewModel()
) {
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val now = rememberNowPlaying(controller)

    val engineStatus by Engine.status.collectAsState()
    val eqState by EqualizerStore.state.collectAsState()
    val autoDlMode by FavoriteDownloader.mode.collectAsState()
    val offlineUrls by FavoriteDownloader.downloadedUrls.collectAsState()
    val downloadingUrl by FavoriteDownloader.downloadingUrl.collectAsState()
    val offlineBytes by FavoriteDownloader.totalStorageBytes.collectAsState()
    val autoplayRadio by PlaybackSettingsStore.autoplayRadio.collectAsState()
    val liveQueue by PlaybackSettingsStore.liveQueue.collectAsState()
    val radioLoading by PlaybackSettingsStore.radioLoading.collectAsState()

    var trackActionTarget by remember { mutableStateOf<Track?>(null) }
    var playlistPickerTrack by remember { mutableStateOf<Track?>(null) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var pendingExportTrack by remember { mutableStateOf<Track?>(null) }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val storagePerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val t = pendingExportTrack
        pendingExportTrack = null
        if (granted && t != null) vm.exportTrackDirectly(t)
    }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) vm.exportBackupToUri(uri) }

    val importBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.importBackupFromUri(uri) }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    LaunchedEffect(sharedText) {
        val link = sharedText?.let { Regex("https?://\\S+").find(it)?.value }
        if (link != null) {
            vm.query = link
            vm.search(controller, link, autoPlay = true)
            onClearSharedText()
        }
    }

    LaunchedEffect(now.mediaId) {
        vm.recordRecentlyPlayed(now, liveQueue)
    }

    fun requestExportTrack(track: Track) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingExportTrack = track
            storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            vm.exportTrackDirectly(track)
        }
    }

    val bgColor = if (isDark) IosDarkBg else IosLightBg
    val cardColor = if (isDark) IosDarkCard else IosLightCard
    val primaryText = if (isDark) Color.White else Color.Black

    val currentTrackObj = remember(now.mediaId, vm.results, vm.favorites, liveQueue, vm.recentTracks) {
        (liveQueue + vm.results + vm.favorites + vm.recentTracks).firstOrNull { it.url == now.mediaId }
            ?: if (now.mediaId.isNotBlank()) {
                Track(now.mediaId, now.title, now.artist, now.durationMs / 1000L, now.art)
            } else null
    }
    val isCurrentFavorite = currentTrackObj != null && vm.favorites.any { it.url == currentTrackObj.url }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        Scaffold(
            containerColor = bgColor,
            bottomBar = {
                Column {
                    if (now.has && controller != null && !vm.expanded) {
                        IosMiniPlayer(
                            now = now,
                            c = controller,
                            isDark = isDark,
                            showArtwork = vm.video || !vm.audioSaver,
                            onOpen = { vm.expanded = true },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                    IosBottomTabBar(
                        selectedTab = vm.selectedTab,
                        onSelectTab = { vm.selectedTab = it },
                        favCount = vm.favorites.size,
                        queueCount = liveQueue.size,
                        isDark = isDark
                    )
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(bottom = innerPadding.calculateBottomPadding())
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val headerTitle = when (vm.selectedTab) {
                        0 -> "Jelajahi"
                        1 -> "Favorit"
                        else -> "Antrean"
                    }
                    Text(
                        text = headerTitle,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp,
                        color = primaryText,
                        modifier = Modifier.weight(1f)
                    )
                    vm.sleepRemainingMin?.let { mins ->
                        Surface(
                            shape = CircleShape,
                            color = IosAccentRed.copy(alpha = 0.14f),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Bedtime,
                                    contentDescription = null,
                                    tint = IosAccentRed,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "${mins}m",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = IosAccentRed
                                )
                            }
                        }
                    }
                    IconButton(
                        onClick = { vm.showEqSheet = true },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                if (eqState.enabled || eqState.loudnessEnabled) IosAccentRed.copy(alpha = 0.18f)
                                else if (isDark) IosDarkSearchBg else IosLightSearchBg
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = "Equalizer",
                            tint = IosAccentRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { vm.updateYtDlp() },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(if (isDark) IosDarkSearchBg else IosLightSearchBg)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Update yt-dlp",
                            tint = IosAccentRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                when (vm.selectedTab) {
                    0 -> {
                        IosSearchBar(
                            query = vm.query,
                            onQueryChange = vm::onQueryChange,
                            onSearch = {
                                focus.clearFocus()
                                vm.search(controller, autoPlay = vm.query.startsWith("http"))
                            },
                            isDark = isDark
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        IosModeSegmentedControl(
                            video = vm.video,
                            onMode = { v ->
                                vm.setMode(controller, v)
                                onVideoModeChanged(v)
                            },
                            isDark = isDark,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        if (vm.video) {
                            IosQualitySegmentedControl(
                                selectedQuality = vm.videoQuality,
                                onSelectQuality = { vm.setQuality(controller, it) },
                                isDark = isDark,
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else {
                            IosAudioQualitySegmentedControl(
                                audioSaver = vm.audioSaver,
                                onSelectAudioSaver = { vm.setAudioSaver(controller, it) },
                                isDark = isDark,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        if (vm.loading) {
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(CircleShape),
                                color = IosAccentRed
                            )
                        }

                        (vm.message ?: engineStatus)?.let {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = it, color = IosSecondaryLabel, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val showingRecent = vm.results.isEmpty() && vm.recentTracks.isNotEmpty()
                        val listToShow = if (vm.results.isNotEmpty()) vm.results else vm.recentTracks

                        if (showingRecent) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.History,
                                    contentDescription = null,
                                    tint = IosAccentRed,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Baru Diputar (${vm.recentTracks.size})",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = primaryText,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "Putar Semua",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = IosAccentRed,
                                    modifier = Modifier.clickable { vm.playList(controller, vm.recentTracks, 0) }
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Hapus",
                                    fontSize = 12.sp,
                                    color = IosSecondaryLabel,
                                    modifier = Modifier.clickable { vm.clearRecentTracks() }
                                )
                            }
                        }

                        if (listToShow.isEmpty() && !vm.loading) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Rounded.GraphicEq,
                                        contentDescription = null,
                                        tint = IosSecondaryLabel.copy(alpha = 0.5f),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Cari lagu atau tempel tautan YouTube",
                                        color = IosSecondaryLabel,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        } else {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = cardColor
                            ) {
                                LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                    itemsIndexed(listToShow) { i, t ->
                                        TrackRowItem(
                                            track = t,
                                            isCurrent = now.mediaId == t.url,
                                            isPlaying = now.mediaId == t.url && now.playing,
                                            isFav = vm.favorites.any { it.url == t.url },
                                            isOffline = t.url in offlineUrls,
                                            isDownloading = downloadingUrl == t.url,
                                            showArtwork = vm.video || !vm.audioSaver,
                                            primaryText = primaryText,
                                            onClick = { vm.playList(controller, listToShow, i) },
                                            onToggleFav = { vm.toggleFavorite(t) },
                                            onMoreClick = { trackActionTarget = t }
                                        )
                                        if (i < listToShow.lastIndex) {
                                            HorizontalDivider(
                                                modifier = Modifier.padding(start = 76.dp),
                                                thickness = 0.5.dp,
                                                color = Color.Gray.copy(alpha = 0.25f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        IosTextSegmentedControl(
                            labels = listOf("Lagu (${vm.favorites.size})", "Playlist (${vm.playlists.size})", "Backup"),
                            selectedIndex = vm.favSubTab,
                            onSelect = {
                                vm.favSubTab = it
                                vm.openedPlaylistId = null
                            },
                            isDark = isDark,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        when (vm.favSubTab) {
                            0 -> {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = cardColor,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.OfflinePin,
                                                contentDescription = null,
                                                tint = IosAccentRed,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Auto-Download Favorit (${offlineUrls.size}/${vm.favorites.size})",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = primaryText,
                                                modifier = Modifier.weight(1f)
                                            )
                                            if (offlineBytes > 0L) {
                                                Text(
                                                    text = fmtSizeMb(offlineBytes),
                                                    fontSize = 11.sp,
                                                    color = IosSecondaryLabel
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "Hapus",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = IosAccentRed,
                                                    modifier = Modifier.clickable {
                                                        FavoriteDownloader.clearAllOffline(ctx)
                                                        Toast.makeText(ctx, "File offline favorit dihapus", Toast.LENGTH_SHORT).show()
                                                    }
                                                )
                                            }
                                        }
                                        IosAutoDownloadSegmentedControl(
                                            selectedMode = autoDlMode,
                                            onSelectMode = { FavoriteDownloader.setMode(ctx, it) },
                                            isDark = isDark,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                if (vm.favorites.isEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1f),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = Icons.Rounded.FavoriteBorder,
                                                contentDescription = null,
                                                tint = IosSecondaryLabel.copy(alpha = 0.5f),
                                                modifier = Modifier.size(56.dp)
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text("Belum ada lagu favorit tersimpan", color = IosSecondaryLabel, fontSize = 14.sp)
                                        }
                                    }
                                } else {
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                        color = cardColor
                                    ) {
                                        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                            itemsIndexed(vm.favorites) { i, t ->
                                                TrackRowItem(
                                                    track = t,
                                                    isCurrent = now.mediaId == t.url,
                                                    isPlaying = now.mediaId == t.url && now.playing,
                                                    isFav = true,
                                                    isOffline = t.url in offlineUrls,
                                                    isDownloading = downloadingUrl == t.url,
                                                    showArtwork = vm.video || !vm.audioSaver,
                                                    primaryText = primaryText,
                                                    onClick = { vm.playList(controller, vm.favorites, i) },
                                                    onToggleFav = { vm.toggleFavorite(t) },
                                                    onMoreClick = { trackActionTarget = t }
                                                )
                                                if (i < vm.favorites.lastIndex) {
                                                    HorizontalDivider(
                                                        modifier = Modifier.padding(start = 76.dp),
                                                        thickness = 0.5.dp,
                                                        color = Color.Gray.copy(alpha = 0.25f)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            1 -> {
                                val openedPl = vm.playlists.firstOrNull { it.id == vm.openedPlaylistId }
                                if (openedPl != null) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = { vm.openedPlaylistId = null }) {
                                            Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Kembali", tint = IosAccentRed)
                                        }
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(openedPl.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = primaryText)
                                            Text("${openedPl.tracks.size} lagu", fontSize = 12.sp, color = IosSecondaryLabel)
                                        }
                                        if (openedPl.tracks.isNotEmpty()) {
                                            Button(
                                                onClick = { vm.playList(controller, openedPl.tracks, 0) },
                                                colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Putar", fontSize = 13.sp)
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    if (openedPl.tracks.isEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "Playlist masih kosong.\nKetuk ikon titik tiga (⋮) pada lagu mana pun untuk menambahkannya.",
                                                color = IosSecondaryLabel,
                                                fontSize = 13.sp,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    } else {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f),
                                            shape = RoundedCornerShape(14.dp),
                                            color = cardColor
                                        ) {
                                            LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                                itemsIndexed(openedPl.tracks) { idx, t ->
                                                    TrackRowItem(
                                                        track = t,
                                                        isCurrent = now.mediaId == t.url,
                                                        isPlaying = now.mediaId == t.url && now.playing,
                                                        isFav = vm.favorites.any { it.url == t.url },
                                                        isOffline = t.url in offlineUrls,
                                                        isDownloading = downloadingUrl == t.url,
                                                        showArtwork = vm.video || !vm.audioSaver,
                                                        primaryText = primaryText,
                                                        onClick = { vm.playList(controller, openedPl.tracks, idx) },
                                                        onToggleFav = { vm.toggleFavorite(t) },
                                                        onMoreClick = { trackActionTarget = t },
                                                        onRemoveFromPlaylist = {
                                                            vm.removeTrackFromPlaylist(openedPl.id, t.url)
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            newPlaylistName = ""
                                            showCreatePlaylistDialog = true
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                                    ) {
                                        Icon(Icons.Rounded.PlaylistAdd, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Buat Playlist Baru", fontWeight = FontWeight.SemiBold)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    if (vm.playlists.isEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(
                                                    imageVector = Icons.Rounded.LibraryMusic,
                                                    contentDescription = null,
                                                    tint = IosSecondaryLabel.copy(alpha = 0.5f),
                                                    modifier = Modifier.size(56.dp)
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text("Belum ada playlist kustom", color = IosSecondaryLabel, fontSize = 14.sp)
                                            }
                                        }
                                    } else {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f),
                                            shape = RoundedCornerShape(14.dp),
                                            color = cardColor
                                        ) {
                                            LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                                itemsIndexed(vm.playlists) { idx, pl ->
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clickable { vm.openedPlaylistId = pl.id }
                                                            .padding(horizontal = 14.dp, vertical = 12.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        IosArtwork(
                                                            url = pl.tracks.firstOrNull()?.thumb,
                                                            size = 48.dp,
                                                            cornerRadius = 10.dp,
                                                            showImage = vm.video || !vm.audioSaver
                                                        )
                                                        Spacer(modifier = Modifier.width(12.dp))
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(
                                                                text = pl.name,
                                                                fontSize = 15.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = primaryText
                                                            )
                                                            Text(
                                                                text = "${pl.tracks.size} lagu",
                                                                fontSize = 12.sp,
                                                                color = IosSecondaryLabel
                                                            )
                                                        }
                                                        if (pl.tracks.isNotEmpty()) {
                                                            IconButton(onClick = { vm.playList(controller, pl.tracks, 0) }) {
                                                                Icon(Icons.Rounded.PlayArrow, contentDescription = "Putar", tint = IosAccentRed)
                                                            }
                                                        }
                                                        IconButton(onClick = { vm.deletePlaylist(pl.id) }) {
                                                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus", tint = IosSecondaryLabel)
                                                        }
                                                    }
                                                    if (idx < vm.playlists.lastIndex) {
                                                        HorizontalDivider(
                                                            modifier = Modifier.padding(start = 74.dp),
                                                            thickness = 0.5.dp,
                                                            color = Color.Gray.copy(alpha = 0.25f)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            else -> {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = cardColor,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Rounded.SaveAlt,
                                                contentDescription = null,
                                                tint = IosAccentRed,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = "Cadangkan & Pulihkan Data",
                                                fontSize = 17.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = primaryText
                                            )
                                        }
                                        Text(
                                            text = "Simpan seluruh daftar Favorit (${vm.favorites.size} lagu) dan Playlist Kustom (${vm.playlists.size} playlist) ke file JSON agar aman saat update aplikasi atau ganti HP.",
                                            fontSize = 13.sp,
                                            color = IosSecondaryLabel,
                                            lineHeight = 18.sp
                                        )
                                        Button(
                                            onClick = { exportBackupLauncher.launch("StreamPlus_Backup.json") },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                                        ) {
                                            Icon(Icons.Rounded.UploadFile, contentDescription = null)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Ekspor Backup (.json)", fontWeight = FontWeight.SemiBold)
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Rounded.DownloadForOffline, contentDescription = null)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Impor / Pulihkan Backup (.json)", fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }

                    else -> {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = cardColor,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Radio,
                                    contentDescription = null,
                                    tint = IosAccentRed,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Mode Radio (Autoplay Serupa)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = primaryText
                                    )
                                    Text(
                                        text = if (radioLoading) "Mencari rekomendasi lagu serupa…"
                                        else "Otomatis tambah lagu terkait di akhir antrean",
                                        fontSize = 11.sp,
                                        color = IosSecondaryLabel
                                    )
                                }
                                Switch(
                                    checked = autoplayRadio,
                                    onCheckedChange = { vm.setAutoplayRadio(controller, it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = IosAccentRed
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (liveQueue.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Rounded.QueueMusic,
                                        contentDescription = null,
                                        tint = IosSecondaryLabel.copy(alpha = 0.5f),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Antrean pemutaran masih kosong", color = IosSecondaryLabel, fontSize = 14.sp)
                                }
                            }
                        } else {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = cardColor
                            ) {
                                LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                                    itemsIndexed(liveQueue) { i, t ->
                                        TrackRowItem(
                                            track = t,
                                            isCurrent = now.mediaId == t.url,
                                            isPlaying = now.mediaId == t.url && now.playing,
                                            isFav = vm.favorites.any { it.url == t.url },
                                            isOffline = t.url in offlineUrls,
                                            isDownloading = downloadingUrl == t.url,
                                            showArtwork = vm.video || !vm.audioSaver,
                                            primaryText = primaryText,
                                            onClick = {
                                                if (controller != null && i < controller.mediaItemCount) {
                                                    controller.seekToDefaultPosition(i)
                                                    controller.play()
                                                } else {
                                                    vm.playList(controller, liveQueue, i)
                                                }
                                            },
                                            onToggleFav = { vm.toggleFavorite(t) },
                                            onMoreClick = { trackActionTarget = t }
                                        )
                                        if (i < liveQueue.lastIndex) {
                                            HorizontalDivider(
                                                modifier = Modifier.padding(start = 76.dp),
                                                thickness = 0.5.dp,
                                                color = Color.Gray.copy(alpha = 0.25f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = vm.expanded && now.has && controller != null,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)
            ),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMedium)
            )
        ) {
            if (controller != null) {
                IosFullPlayer(
                    now = now,
                    c = controller,
                    video = vm.video,
                    videoQuality = vm.videoQuality,
                    audioSaver = vm.audioSaver,
                    showArtwork = vm.video || !vm.audioSaver,
                    eqState = eqState,
                    autoplayRadio = autoplayRadio,
                    status = engineStatus,
                    isDark = isDark,
                    isFavorite = isCurrentFavorite,
                    sleepRemainingMin = vm.sleepRemainingMin,
                    onToggleFavorite = { currentTrackObj?.let { vm.toggleFavorite(it) } },
                    onAddToPlaylist = { currentTrackObj?.let { playlistPickerTrack = it } },
                    onExportMusicFolder = { currentTrackObj?.let { requestExportTrack(it) } },
                    onMode = { v ->
                        vm.setMode(controller, v)
                        onVideoModeChanged(v)
                    },
                    onQualityChange = { vm.setQuality(controller, it) },
                    onAudioSaverChange = { vm.setAudioSaver(controller, it) },
                    onToggleAutoplay = { vm.setAutoplayRadio(controller, it) },
                    onSetSleepTimer = { vm.setSleepTimer(controller, it) },
                    onOpenEq = { vm.showEqSheet = true },
                    onClose = { vm.expanded = false }
                )
            }
        }

        if (vm.showEqSheet) {
            IosEqualizerSheet(
                eqState = eqState,
                isDark = isDark,
                onUpdateEq = { en, pr, lv, bs, ld, ldg, ss ->
                    vm.updateEqualizer(controller, en, pr, lv, bs, ld, ldg, ss)
                },
                onDismiss = { vm.showEqSheet = false }
            )
        }

        trackActionTarget?.let { target ->
            ModalBottomSheet(
                onDismissRequest = { trackActionTarget = null },
                containerColor = cardColor,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = target.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryText,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (target.artist.isNotBlank()) {
                        Text(text = target.artist, fontSize = 13.sp, color = IosSecondaryLabel)
                    }
                    Spacer(modifier = Modifier.height(6.dp))

                    ListItem(
                        headlineContent = { Text("Simpan ke Folder Musik HP (Music/StreamPlus)") },
                        leadingContent = { Icon(Icons.Rounded.LibraryMusic, contentDescription = null, tint = IosAccentRed) },
                        modifier = Modifier.clickable {
                            trackActionTarget = null
                            requestExportTrack(target)
                        }
                    )
                    ListItem(
                        headlineContent = { Text("Tambah ke Playlist Kustom") },
                        leadingContent = { Icon(Icons.Rounded.PlaylistAdd, contentDescription = null, tint = IosAccentRed) },
                        modifier = Modifier.clickable {
                            trackActionTarget = null
                            playlistPickerTrack = target
                        }
                    )
                    ListItem(
                        headlineContent = {
                            val isFav = vm.favorites.any { it.url == target.url }
                            Text(if (isFav) "Hapus dari Favorit" else "Simpan ke Favorit (Auto-Offline)")
                        },
                        leadingContent = { Icon(Icons.Rounded.Favorite, contentDescription = null, tint = IosAccentRed) },
                        modifier = Modifier.clickable {
                            trackActionTarget = null
                            vm.toggleFavorite(target)
                        }
                    )
                    ListItem(
                        headlineContent = { Text("Bagikan Tautan") },
                        leadingContent = { Icon(Icons.Rounded.IosShare, contentDescription = null, tint = IosAccentRed) },
                        modifier = Modifier.clickable {
                            trackActionTarget = null
                            shareTrack(ctx, target.url, target.title)
                        }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }
            }
        }

        playlistPickerTrack?.let { trackToAdd ->
            ModalBottomSheet(
                onDismissRequest = { playlistPickerTrack = null },
                containerColor = cardColor,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Tambahkan ke Playlist",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryText
                    )
                    Button(
                        onClick = {
                            newPlaylistName = ""
                            showCreatePlaylistDialog = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Buat Playlist Baru")
                    }
                    if (vm.playlists.isEmpty()) {
                        Text(
                            text = "Belum ada playlist. Ketuk tombol di atas untuk membuat.",
                            color = IosSecondaryLabel,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        vm.playlists.forEach { pl ->
                            ListItem(
                                headlineContent = { Text(pl.name, fontWeight = FontWeight.SemiBold) },
                                supportingContent = { Text("${pl.tracks.size} lagu") },
                                leadingContent = { Icon(Icons.Rounded.QueueMusic, contentDescription = null, tint = IosAccentRed) },
                                modifier = Modifier.clickable {
                                    vm.addTrackToPlaylist(pl.id, pl.name, trackToAdd)
                                    playlistPickerTrack = null
                                }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        if (showCreatePlaylistDialog) {
            AlertDialog(
                onDismissRequest = { showCreatePlaylistDialog = false },
                title = { Text("Playlist Baru") },
                text = {
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        singleLine = true,
                        placeholder = { Text("Nama playlist (mis. Santai, Perjalanan)") }
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            vm.createPlaylist(newPlaylistName, playlistPickerTrack)
                            playlistPickerTrack = null
                            showCreatePlaylistDialog = false
                        }
                    ) {
                        Text("Simpan", color = IosAccentRed, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreatePlaylistDialog = false }) {
                        Text("Batal")
                    }
                }
            )
        }
    }
}
