package com.streamplus.app

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.streamplus.app.ui.screens.MainScreen
import com.streamplus.app.ui.theme.StreamPlusTheme

class MainActivity : ComponentActivity() {
    private var sharedText by mutableStateOf<String?>(null)
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var isVideoModeActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        EqualizerStore.loadPrefs(this)
        PlaybackSettingsStore.init(this)
        sharedText = intent.sharedText()

        setContent {
            val isDark = isSystemInDarkTheme()
            StreamPlusTheme(isDark = isDark) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(
                        controller = controller,
                        sharedText = sharedText,
                        onClearSharedText = { sharedText = null },
                        onVideoModeChanged = { enabled ->
                            isVideoModeActive = enabled
                            controller?.let { setVideoTrackEnabled(it, enabled) }
                        },
                        isDark = isDark
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (controllerFuture == null) {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerFuture = MediaController.Builder(this, token).buildAsync().also { f ->
                f.addListener(
                    {
                        controller = f.get().also { setVideoTrackEnabled(it, isVideoModeActive) }
                    },
                    ContextCompat.getMainExecutor(this)
                )
            }
        } else {
            controller?.let { setVideoTrackEnabled(it, isVideoModeActive) }
        }
    }

    override fun onStop() {
        controller?.let { setVideoTrackEnabled(it, false) }
        super.onStop()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        super.onDestroy()
    }

    private fun setVideoTrackEnabled(c: MediaController, enabled: Boolean) {
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !enabled)
            .build()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        sharedText = intent.sharedText()
    }

    private fun Intent.sharedText(): String? =
        if (action == Intent.ACTION_SEND) getStringExtra(Intent.EXTRA_TEXT) else null
}
