package com.streamplus.app.ui.theme

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import java.util.Locale

val IosAccentRed = Color(0xFFFA233B)
val IosLightBg = Color(0xFFF2F2F7)
val IosDarkBg = Color(0xFF000000)
val IosLightCard = Color(0xFFFFFFFF)
val IosDarkCard = Color(0xFF1C1C1E)
val IosLightSearchBg = Color(0xFFE3E3E8)
val IosDarkSearchBg = Color(0xFF2C2C2E)
val IosSecondaryLabel = Color(0xFF8E8E93)

val EqPresets: List<Pair<String, List<Int>>> = listOf(
    "Normal" to listOf(0, 0, 0, 0, 0),
    "Bass Booster" to listOf(900, 600, 0, 0, 0),
    "Pop" to listOf(-200, 300, 600, 300, -200),
    "Rock" to listOf(700, 300, -300, 400, 700),
    "Jazz" to listOf(500, 200, -200, 300, 500),
    "Akustik" to listOf(400, 300, 100, 300, 400),
    "Vokal" to listOf(-300, 100, 600, 400, -100),
    "Treble" to listOf(0, 0, 100, 500, 900)
)

@Composable
fun StreamPlusTheme(
    isDark: Boolean,
    content: @Composable () -> Unit
) {
    val scheme = if (isDark) {
        darkColorScheme(
            primary = IosAccentRed,
            background = IosDarkBg,
            surface = IosDarkCard,
            surfaceVariant = IosDarkSearchBg,
            onBackground = Color.White,
            onSurface = Color.White
        )
    } else {
        lightColorScheme(
            primary = IosAccentRed,
            background = IosLightBg,
            surface = IosLightCard,
            surfaceVariant = IosLightSearchBg,
            onBackground = Color.Black,
            onSurface = Color.Black
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}

fun fmtFreq(hz: Int): String =
    if (hz >= 1000) "${hz / 1000}kHz" else "${hz}Hz"

fun fmtSizeMb(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb < 0.1) "0 MB" else String.format(Locale.US, "%.1f MB", mb)
}

fun shareTrack(ctx: Context, url: String, title: String) {
    if (url.isBlank()) return
    val text = if (title.isNotBlank()) "$title\n$url" else url
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(intent, "Bagikan Tautan"))
}

fun copyLink(ctx: Context, url: String) {
    if (url.isBlank()) return
    val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cb.setPrimaryClip(ClipData.newPlainText("StreamPlus URL", url))
    Toast.makeText(ctx, "Tautan disalin", Toast.LENGTH_SHORT).show()
}
