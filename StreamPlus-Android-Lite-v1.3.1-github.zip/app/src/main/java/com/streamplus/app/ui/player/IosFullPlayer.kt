package com.streamplus.app.ui.player

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.streamplus.app.EqState
import com.streamplus.app.LyricsClient
import com.streamplus.app.LyricsResult
import com.streamplus.app.ui.components.IosAudioQualitySegmentedControl
import com.streamplus.app.ui.components.IosModeSegmentedControl
import com.streamplus.app.ui.components.IosQualitySegmentedControl
import com.streamplus.app.ui.theme.*
import com.streamplus.app.ui.viewmodel.NowPlayingState
import com.streamplus.app.ui.viewmodel.togglePlayback
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerProgress(posState: State<Long>, durMs: Long, onSeek: (Long) -> Unit) {
    var seeking by remember { mutableStateOf<Float?>(null) }
    val dur = durMs.coerceAtLeast(1L)
    val pos = posState.value

    Slider(
        value = (seeking ?: (pos.toFloat() / dur)).coerceIn(0f, 1f),
        onValueChange = { seeking = it },
        onValueChangeFinished = {
            seeking?.let { onSeek((it * dur).toLong()) }
            seeking = null
        },
        colors = SliderDefaults.colors(
            thumbColor = Color.White,
            activeTrackColor = IosAccentRed,
            inactiveTrackColor = Color.Gray.copy(alpha = 0.25f)
        ),
        modifier = Modifier.fillMaxWidth()
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(fmt(seeking?.let { (it * dur).toLong() } ?: pos), fontSize = 11.sp, color = IosSecondaryLabel)
        Text(fmt(durMs), fontSize = 11.sp, color = IosSecondaryLabel)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IosFullPlayer(
    now: NowPlayingState,
    c: MediaController,
    video: Boolean,
    videoQuality: Int,
    audioSaver: Boolean,
    showArtwork: Boolean,
    eqState: EqState,
    autoplayRadio: Boolean,
    status: String?,
    isDark: Boolean,
    isFavorite: Boolean,
    sleepRemainingMin: Int?,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onExportMusicFolder: () -> Unit,
    onMode: (Boolean) -> Unit,
    onQualityChange: (Int) -> Unit,
    onAudioSaverChange: (Boolean) -> Unit,
    onToggleAutoplay: (Boolean) -> Unit,
    onSetSleepTimer: (Int?) -> Unit,
    onOpenEq: () -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)
    val posState = remember { mutableLongStateOf(0L) }
    var showOptionsSheet by remember { mutableStateOf(false) }

    var showLyrics by remember { mutableStateOf(false) }
    var lyricsLoading by remember { mutableStateOf(false) }
    var lyricsResult by remember { mutableStateOf<LyricsResult?>(null) }
    val lyricsListState = rememberLazyListState()

    LaunchedEffect(c, showLyrics) {
        while (true) {
            posState.longValue = c.currentPosition.coerceAtLeast(0L)
            delay(if (showLyrics) 300L else if (c.isPlaying) 500L else 1000L)
        }
    }

    LaunchedEffect(showLyrics, now.mediaId, now.title) {
        if (!showLyrics || now.title.isBlank()) return@LaunchedEffect
        lyricsLoading = true
        lyricsResult = LyricsClient.fetchLyrics(now.title, now.artist, now.durationMs / 1000L)
        lyricsLoading = false
    }

    val activeLyricIndexState = remember {
        derivedStateOf {
            val lines = lyricsResult?.synced.orEmpty()
            if (lines.isEmpty()) -1
            else lines.indexOfLast { it.timeMs <= posState.longValue + 250L }
        }
    }
    val activeLyricIndex = activeLyricIndexState.value

    LaunchedEffect(activeLyricIndex, showLyrics) {
        if (showLyrics && activeLyricIndex >= 0) {
            runCatching {
                lyricsListState.animateScrollToItem((activeLyricIndex - 2).coerceAtLeast(0))
            }
        }
    }

    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    val animatedOffsetY by animateFloatAsState(
        targetValue = dragOffsetY,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "drag_dismiss"
    )

    val artworkScale by animateFloatAsState(
        targetValue = if (now.playing || video || showLyrics) 1.0f else 0.90f,
        animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessLow),
        label = "artwork_scale"
    )

    val sheetBg = if (isDark) Color(0xFF141416) else Color(0xFFFAFAFC)
    val contentColor = if (isDark) Color.White else Color.Black

    Box(
        modifier = Modifier
            .fillMaxSize()
            .offset { IntOffset(0, animatedOffsetY.roundToInt().coerceAtLeast(0)) }
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(sheetBg)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (dragOffsetY > 220f) onClose()
                        dragOffsetY = 0f
                    },
                    onDragCancel = { dragOffsetY = 0f },
                    onVerticalDrag = { change, dragAmount ->
                        change.consume()
                        dragOffsetY = (dragOffsetY + dragAmount).coerceAtLeast(0f)
                    }
                )
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .width(38.dp)
                    .height(5.dp)
                    .clip(CircleShape)
                    .background(Color.Gray.copy(alpha = 0.45f))
                    .clickable { onClose() }
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.16f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Tutup",
                        tint = contentColor
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                IosModeSegmentedControl(
                    video = video,
                    onMode = onMode,
                    isDark = isDark,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(10.dp))
                IconButton(
                    onClick = { showOptionsSheet = true },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.16f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.MoreHoriz,
                        contentDescription = "Opsi Lainnya",
                        tint = IosAccentRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            if (video) {
                IosQualitySegmentedControl(
                    selectedQuality = videoQuality,
                    onSelectQuality = onQualityChange,
                    isDark = isDark,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                IosAudioQualitySegmentedControl(
                    audioSaver = audioSaver,
                    onSelectAudioSaver = onAudioSaverChange,
                    isDark = isDark,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.weight(0.4f))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(if (video && !showLyrics) 16f / 9f else 1f)
                    .scale(artworkScale)
                    .shadow(24.dp, RoundedCornerShape(20.dp))
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (showLyrics) {
                            Brush.verticalGradient(listOf(Color(0xFF1F1F24), Color(0xFF121215)))
                        } else {
                            Brush.linearGradient(listOf(Color(0xFFFA233B), Color(0xFFFF6B81)))
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (showLyrics) {
                    when {
                        lyricsLoading -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = IosAccentRed, modifier = Modifier.size(30.dp))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Mencari lirik lagu…", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                            }
                        }
                        lyricsResult != null && lyricsResult!!.synced.isNotEmpty() -> {
                            val lines = lyricsResult!!.synced
                            LazyColumn(
                                state = lyricsListState,
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 28.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                itemsIndexed(lines) { idx, line ->
                                    val isActive = idx == activeLyricIndex
                                    Text(
                                        text = line.text,
                                        fontSize = if (isActive) 20.sp else 16.sp,
                                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isActive) Color.White else Color.White.copy(alpha = 0.42f),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { c.seekTo(line.timeMs) }
                                    )
                                }
                            }
                        }
                        lyricsResult != null && !lyricsResult!!.plain.isNullOrBlank() -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(20.dp)
                            ) {
                                Text(
                                    text = lyricsResult!!.plain.orEmpty(),
                                    fontSize = 15.sp,
                                    lineHeight = 22.sp,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }
                        }
                        else -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Lyrics,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.4f),
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Lirik tidak ditemukan untuk lagu ini",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else if (video) {
                    AndroidView(
                        factory = { PlayerView(it).apply { useController = false } },
                        update = {
                            it.player = c
                            it.keepScreenOn = now.playing
                        },
                        onRelease = {
                            it.keepScreenOn = false
                            it.player = null
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Rounded.MusicNote,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(96.dp)
                    )
                    if (showArtwork && !now.art.isNullOrBlank()) {
                        AsyncImage(
                            model = now.art,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.4f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = now.title.ifEmpty { "Memuat…" },
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = now.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = IosAccentRed
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = { showLyrics = !showLyrics },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (showLyrics) IosAccentRed.copy(alpha = 0.18f) else Color.Gray.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lyrics,
                        contentDescription = "Lirik",
                        tint = if (showLyrics) IosAccentRed else contentColor,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = onOpenEq,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (eqState.enabled || eqState.loudnessEnabled) IosAccentRed.copy(alpha = 0.18f) else Color.Gray.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = "Equalizer",
                        tint = if (eqState.enabled || eqState.loudnessEnabled) IosAccentRed else contentColor,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorit",
                        tint = IosAccentRed,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = { shareTrack(ctx, now.mediaId, now.title) },
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Gray.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.IosShare,
                        contentDescription = "Bagikan",
                        tint = IosAccentRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (eqState.enabled) {
                    AssistChip(
                        onClick = onOpenEq,
                        leadingIcon = {
                            Icon(Icons.Rounded.GraphicEq, contentDescription = null, modifier = Modifier.size(14.dp), tint = IosAccentRed)
                        },
                        label = { Text("EQ: ${eqState.presetName}", fontSize = 11.sp) }
                    )
                }
                if (now.speed != 1.0f) {
                    AssistChip(
                        onClick = { showOptionsSheet = true },
                        label = { Text("${now.speed}x", fontSize = 11.sp) }
                    )
                }
                if (sleepRemainingMin != null) {
                    AssistChip(
                        onClick = { showOptionsSheet = true },
                        leadingIcon = {
                            Icon(Icons.Rounded.Bedtime, contentDescription = null, modifier = Modifier.size(14.dp))
                        },
                        label = { Text("Tidur: ${sleepRemainingMin}m", fontSize = 11.sp) }
                    )
                }
                status?.let {
                    Text(
                        text = it,
                        color = IosSecondaryLabel,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            PlayerProgress(
                posState = posState,
                durMs = now.durationMs,
                onSeek = { ms ->
                    c.seekTo(ms)
                    posState.longValue = ms
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { c.shuffleModeEnabled = !now.shuffle },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shuffle,
                        contentDescription = "Acak",
                        tint = if (now.shuffle) IosAccentRed else IosSecondaryLabel,
                        modifier = Modifier.size(22.dp)
                    )
                }

                IconButton(onClick = { c.seekToPrevious() }, modifier = Modifier.size(54.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.FastRewind,
                        contentDescription = "Sebelumnya",
                        tint = contentColor,
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(onClick = { togglePlayback(c) }, modifier = Modifier.size(72.dp)) {
                    Icon(
                        imageVector = if (now.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = "Putar/Jeda",
                        tint = contentColor,
                        modifier = Modifier.size(56.dp)
                    )
                }

                IconButton(onClick = { c.seekToNextMediaItem() }, modifier = Modifier.size(54.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.FastForward,
                        contentDescription = "Berikutnya",
                        tint = contentColor,
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(
                    onClick = {
                        c.repeatMode = when (now.repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                    },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = if (now.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        contentDescription = "Ulangi",
                        tint = if (now.repeatMode != Player.REPEAT_MODE_OFF) IosAccentRed else IosSecondaryLabel,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        if (showOptionsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showOptionsSheet = false },
                containerColor = if (isDark) IosDarkCard else IosLightCard,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Opsi Pemutaran & File",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                showOptionsSheet = false
                                onExportMusicFolder()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                        ) {
                            Icon(Icons.Rounded.LibraryMusic, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simpan ke Musik HP", fontSize = 12.sp, maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = {
                                showOptionsSheet = false
                                onAddToPlaylist()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.PlaylistAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ke Playlist", fontSize = 12.sp, maxLines = 1)
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isDark) IosDarkSearchBg else IosLightSearchBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Radio,
                                contentDescription = null,
                                tint = IosAccentRed,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Mode Radio (Autoplay Serupa)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = contentColor
                                )
                                Text(
                                    text = "Putar lagu terkait otomatis setelah antrean habis",
                                    fontSize = 11.sp,
                                    color = IosSecondaryLabel
                                )
                            }
                            Switch(
                                checked = autoplayRadio,
                                onCheckedChange = onToggleAutoplay,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = IosAccentRed
                                )
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showOptionsSheet = false
                                onOpenEq()
                            },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isDark) IosDarkSearchBg else IosLightSearchBg
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.GraphicEq,
                                contentDescription = null,
                                tint = IosAccentRed,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Equalizer, Loudness & Skip Silence",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = contentColor
                                )
                                Text(
                                    text = if (eqState.enabled) "EQ: ${eqState.presetName}" else "Ketuk untuk atur efek suara",
                                    fontSize = 12.sp,
                                    color = IosSecondaryLabel
                                )
                            }
                            Icon(
                                imageVector = Icons.Rounded.ChevronRight,
                                contentDescription = null,
                                tint = IosSecondaryLabel
                            )
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Kecepatan Pemutaran",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosSecondaryLabel
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                                val active = now.speed == spd
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .clickable { c.playbackParameters = PlaybackParameters(spd) },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (active) IosAccentRed else (if (isDark) IosDarkSearchBg else IosLightSearchBg)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "${spd}x",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (active) Color.White else contentColor
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Sleep Timer (Mati Otomatis)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosSecondaryLabel
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val timers = listOf<Pair<String, Int?>>(
                                "Mati" to null,
                                "15m" to 15,
                                "30m" to 30,
                                "45m" to 45,
                                "60m" to 60
                            )
                            timers.forEach { (label, mins) ->
                                val active = sleepRemainingMin == mins
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .clickable {
                                            onSetSleepTimer(mins)
                                            showOptionsSheet = false
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (active) IosAccentRed else (if (isDark) IosDarkSearchBg else IosLightSearchBg)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = label,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (active) Color.White else contentColor
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Kualitas Audio (Hemat Kuota)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosSecondaryLabel
                        )
                        IosAudioQualitySegmentedControl(
                            audioSaver = audioSaver,
                            onSelectAudioSaver = { saver ->
                                onAudioSaverChange(saver)
                                showOptionsSheet = false
                            },
                            isDark = isDark,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Resolusi Video Maksimal",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosSecondaryLabel
                        )
                        IosQualitySegmentedControl(
                            selectedQuality = videoQuality,
                            onSelectQuality = { q ->
                                onQualityChange(q)
                                showOptionsSheet = false
                            },
                            isDark = isDark,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                copyLink(ctx, now.mediaId)
                                showOptionsSheet = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Salin Link", fontSize = 13.sp)
                        }
                        Button(
                            onClick = {
                                shareTrack(ctx, now.mediaId, now.title)
                                showOptionsSheet = false
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IosAccentRed)
                        ) {
                            Icon(Icons.Rounded.IosShare, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bagikan", fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
