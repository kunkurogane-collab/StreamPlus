package com.streamplus.app.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import com.streamplus.app.AutoDownloadMode
import com.streamplus.app.CMD_SET_AUDIO_SAVER
import com.streamplus.app.CMD_SET_AUTOPLAY
import com.streamplus.app.CMD_SET_EQ
import com.streamplus.app.CMD_SET_MODE
import com.streamplus.app.CMD_SET_QUALITY
import com.streamplus.app.CMD_SET_QUEUE
import com.streamplus.app.CustomPlaylist
import com.streamplus.app.Engine
import com.streamplus.app.EqualizerStore
import com.streamplus.app.FavoriteDownloader
import com.streamplus.app.LibraryBackupManager
import com.streamplus.app.MusicExporter
import com.streamplus.app.PlaybackSettingsStore
import com.streamplus.app.PlaylistStore
import com.streamplus.app.RecentlyPlayedStore
import com.streamplus.app.Track
import com.streamplus.app.data.FavoritesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class NowPlayingState(
    val mediaId: String = "",
    val title: String = "",
    val artist: String = "",
    val art: String? = null,
    val playing: Boolean = false,
    val has: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1.0f,
    val currentIndex: Int = 0
)

fun togglePlayback(c: MediaController) {
    val st = c.playbackState
    if (c.playWhenReady && st != Player.STATE_IDLE && st != Player.STATE_ENDED) {
        c.pause()
    } else {
        if (st == Player.STATE_IDLE) c.prepare()
        if (st == Player.STATE_ENDED) c.seekToDefaultPosition()
        c.play()
    }
}

@Composable
fun rememberNowPlaying(c: MediaController?): NowPlayingState {
    var now by remember { mutableStateOf(NowPlayingState()) }
    DisposableEffect(c) {
        if (c == null) {
            onDispose { }
        } else {
            fun upd() {
                now = NowPlayingState(
                    mediaId = c.currentMediaItem?.mediaId.orEmpty(),
                    title = c.mediaMetadata.title?.toString().orEmpty(),
                    artist = c.mediaMetadata.artist?.toString().orEmpty(),
                    art = c.mediaMetadata.artworkUri?.toString(),
                    playing = c.playWhenReady &&
                        c.playbackState != Player.STATE_IDLE &&
                        c.playbackState != Player.STATE_ENDED,
                    has = c.mediaItemCount > 0,
                    durationMs = c.duration.coerceAtLeast(0L),
                    shuffle = c.shuffleModeEnabled,
                    repeatMode = c.repeatMode,
                    speed = c.playbackParameters.speed,
                    currentIndex = c.currentMediaItemIndex
                )
            }
            val l = object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = upd()
            }
            c.addListener(l)
            upd()
            onDispose { c.removeListener(l) }
        }
    }
    return now
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val ctx: Context get() = getApplication()
    private val appPrefs = ctx.getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE)

    var selectedTab by mutableIntStateOf(0)
    var favSubTab by mutableIntStateOf(0)
    var query by mutableStateOf("")
    var results by mutableStateOf<List<Track>>(emptyList())
    var favorites by mutableStateOf<List<Track>>(FavoritesStore.load(ctx))
    var recentTracks by mutableStateOf<List<Track>>(RecentlyPlayedStore.load(ctx))
    var playlists by mutableStateOf<List<CustomPlaylist>>(PlaylistStore.load(ctx))
    var openedPlaylistId by mutableStateOf<String?>(null)

    var loading by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var video by mutableStateOf(false)
    var videoQuality by mutableIntStateOf(720)
    var audioSaver by mutableStateOf(appPrefs.getBoolean("audio_saver", true))
    var expanded by mutableStateOf(false)
    var showEqSheet by mutableStateOf(false)
    var sleepRemainingMin by mutableStateOf<Int?>(null)

    private var sleepJob: Job? = null

    init {
        FavoriteDownloader.init(ctx)
        FavoriteDownloader.syncFavorites(ctx, favorites)
    }

    fun onQueryChange(newQuery: String) {
        query = newQuery
        if (newQuery.isEmpty()) results = emptyList()
    }

    fun search(
        controller: MediaController?,
        text: String = query,
        autoPlay: Boolean = false
    ) {
        val q = text.trim()
        if (q.isEmpty() || loading) return
        selectedTab = 0
        if (!autoPlay) expanded = false
        loading = true
        message = null
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { Engine.query(ctx, q) } }
                .onSuccess { list ->
                    results = list
                    if (list.isEmpty()) {
                        message = "Tidak ada hasil"
                    } else if (autoPlay) {
                        playList(controller, list, 0)
                    }
                }
                .onFailure { err ->
                    message = "Gagal: ${err.message?.take(160)}\n(Jika baru dibuka, tunggu sebentar lalu coba lagi.)"
                }
            loading = false
        }
    }

    fun updateYtDlp() {
        message = "Memperbarui yt-dlp…"
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { Engine.update(ctx) }
            message = "yt-dlp: $r"
        }
    }

    fun playList(controller: MediaController?, list: List<Track>, startIndex: Int) {
        val ctrl = controller ?: run {
            message = "Pemutar belum siap, coba lagi sebentar."
            return
        }
        if (list.isEmpty()) return
        PlaybackSettingsStore.liveQueue.value = list
        val args = Bundle().apply {
            putStringArrayList("urls", ArrayList(list.map { it.url }))
            putStringArrayList("titles", ArrayList(list.map { it.title }))
            putStringArrayList("artists", ArrayList(list.map { it.artist }))
            putStringArrayList("thumbs", ArrayList(list.map { it.thumb.orEmpty() }))
            putLongArray("durations", list.map { it.durationSec }.toLongArray())
            putInt("start", startIndex)
            putBoolean("video", video)
            putInt("quality", videoQuality)
            putBoolean("audioSaver", audioSaver)
        }
        ctrl.sendCustomCommand(SessionCommand(CMD_SET_QUEUE, Bundle.EMPTY), args)
    }

    fun setMode(controller: MediaController?, v: Boolean) {
        video = v
        controller?.sendCustomCommand(
            SessionCommand(CMD_SET_MODE, Bundle.EMPTY),
            Bundle().apply {
                putBoolean("video", v)
                putInt("quality", videoQuality)
                putBoolean("audioSaver", audioSaver)
            }
        )
    }

    fun setAudioSaver(controller: MediaController?, saver: Boolean) {
        audioSaver = saver
        appPrefs.edit().putBoolean("audio_saver", saver).apply()
        controller?.sendCustomCommand(
            SessionCommand(CMD_SET_AUDIO_SAVER, Bundle.EMPTY),
            Bundle().apply { putBoolean("audioSaver", saver) }
        )
        val label = if (saver) "Mode Hemat Kuota (~48k) aktif" else "Mode Audio HD (~128k) aktif"
        Toast.makeText(ctx, label, Toast.LENGTH_SHORT).show()
    }

    fun setQuality(controller: MediaController?, q: Int) {
        videoQuality = q
        controller?.sendCustomCommand(
            SessionCommand(CMD_SET_QUALITY, Bundle.EMPTY),
            Bundle().apply { putInt("quality", q) }
        )
        Toast.makeText(ctx, "Resolusi video maksimal: ${q}p", Toast.LENGTH_SHORT).show()
    }

    fun setAutoplayRadio(controller: MediaController?, enabled: Boolean) {
        PlaybackSettingsStore.setAutoplayRadio(ctx, enabled)
        controller?.sendCustomCommand(
            SessionCommand(CMD_SET_AUTOPLAY, Bundle.EMPTY),
            Bundle().apply { putBoolean("autoplay", enabled) }
        )
    }

    fun updateEqualizer(
        controller: MediaController?,
        enabled: Boolean,
        preset: String,
        levels: List<Int>,
        bass: Int,
        loudnessEnabled: Boolean,
        loudnessGainMb: Int,
        skipSilence: Boolean
    ) {
        val updated = EqualizerStore.state.value.copy(
            enabled = enabled,
            presetName = preset,
            bandLevelsMb = levels,
            bassStrength = bass,
            loudnessEnabled = loudnessEnabled,
            loudnessGainMb = loudnessGainMb,
            skipSilence = skipSilence
        )
        EqualizerStore.state.value = updated
        EqualizerStore.applyCurrentState(ctx)
        controller?.sendCustomCommand(
            SessionCommand(CMD_SET_EQ, Bundle.EMPTY),
            Bundle().apply {
                putBoolean("enabled", enabled)
                putString("preset", preset)
                putInt("bass", bass)
                putIntegerArrayList("levels", ArrayList(levels))
                putBoolean("loudnessEnabled", loudnessEnabled)
                putInt("loudnessGain", loudnessGainMb)
                putBoolean("skipSilence", skipSilence)
            }
        )
    }

    fun toggleFavorite(track: Track) {
        val exists = favorites.any { it.url == track.url }
        val updated = if (exists) {
            FavoriteDownloader.deleteOfflineForUrl(ctx, track.url)
            favorites.filterNot { it.url == track.url }
        } else {
            listOf(track) + favorites
        }
        favorites = updated
        FavoritesStore.save(ctx, updated)
        FavoriteDownloader.syncFavorites(ctx, updated)
        if (!exists && FavoriteDownloader.mode.value != AutoDownloadMode.OFF) {
            Toast.makeText(ctx, "Ditambahkan ke Favorit (auto-download antre)", Toast.LENGTH_SHORT).show()
        }
    }

    fun recordRecentlyPlayed(now: NowPlayingState, liveQueue: List<Track>) {
        val id = now.mediaId
        if (id.isBlank()) return
        val found = (liveQueue + results + favorites + recentTracks).firstOrNull { it.url == id }
            ?: Track(id, now.title.ifBlank { "Lagu" }, now.artist, now.durationMs / 1000L, now.art)
        if (found.title.isNotBlank()) {
            recentTracks = RecentlyPlayedStore.record(ctx, found)
        }
    }

    fun clearRecentTracks() {
        RecentlyPlayedStore.clear(ctx)
        recentTracks = emptyList()
    }

    fun createPlaylist(name: String, initialTrack: Track? = null) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        playlists = PlaylistStore.createPlaylist(ctx, trimmed)
        if (initialTrack != null) {
            val createdId = playlists.firstOrNull()?.id
            if (createdId != null) {
                playlists = PlaylistStore.addTrack(ctx, createdId, initialTrack)
                Toast.makeText(ctx, "Ditambahkan ke $trimmed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun addTrackToPlaylist(playlistId: String, playlistName: String, track: Track) {
        playlists = PlaylistStore.addTrack(ctx, playlistId, track)
        Toast.makeText(ctx, "Ditambahkan ke $playlistName", Toast.LENGTH_SHORT).show()
    }

    fun removeTrackFromPlaylist(playlistId: String, trackUrl: String) {
        playlists = PlaylistStore.removeTrack(ctx, playlistId, trackUrl)
    }

    fun deletePlaylist(playlistId: String) {
        playlists = PlaylistStore.deletePlaylist(ctx, playlistId)
        Toast.makeText(ctx, "Playlist dihapus", Toast.LENGTH_SHORT).show()
    }

    fun exportTrackDirectly(track: Track) {
        viewModelScope.launch {
            Toast.makeText(ctx, "Menyimpan ke Music/StreamPlus…", Toast.LENGTH_SHORT).show()
            val res = withContext(Dispatchers.IO) { MusicExporter.exportTrackToPublicMusic(ctx, track) }
            Toast.makeText(ctx, res.getOrElse { "Gagal: ${it.message}" }, Toast.LENGTH_LONG).show()
        }
    }

    fun exportBackupToUri(uri: Uri) {
        runCatching {
            val jsonStr = LibraryBackupManager.exportJson(favorites, playlists)
            ctx.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(jsonStr.toByteArray(Charsets.UTF_8))
            }
            Toast.makeText(ctx, "Backup berhasil disimpan!", Toast.LENGTH_SHORT).show()
        }.onFailure {
            Toast.makeText(ctx, "Gagal ekspor backup: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun importBackupFromUri(uri: Uri) {
        runCatching {
            val raw = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("File tidak dapat dibaca")
            val (mergedFavs, mergedPls, counts) = LibraryBackupManager.importJson(favorites, playlists, raw)
            favorites = mergedFavs
            playlists = mergedPls
            FavoritesStore.save(ctx, mergedFavs)
            PlaylistStore.save(ctx, mergedPls)
            FavoriteDownloader.syncFavorites(ctx, mergedFavs)
            Toast.makeText(
                ctx,
                "Impor selesai: +${counts.first} favorit, +${counts.second} playlist",
                Toast.LENGTH_LONG
            ).show()
        }.onFailure {
            Toast.makeText(ctx, "File backup tidak valid: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun setSleepTimer(controller: MediaController?, minutes: Int?) {
        sleepJob?.cancel()
        sleepRemainingMin = minutes
        val msg = if (minutes != null) "Sleep timer diatur: $minutes menit" else "Sleep timer dimatikan"
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

        if (minutes != null && minutes > 0) {
            sleepJob = viewModelScope.launch {
                var rem = minutes
                while (rem > 0) {
                    delay(60_000L)
                    rem -= 1
                    sleepRemainingMin = rem
                }
                controller?.pause()
                sleepRemainingMin = null
                Toast.makeText(ctx, "Sleep timer selesai — pemutaran dijeda", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
