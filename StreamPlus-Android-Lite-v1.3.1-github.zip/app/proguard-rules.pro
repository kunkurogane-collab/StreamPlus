-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Paket utama StreamPlus
-keep class com.streamplus.app.** { *; }
-keepclassmembers class com.streamplus.app.** { *; }

# youtubedl-android (JNI & Python runtime reflection)
-keep class com.yausername.** { *; }
-dontwarn com.yausername.**

# AndroidX Media3
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-dontwarn kotlinx.coroutines.**
