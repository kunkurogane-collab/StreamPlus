@file:OptIn(UnstableApi::class)

package com.streamplus.app

import android.content.Context
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val CMD_SET_QUEUE = "com.streamplus.app.SET_QUEUE"
const val CMD_SET_MODE = "com.streamplus.app.SET_MODE"
const val CMD_SET_QUALITY = "com.streamplus.app.SET_QUALITY"
const val CMD_SET_AUDIO_SAVER = "com.streamplus.app.SET_AUDIO_SAVER"
const val CMD_SET_EQ = "com.streamplus.app.SET_EQ"
const val CMD_SET_AUDIO_ENHANCE = "com.streamplus.app.SET_AUDIO_ENHANCE"
const val CMD_SET_AUTO_RADIO = "com.streamplus.app.SET_AUTO_RADIO"

object AutoRadioBus {
    val appendedTracks = MutableSharedFlow<List<Track>>(extraBufferCapacity = 8)
}

data class EqState(
    val enabled: Boolean = false,
    val presetName: String = "Normal",
    val bandFreqsHz: List<Int> = listOf(60, 230, 910, 3600, 14000),
    val bandLevelsMb: List<Int> = listOf(0, 0, 0, 0, 0),
    val minLevelMb: Int = -1500,
    val maxLevelMb: Int = 1500,
    val bassStrength: Int = 0
)

object EqualizerStore {
    private const val PREF = "streamplus_eq"
    val state = MutableStateFlow(EqState())

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var boundSessionId: Int = C.AUDIO_SESSION_ID_UNSET

    fun loadPrefs(ctx: Context) {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val enabled = p.getBoolean("enabled", false)
        val preset = p.getString("preset", "Normal") ?: "Normal"
        val bass = p.getInt("bass", 0).coerceIn(0, 1000)
        val rawLevels = p.getString("levels", null)
        val levels = rawLevels?.split(",")?.mapNotNull { it.toIntOrNull() }?.takeIf { it.isNotEmpty() }
            ?: listOf(0, 0, 0, 0, 0)
        state.value = state.value.copy(
            enabled = enabled,
            presetName = preset,
            bandLevelsMb = levels,
            bassStrength = bass
        )
    }

    fun savePrefs(ctx: Context, s: EqState) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", s.enabled)
            .putString("preset", s.presetName)
            .putInt("bass", s.bassStrength)
            .putString("levels", s.bandLevelsMb.joinToString(","))
            .apply()
    }

    @Synchronized
    fun attachToSession(ctx: Context, sessionId: Int) {
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        if (boundSessionId != sessionId) {
            release()
            boundSessionId = sessionId
            runCatching {
                val eq = Equalizer(0, sessionId)
                val bands = eq.numberOfBands.toInt().coerceAtLeast(1)
                val range = eq.bandLevelRange
                val minMb = range.getOrNull(0)?.toInt() ?: -1500
                val maxMb = range.getOrNull(1)?.toInt() ?: 1500
                val freqs = (0 until bands).map { b -> (eq.getCenterFreq(b.toShort()) / 1000) }
                val currentLevels = state.value.bandLevelsMb
                val normalizedLevels = (0 until bands).map { b ->
                    (currentLevels.getOrNull(b) ?: 0).coerceIn(minMb, maxMb)
                }
                state.value = state.value.copy(
                    bandFreqsHz = freqs,
                    bandLevelsMb = normalizedLevels,
                    minLevelMb = minMb,
                    maxLevelMb = maxMb
                )
                equalizer = eq
            }
            runCatching {
                bassBoost = BassBoost(0, sessionId)
            }
            runCatching {
                loudnessEnhancer = LoudnessEnhancer(sessionId)
            }
        }
        applyCurrentState(ctx)
    }

    @Synchronized
    fun applyCurrentState(ctx: Context) {
        val s = state.value
        savePrefs(ctx, s)
        runCatching {
            equalizer?.let { eq ->
                eq.enabled = s.enabled
                val bands = eq.numberOfBands.toInt()
                for (b in 0 until bands) {
                    val lvl = (s.bandLevelsMb.getOrNull(b) ?: 0)
                        .coerceIn(s.minLevelMb, s.maxLevelMb)
                        .toShort()
                    eq.setBandLevel(b.toShort(), lvl)
                }
            }
        }
        runCatching {
            bassBoost?.let { bb ->
                bb.enabled = s.enabled && s.bassStrength > 0
                if (bb.strengthSupported) {
                    bb.setStrength(s.bassStrength.coerceIn(0, 1000).toShort())
                }
            }
        }
        runCatching {
            loudnessEnhancer?.let { le ->
                val normalizeEnabled = AudioEnhancePrefs.isLoudnessNormalize(ctx)
                le.setTargetGain(if (normalizeEnabled) 350 else 0)
                le.enabled = normalizeEnabled
            }
        }
    }

    @Synchronized
    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { loudnessEnhancer?.release() }
        equalizer = null
        bassBoost = null
        loudnessEnhancer = null
        boundSessionId = C.AUDIO_SESSION_ID_UNSET
    }
}

private object MediaDiskCache {
    @Volatile private var cache: SimpleCache? = null

    @Synchronized
    fun get(ctx: Context): SimpleCache {
        cache?.let { return it }
        val dir = File(ctx.applicationContext.cacheDir, "media_stream_cache")
        val evictor = LeastRecentlyUsedCacheEvictor(150L * 1024L * 1024L)
        val dbProvider = StandaloneDatabaseProvider(ctx.applicationContext)
        return SimpleCache(dir, evictor, dbProvider).also { cache = it }
    }

    @Synchronized
    fun release() {
        runCatching { cache?.release() }
        cache = null
    }
}

/** Pemutar + antrean hidup di service: tetap jalan di background / layar mati. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var exo: ExoPlayer? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var prefetchJob: Job? = null
    private var favDownloadResumeJob: Job? = null
    private var autoRadioJob: Job? = null

    @Volatile private var audioOnly = true
    @Volatile private var audioSaver = true
    @Volatile private var maxQuality = 720
    @Volatile private var autoRadio = true
    @Volatile private var lastAutoRadioSeedUrl: String? = null
    @Volatile private var lastRecordedHistoryUrl: String? = null

    private val resolver = object : ResolvingDataSource.Resolver {
        override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
            if (dataSpec.uri.scheme != "yt") return dataSpec
            val target = dataSpec.uri.getQueryParameter("u") ?: return dataSpec
            if (audioOnly) {
                FavoriteOfflineManager.getLocalFile(this@PlaybackService, target)?.let { localFile ->
                    return dataSpec.buildUpon()
                        .setUri(Uri.fromFile(localFile))
                        .setKey("offline:$target")
                        .build()
                }
            }
            val real = Engine.resolve(this@PlaybackService, target, audioOnly, maxQuality, audioSaver)
            val modeTag = when {
                !audioOnly -> "v$maxQuality"
                audioSaver -> "as"
                else -> "an"
            }
            return dataSpec.buildUpon()
                .setUri(Uri.parse(real))
                .setKey("$modeTag:$target")
                .build()
        }
    }

    private fun buildMediaItem(track: Track): MediaItem =
        MediaItem.Builder()
            .setUri(ytUri(track.url))
            .setMediaId(track.url)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(track.title)
                    .setArtist(track.artist)
                    .setArtworkUri(track.thumb?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) })
                    .build()
            ).build()

    private fun recordCurrentTrackToHistory(player: ExoPlayer) {
        val item = player.currentMediaItem ?: return
        val url = item.mediaId
        if (!url.startsWith("http") || url == lastRecordedHistoryUrl) return
        lastRecordedHistoryUrl = url
        val meta = item.mediaMetadata
        val durSec = (player.duration.takeIf { it > 0L } ?: 0L) / 1000L
        val track = Track(
            url = url,
            title = meta.title?.toString().orEmpty(),
            artist = meta.artist?.toString().orEmpty(),
            durationSec = durSec,
            thumb = meta.artworkUri?.toString()
        )
        serviceScope.launch {
            HistoryStore.recordPlay(this@PlaybackService, track)
        }
    }

    private fun checkAndTriggerAutoRadio(player: ExoPlayer) {
        if (!autoRadio) return
        if (player.repeatMode != Player.REPEAT_MODE_OFF) return
        val count = player.mediaItemCount
        if (count == 0 || player.currentMediaItemIndex < count - 1) return

        val currentItem = player.currentMediaItem ?: return
        val seedUrl = currentItem.mediaId
        if (!seedUrl.startsWith("http") || seedUrl == lastAutoRadioSeedUrl) return
        if (autoRadioJob?.isActive == true) return

        val title = currentItem.mediaMetadata.title?.toString().orEmpty()
        val artist = currentItem.mediaMetadata.artist?.toString().orEmpty()
        if (title.isBlank()) return

        val excludeUrls = (0 until count).mapNotNull { idx ->
            player.getMediaItemAt(idx).mediaId.takeIf { it.startsWith("http") }
        }.toSet()

        lastAutoRadioSeedUrl = seedUrl
        autoRadioJob = serviceScope.launch {
            val related = runCatching {
                Engine.queryRelated(this@PlaybackService, title, artist, excludeUrls)
            }.getOrDefault(emptyList())

            if (related.isNotEmpty()) {
                withContext(Dispatchers.Main) {
                    val p = exo ?: return@withContext
                    if (!autoRadio || p.repeatMode != Player.REPEAT_MODE_OFF) return@withContext
                    val currentUrls = (0 until p.mediaItemCount).map { p.getMediaItemAt(it).mediaId }.toSet()
                    val filtered = related.filterNot { currentUrls.contains(it.url) }
                    if (filtered.isNotEmpty()) {
                        p.addMediaItems(filtered.map { buildMediaItem(it) })
                        AutoRadioBus.appendedTracks.tryEmit(filtered)
                        schedulePrefetchUpcoming()
                    }
                }
            }
        }
    }

    private fun schedulePrefetchUpcoming() {
        val p = exo ?: return
        val count = p.mediaItemCount
        if (count <= 1) return
        val currentIdx = p.currentMediaItemIndex
        val lookahead = if (audioOnly && audioSaver) listOf(currentIdx + 1) else listOf(currentIdx + 1, currentIdx + 2)
        val upcomingUrls = lookahead
            .filter { it in 0 until count }
            .mapNotNull { idx -> p.getMediaItemAt(idx).mediaId.takeIf { it.startsWith("http") } }
        if (upcomingUrls.isEmpty()) return

        val isAudio = audioOnly
        val qual = maxQuality
        val saver = audioSaver
        prefetchJob?.cancel()
        prefetchJob = serviceScope.launch {
            delay(1200L)
            for (nextUrl in upcomingUrls) {
                if (isAudio && FavoriteOfflineManager.isDownloaded(this@PlaybackService, nextUrl)) continue
                Engine.prefetch(this@PlaybackService, nextUrl, isAudio, qual, saver)
            }
        }
    }

    private fun scheduleFavoriteDownloadAfterStableReady(player: ExoPlayer) {
        favDownloadResumeJob?.cancel()
        favDownloadResumeJob = serviceScope.launch {
            delay(4_000L)
            if (player.playbackState == Player.STATE_READY && player.playWhenReady) {
                FavoriteOfflineManager.resumeAfterPlaybackStable(this@PlaybackService)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        EqualizerStore.loadPrefs(this)
        val prefs = getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE)
        audioSaver = prefs.getBoolean("audio_saver", true)
        autoRadio = AudioEnhancePrefs.isAutoRadio(this)

        val upstreamFactory = DefaultDataSource.Factory(this)
        val cacheFactory = CacheDataSource.Factory()
            .setCache(MediaDiskCache.get(this))
            .setUpstreamDataSourceFactory(upstreamFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        val dsFactory = ResolvingDataSource.Factory(cacheFactory, resolver)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                8_000,
                12_000,
                750,
                1_500
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(
                DefaultMediaSourceFactory(dsFactory).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(1))
            )
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        player.skipSilenceEnabled = AudioEnhancePrefs.isSkipSilence(this)
        EqualizerStore.attachToSession(this, player.audioSessionId)

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                EqualizerStore.attachToSession(this@PlaybackService, audioSessionId)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                favDownloadResumeJob?.cancel()
                FavoriteOfflineManager.pauseForPlayback(this@PlaybackService)
                schedulePrefetchUpcoming()
                checkAndTriggerAutoRadio(player)
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                if (repeatMode == Player.REPEAT_MODE_OFF) {
                    checkAndTriggerAutoRadio(player)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        favDownloadResumeJob?.cancel()
                        FavoriteOfflineManager.pauseForPlayback(this@PlaybackService)
                    }
                    Player.STATE_READY -> {
                        recordCurrentTrackToHistory(player)
                        schedulePrefetchUpcoming()
                        checkAndTriggerAutoRadio(player)
                        if (player.playWhenReady) {
                            scheduleFavoriteDownloadAfterStableReady(player)
                        }
                    }
                    Player.STATE_IDLE, Player.STATE_ENDED -> {
                        favDownloadResumeJob?.cancel()
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying && player.playbackState == Player.STATE_READY) {
                    recordCurrentTrackToHistory(player)
                    scheduleFavoriteDownloadAfterStableReady(player)
                } else if (!isPlaying && player.playbackState == Player.STATE_BUFFERING) {
                    favDownloadResumeJob?.cancel()
                    FavoriteOfflineManager.pauseForPlayback(this@PlaybackService)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (player.hasNextMediaItem()) { player.seekToNextMediaItem(); player.prepare() }
            }
        })
        exo = player
        session = MediaSession.Builder(this, player).setCallback(Callback()).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = exo
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        favDownloadResumeJob?.cancel()
        prefetchJob?.cancel()
        autoRadioJob?.cancel()
        serviceScope.cancel()
        EqualizerStore.release()
        session?.release()
        exo?.release()
        MediaDiskCache.release()
        exo = null; session = null
        super.onDestroy()
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession, controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_SET_QUEUE, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_MODE, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_QUALITY, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_AUDIO_SAVER, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_EQ, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_AUDIO_ENHANCE, Bundle.EMPTY))
                .add(SessionCommand(CMD_SET_AUTO_RADIO, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(cmds).build()
        }

        override fun onCustomCommand(
            session: MediaSession, controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand, args: Bundle
        ): ListenableFuture<SessionResult> {
            val p = exo ?: return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_UNKNOWN))
            when (customCommand.customAction) {
                CMD_SET_QUEUE -> {
                    val urls = args.getStringArrayList("urls").orEmpty()
                    val titles = args.getStringArrayList("titles").orEmpty()
                    val artists = args.getStringArrayList("artists").orEmpty()
                    val thumbs = args.getStringArrayList("thumbs").orEmpty()
                    if (urls.isEmpty()) return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_BAD_VALUE))
                    audioOnly = !args.getBoolean("video")
                    if (args.containsKey("quality")) {
                        maxQuality = args.getInt("quality", 720)
                    }
                    if (args.containsKey("audioSaver")) {
                        audioSaver = args.getBoolean("audioSaver", true)
                    }
                    lastAutoRadioSeedUrl = null
                    lastRecordedHistoryUrl = null
                    val startIdx = args.getInt("start", 0)
                    val items = urls.indices.map { i ->
                        MediaItem.Builder()
                            .setUri(ytUri(urls[i]))
                            .setMediaId(urls[i])
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(titles.getOrNull(i))
                                    .setArtist(artists.getOrNull(i))
                                    .setArtworkUri(thumbs.getOrNull(i)?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) })
                                    .build()
                            ).build()
                    }
                    p.setMediaItems(items, startIdx, 0L)
                    p.prepare(); p.playWhenReady = true
                    schedulePrefetchUpcoming()
                    checkAndTriggerAutoRadio(p)
                }
                CMD_SET_MODE -> {
                    audioOnly = !args.getBoolean("video")
                    if (args.containsKey("quality")) {
                        maxQuality = args.getInt("quality", 720)
                    }
                    if (args.containsKey("audioSaver")) {
                        audioSaver = args.getBoolean("audioSaver", true)
                    }
                    val n = p.mediaItemCount
                    if (n > 0) {
                        val items = (0 until n).map { p.getMediaItemAt(it) }
                        p.setMediaItems(items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                        schedulePrefetchUpcoming()
                    }
                }
                CMD_SET_QUALITY -> {
                    maxQuality = args.getInt("quality", 720)
                    if (!audioOnly && p.mediaItemCount > 0) {
                        val items = (0 until p.mediaItemCount).map { p.getMediaItemAt(it) }
                        p.setMediaItems(items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                        schedulePrefetchUpcoming()
                    }
                }
                CMD_SET_AUDIO_SAVER -> {
                    audioSaver = args.getBoolean("audioSaver", true)
                    getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE)
                        .edit().putBoolean("audio_saver", audioSaver).apply()
                    if (audioOnly && p.mediaItemCount > 0) {
                        val items = (0 until p.mediaItemCount).map { p.getMediaItemAt(it) }
                        p.setMediaItems(items, p.currentMediaItemIndex, p.currentPosition)
                        p.prepare()
                        schedulePrefetchUpcoming()
                    }
                }
                CMD_SET_EQ -> {
                    val enabled = args.getBoolean("enabled", false)
                    val preset = args.getString("preset", "Normal") ?: "Normal"
                    val bass = args.getInt("bass", 0)
                    val levels = args.getIntegerArrayList("levels")?.toList() ?: EqualizerStore.state.value.bandLevelsMb
                    EqualizerStore.state.value = EqualizerStore.state.value.copy(
                        enabled = enabled,
                        presetName = preset,
                        bandLevelsMb = levels,
                        bassStrength = bass
                    )
                    EqualizerStore.attachToSession(this@PlaybackService, p.audioSessionId)
                }
                CMD_SET_AUDIO_ENHANCE -> {
                    val skipSilence = args.getBoolean("skipSilence", AudioEnhancePrefs.isSkipSilence(this@PlaybackService))
                    val normalize = args.getBoolean("loudnessNormalize", AudioEnhancePrefs.isLoudnessNormalize(this@PlaybackService))
                    AudioEnhancePrefs.setSkipSilence(this@PlaybackService, skipSilence)
                    AudioEnhancePrefs.setLoudnessNormalize(this@PlaybackService, normalize)
                    p.skipSilenceEnabled = skipSilence
                    EqualizerStore.attachToSession(this@PlaybackService, p.audioSessionId)
                    EqualizerStore.applyCurrentState(this@PlaybackService)
                }
                CMD_SET_AUTO_RADIO -> {
                    autoRadio = args.getBoolean("autoRadio", true)
                    AudioEnhancePrefs.setAutoRadio(this@PlaybackService, autoRadio)
                    if (autoRadio) {
                        lastAutoRadioSeedUrl = null
                        checkAndTriggerAutoRadio(p)
                    }
                }
                else -> return super.onCustomCommand(session, controller, customCommand, args)
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }
}
