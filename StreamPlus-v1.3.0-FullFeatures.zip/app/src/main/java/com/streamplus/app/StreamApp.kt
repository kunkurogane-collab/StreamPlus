package com.streamplus.app

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class StreamApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FavoriteOfflineManager.init(this)
        HistoryStore.init(this)
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                Engine.ensureInit(this@StreamApp)
                Engine.autoUpdate(this@StreamApp)
            }
        }
    }
}
