package com.streamplus.app

import android.content.Context
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class PlayHistoryItem(
    val track: Track,
    val playCount: Int,
    val lastPlayedMs: Long
)

data class LyricLine(
    val timeMs: Long,
    val text: String
)

object HistoryStore {
    private const val PREF = "streamplus_history"
    private const val KEY = "history_json"
    private const val MAX_ITEMS = 60

    val itemsFlow = MutableStateFlow<List<PlayHistoryItem>>(emptyList())

    fun init(ctx: Context) {
        itemsFlow.value = load(ctx)
    }

    fun load(ctx: Context): List<PlayHistoryItem> {
        val raw = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                val url = obj.optString("url")
                if (url.isBlank()) return@mapNotNull null
                PlayHistoryItem(
                    track = Track(
                        url = url,
                        title = obj.optString("title"),
                        artist = obj.optString("artist"),
                        durationSec = obj.optLong("durationSec", 0L),
                        thumb = obj.optString("thumb").takeIf { it.isNotBlank() }
                    ),
                    playCount = obj.optInt("playCount", 1).coerceAtLeast(1),
                    lastPlayedMs = obj.optLong("lastPlayedMs", 0L)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(ctx: Context, list: List<PlayHistoryItem>) {
        val trimmed = list.take(MAX_ITEMS)
        itemsFlow.value = trimmed
        val arr = JSONArray()
        trimmed.forEach { item ->
            arr.put(JSONObject().apply {
                put("url", item.track.url)
                put("title", item.track.title)
                put("artist", item.track.artist)
                put("durationSec", item.track.durationSec)
                put("thumb", item.track.thumb.orEmpty())
                put("playCount", item.playCount)
                put("lastPlayedMs", item.lastPlayedMs)
            })
        }
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun recordPlay(ctx: Context, track: Track) {
        if (track.url.isBlank()) return
        val current = if (itemsFlow.value.isEmpty()) load(ctx) else itemsFlow.value
        val existing = current.firstOrNull { it.track.url == track.url }
        val updatedItem = PlayHistoryItem(
            track = track.copy(
                title = track.title.ifBlank { existing?.track?.title.orEmpty() },
                artist = track.artist.ifBlank { existing?.track?.artist.orEmpty() },
                thumb = track.thumb ?: existing?.track?.thumb,
                durationSec = if (track.durationSec > 0L) track.durationSec else (existing?.track?.durationSec ?: 0L)
            ),
            playCount = (existing?.playCount ?: 0) + 1,
            lastPlayedMs = System.currentTimeMillis()
        )
        val merged = listOf(updatedItem) + current.filterNot { it.track.url == track.url }
        save(ctx, merged)
    }

    fun getRecentlyPlayed(list: List<PlayHistoryItem>, limit: Int = 10): List<Track> =
        list.sortedByDescending { it.lastPlayedMs }.take(limit).map { it.track }

    fun getMostPlayed(list: List<PlayHistoryItem>, limit: Int = 10): List<PlayHistoryItem> =
        list.filter { it.playCount >= 2 }
            .sortedWith(compareByDescending<PlayHistoryItem> { it.playCount }.thenByDescending { it.lastPlayedMs })
            .take(limit)

    fun clear(ctx: Context) = save(ctx, emptyList())
}

object AudioEnhancePrefs {
    private const val PREF = "streamplus_prefs"
    private const val KEY_SKIP_SILENCE = "skip_silence"
    private const val KEY_NORMALIZE = "loudness_normalize"
    private const val KEY_AUTO_RADIO = "auto_radio"

    fun isSkipSilence(ctx: Context): Boolean =
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getBoolean(KEY_SKIP_SILENCE, false)

    fun setSkipSilence(ctx: Context, enabled: Boolean) {
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_SKIP_SILENCE, enabled).apply()
    }

    fun isLoudnessNormalize(ctx: Context): Boolean =
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getBoolean(KEY_NORMALIZE, true)

    fun setLoudnessNormalize(ctx: Context, enabled: Boolean) {
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_NORMALIZE, enabled).apply()
    }

    fun isAutoRadio(ctx: Context): Boolean =
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_RADIO, true)

    fun setAutoRadio(ctx: Context, enabled: Boolean) {
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTO_RADIO, enabled).apply()
    }
}

object LyricsManager {
    private val cache = ConcurrentHashMap<String, List<LyricLine>>()
    private val notFound = ConcurrentHashMap<String, Boolean>()

    fun cleanTitle(raw: String): String =
        raw.replace(Regex("\\((Official|Lyric|Audio|Music|Video|MV|Live|Remaster|HD|4K)[^)]*\\)", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\[(Official|Lyric|Audio|Music|Video|MV|Live|Remaster|HD|4K)[^]]*]", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s+"), " ")
            .trim()

    suspend fun fetchLyrics(title: String, artist: String): List<LyricLine> = withContext(Dispatchers.IO) {
        val cleaned = cleanTitle(title)
        if (cleaned.isBlank()) return@withContext emptyList()
        val cacheKey = "${cleaned.lowercase()}|${artist.lowercase().trim()}"
        cache[cacheKey]?.let { return@withContext it }
        if (notFound.containsKey(cacheKey)) return@withContext emptyList()

        runCatching {
            val q = URLEncoder.encode(
                if (artist.isNotBlank() && !cleaned.contains(artist, ignoreCase = true)) "$cleaned $artist" else cleaned,
                "UTF-8"
            )
            val conn = (URL("https://lrclib.net/api/search?q=$q").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 8_000
                setRequestProperty("User-Agent", "StreamPlus/1.3.0 (Android)")
            }
            if (conn.responseCode != 200) {
                conn.disconnect()
                return@withContext emptyList()
            }
            val body = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
            conn.disconnect()

            val arr = JSONArray(body)
            var bestLines: List<LyricLine> = emptyList()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val synced = obj.optString("syncedLyrics")
                if (synced.isNotBlank() && synced != "null") {
                    val parsed = parseLrc(synced)
                    if (parsed.isNotEmpty()) {
                        bestLines = parsed
                        break
                    }
                }
                if (bestLines.isEmpty()) {
                    val plain = obj.optString("plainLyrics")
                    if (plain.isNotBlank() && plain != "null") {
                        bestLines = plain.lines().map { it.trim() }.filter { it.isNotEmpty() }
                            .map { LyricLine(-1L, it) }
                    }
                }
            }
            if (bestLines.isNotEmpty()) cache[cacheKey] = bestLines else notFound[cacheKey] = true
            bestLines
        }.getOrDefault(emptyList())
    }

    fun parseLrc(lrc: String): List<LyricLine> {
        val regex = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?](.*)")
        val result = mutableListOf<LyricLine>()
        for (rawLine in lrc.lines()) {
            val match = regex.find(rawLine.trim()) ?: continue
            val min = match.groupValues[1].toLongOrNull() ?: continue
            val sec = match.groupValues[2].toLongOrNull() ?: continue
            val fracStr = match.groupValues[3]
            val msPart = when (fracStr.length) {
                0 -> 0L
                1 -> (fracStr.toLongOrNull() ?: 0L) * 100L
                2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                else -> fracStr.take(3).toLongOrNull() ?: 0L
            }
            val text = match.groupValues[4].trim()
            if (text.isNotEmpty()) result.add(LyricLine(min * 60_000L + sec * 1000L + msPart, text))
        }
        return result.sortedBy { it.timeMs }
    }
}

object BackupManager {
    fun exportJson(ctx: Context, favorites: List<Track>): String {
        val eq = EqualizerStore.state.value
        val prefs = ctx.applicationContext.getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE)
        val history = HistoryStore.load(ctx)

        return JSONObject().apply {
            put("app", "StreamPlus")
            put("version", 1)
            put("exportedAt", System.currentTimeMillis())
            put("favorites", JSONArray().apply {
                favorites.forEach { t ->
                    put(JSONObject().apply {
                        put("url", t.url); put("title", t.title); put("artist", t.artist)
                        put("durationSec", t.durationSec); put("thumb", t.thumb.orEmpty())
                    })
                }
            })
            put("history", JSONArray().apply {
                history.forEach { h ->
                    put(JSONObject().apply {
                        put("url", h.track.url); put("title", h.track.title); put("artist", h.track.artist)
                        put("durationSec", h.track.durationSec); put("thumb", h.track.thumb.orEmpty())
                        put("playCount", h.playCount); put("lastPlayedMs", h.lastPlayedMs)
                    })
                }
            })
            put("equalizer", JSONObject().apply {
                put("enabled", eq.enabled); put("presetName", eq.presetName)
                put("bassStrength", eq.bassStrength); put("bandLevelsMb", JSONArray(eq.bandLevelsMb))
            })
            put("settings", JSONObject().apply {
                put("audioSaver", prefs.getBoolean("audio_saver", true))
                put("autoDownloadMode", FavoriteOfflineManager.modeFlow.value.value)
                put("skipSilence", AudioEnhancePrefs.isSkipSilence(ctx))
                put("loudnessNormalize", AudioEnhancePrefs.isLoudnessNormalize(ctx))
                put("autoRadio", AudioEnhancePrefs.isAutoRadio(ctx))
            })
        }.toString(2)
    }

    data class RestoreResult(
        val favorites: List<Track>,
        val historyCount: Int,
        val eqState: EqState,
        val audioSaver: Boolean,
        val autoDownloadMode: AutoDownloadMode,
        val skipSilence: Boolean,
        val loudnessNormalize: Boolean,
        val autoRadio: Boolean
    )

    fun importJson(ctx: Context, rawJson: String): RestoreResult {
        val root = JSONObject(rawJson)
        val favArr = root.optJSONArray("favorites") ?: JSONArray()
        val restoredFavs = (0 until favArr.length()).mapNotNull { i ->
            val obj = favArr.optJSONObject(i) ?: return@mapNotNull null
            val url = obj.optString("url")
            if (url.isBlank()) return@mapNotNull null
            Track(url, obj.optString("title"), obj.optString("artist"), obj.optLong("durationSec", 0L), obj.optString("thumb").takeIf { it.isNotBlank() })
        }
        val histArr = root.optJSONArray("history") ?: JSONArray()
        val restoredHist = (0 until histArr.length()).mapNotNull { i ->
            val obj = histArr.optJSONObject(i) ?: return@mapNotNull null
            val url = obj.optString("url")
            if (url.isBlank()) return@mapNotNull null
            PlayHistoryItem(
                Track(url, obj.optString("title"), obj.optString("artist"), obj.optLong("durationSec", 0L), obj.optString("thumb").takeIf { it.isNotBlank() }),
                obj.optInt("playCount", 1).coerceAtLeast(1),
                obj.optLong("lastPlayedMs", System.currentTimeMillis())
            )
        }
        if (restoredHist.isNotEmpty()) HistoryStore.save(ctx, restoredHist)

        val eqObj = root.optJSONObject("equalizer")
        val currentEq = EqualizerStore.state.value
        val restoredEq = if (eqObj != null) {
            val lvArr = eqObj.optJSONArray("bandLevelsMb")
            val levels = if (lvArr != null && lvArr.length() > 0) (0 until lvArr.length()).map { lvArr.optInt(it, 0) } else currentEq.bandLevelsMb
            currentEq.copy(
                enabled = eqObj.optBoolean("enabled", currentEq.enabled),
                presetName = eqObj.optString("presetName", currentEq.presetName),
                bassStrength = eqObj.optInt("bassStrength", currentEq.bassStrength).coerceIn(0, 1000),
                bandLevelsMb = levels
            )
        } else currentEq

        val setObj = root.optJSONObject("settings")
        val prefs = ctx.applicationContext.getSharedPreferences("streamplus_prefs", Context.MODE_PRIVATE)
        val audioSaver = setObj?.optBoolean("audioSaver", prefs.getBoolean("audio_saver", true)) ?: prefs.getBoolean("audio_saver", true)
        val autoMode = AutoDownloadMode.fromValue(setObj?.optInt("autoDownloadMode", FavoriteOfflineManager.modeFlow.value.value) ?: FavoriteOfflineManager.modeFlow.value.value)
        val skipSilence = setObj?.optBoolean("skipSilence", AudioEnhancePrefs.isSkipSilence(ctx)) ?: AudioEnhancePrefs.isSkipSilence(ctx)
        val loudnessNorm = setObj?.optBoolean("loudnessNormalize", AudioEnhancePrefs.isLoudnessNormalize(ctx)) ?: AudioEnhancePrefs.isLoudnessNormalize(ctx)
        val autoRadio = setObj?.optBoolean("autoRadio", AudioEnhancePrefs.isAutoRadio(ctx)) ?: AudioEnhancePrefs.isAutoRadio(ctx)

        prefs.edit().putBoolean("audio_saver", audioSaver).apply()
        FavoriteOfflineManager.setMode(ctx, autoMode)
        AudioEnhancePrefs.setSkipSilence(ctx, skipSilence)
        AudioEnhancePrefs.setLoudnessNormalize(ctx, loudnessNorm)
        AudioEnhancePrefs.setAutoRadio(ctx, autoRadio)

        return RestoreResult(restoredFavs, restoredHist.size, restoredEq, audioSaver, autoMode, skipSilence, loudnessNorm, autoRadio)
    }

    fun writeToUri(ctx: Context, uri: Uri, content: String): Boolean = runCatching {
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) } != null
    }.getOrDefault(false)

    fun readFromUri(ctx: Context, uri: Uri): String? = runCatching {
        ctx.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
    }.getOrNull()
}
