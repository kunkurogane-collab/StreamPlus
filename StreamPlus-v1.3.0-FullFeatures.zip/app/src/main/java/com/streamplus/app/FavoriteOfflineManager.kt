package com.streamplus.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.ArrayDeque
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class AutoDownloadMode(val value: Int, val label: String) {
    OFF(0, "Off"),
    WIFI_ONLY(1, "Wi-Fi Saja"),
    ALL_NETWORKS(2, "Semua Jaringan");

    companion object {
        fun fromValue(value: Int): AutoDownloadMode =
            entries.firstOrNull { it.value == value } ?: WIFI_ONLY
    }
}

object FavoriteOfflineManager {
    private const val PREF = "streamplus_prefs"
    private const val KEY_MODE = "fav_auto_download_mode"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val queue = ArrayDeque<Track>()
    private val queueMutex = Mutex()
    private var workerJob: Job? = null

    @Volatile
    private var pausedByPlayer = false

    val modeFlow = MutableStateFlow(AutoDownloadMode.WIFI_ONLY)
    val downloadedUrls = MutableStateFlow<Set<String>>(emptySet())
    val activeDownloadUrl = MutableStateFlow<String?>(null)

    private fun offlineDir(ctx: Context): File =
        File(ctx.applicationContext.filesDir, "offline_favorites").apply { if (!exists()) mkdirs() }

    private fun trackKey(url: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(url.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }.take(32)
    }

    fun init(ctx: Context) {
        val appCtx = ctx.applicationContext
        val saved = appCtx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getInt(KEY_MODE, AutoDownloadMode.WIFI_ONLY.value)
        modeFlow.value = AutoDownloadMode.fromValue(saved)
        refreshDownloadedSet(appCtx)
    }

    fun setMode(ctx: Context, newMode: AutoDownloadMode) {
        val appCtx = ctx.applicationContext
        modeFlow.value = newMode
        appCtx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putInt(KEY_MODE, newMode.value).apply()

        if (newMode == AutoDownloadMode.OFF) {
            workerJob?.cancel()
            activeDownloadUrl.value = null
        } else {
            triggerNextIfReady(appCtx)
        }
    }

    fun isNetworkAllowed(ctx: Context): Boolean {
        val mode = modeFlow.value
        if (mode == AutoDownloadMode.OFF) return false

        val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false

        return when (mode) {
            AutoDownloadMode.OFF -> false
            AutoDownloadMode.WIFI_ONLY -> caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
            AutoDownloadMode.ALL_NETWORKS -> true
        }
    }

    fun getLocalFile(ctx: Context, url: String): File? {
        val file = File(offlineDir(ctx), "${trackKey(url)}.audio")
        return if (file.exists() && file.length() > 0L) file else null
    }

    fun isDownloaded(ctx: Context, url: String): Boolean = getLocalFile(ctx, url) != null

    fun refreshDownloadedSet(ctx: Context, favorites: List<Track>? = null) {
        val dir = offlineDir(ctx)
        val existingKeys = dir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".audio") && it.length() > 0L }
            ?.map { it.nameWithoutExtension }
            ?.toSet()
            .orEmpty()

        if (favorites != null) {
            downloadedUrls.value = favorites
                .filter { existingKeys.contains(trackKey(it.url)) }
                .map { it.url }
                .toSet()
        }
    }

    /**
     * Dipanggil saat user menambah lagu favorit atau saat daftar favorit dimuat.
     * Menggunakan antrean sequential (1 per satu).
     */
    fun enqueueFavorites(ctx: Context, tracks: List<Track>) {
        val appCtx = ctx.applicationContext
        refreshDownloadedSet(appCtx, tracks)
        if (modeFlow.value == AutoDownloadMode.OFF) return

        scope.launch {
            queueMutex.withLock {
                for (t in tracks) {
                    if (!isDownloaded(appCtx, t.url) && queue.none { it.url == t.url }) {
                        queue.addLast(t)
                    }
                }
            }
            triggerNextIfReady(appCtx)
        }
    }

    /**
     * Hapus file offline jika lagu dihapus dari favorit.
     */
    fun removeFavoriteOffline(ctx: Context, url: String) {
        val appCtx = ctx.applicationContext
        scope.launch {
            queueMutex.withLock {
                queue.removeAll { it.url == url }
            }
            if (activeDownloadUrl.value == url) {
                workerJob?.cancel()
                activeDownloadUrl.value = null
            }
            val key = trackKey(url)
            File(offlineDir(appCtx), "$key.audio").delete()
            File(offlineDir(appCtx), "$key.tmp").delete()
            downloadedUrls.value = downloadedUrls.value - url
            triggerNextIfReady(appCtx)
        }
    }

    /**
     * Aturan Pengaman 1: Jeda otomatis saat player utama buffering atau ganti lagu (Next/Prev).
     */
    fun pauseForPlayback(ctx: Context) {
        pausedByPlayer = true
        workerJob?.cancel()
        activeDownloadUrl.value = null
    }

    /**
     * Aturan Pengaman 1: Lanjutkan unduhan setelah player utama berstatus STATE_READY stabil 4 detik.
     */
    fun resumeAfterPlaybackStable(ctx: Context) {
        pausedByPlayer = false
        triggerNextIfReady(ctx.applicationContext)
    }

    private fun triggerNextIfReady(appCtx: Context) {
        if (pausedByPlayer) return
        if (!isNetworkAllowed(appCtx)) return
        if (workerJob?.isActive == true) return

        workerJob = scope.launch {
            while (isActive && !pausedByPlayer && isNetworkAllowed(appCtx)) {
                val nextTrack = queueMutex.withLock { queue.peekFirst() } ?: break

                if (isDownloaded(appCtx, nextTrack.url)) {
                    queueMutex.withLock { queue.pollFirst() }
                    downloadedUrls.value = downloadedUrls.value + nextTrack.url
                    continue
                }

                activeDownloadUrl.value = nextTrack.url
                val ok = downloadSingleEcoAudio(appCtx, nextTrack)
                activeDownloadUrl.value = null

                if (ok) {
                    queueMutex.withLock { queue.pollFirst() }
                    downloadedUrls.value = downloadedUrls.value + nextTrack.url
                } else {
                    // Jika dijeda di tengah jalan karena user menekan Next atau sinyal putus, tahan posisi antrean
                    break
                }
            }
        }
    }

    /**
     * Aturan Pengaman 2: Unduh 1 lagu per satu waktu menggunakan format hemat kuota (~48k).
     */
    private suspend fun downloadSingleEcoAudio(appCtx: Context, track: Track): Boolean {
        val key = trackKey(track.url)
        val dir = offlineDir(appCtx)
        val targetFile = File(dir, "$key.audio")
        val tempFile = File(dir, "$key.tmp")

        return try {
            // Selalu gunakan audioOnly = true dan audioSaver = true (~48k) agar hemat kuota
            val directUrl = Engine.resolveSilent(
                ctx = appCtx,
                url = track.url,
                audioOnly = true,
                maxHeight = 720,
                audioSaver = true
            )

            val existingBytes = if (tempFile.exists()) tempFile.length() else 0L
            val conn = (URL(directUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 12_000
                readTimeout = 20_000
                setRequestProperty("User-Agent", "Mozilla/5.0")
                if (existingBytes > 0L) {
                    setRequestProperty("Range", "bytes=$existingBytes-")
                }
            }

            conn.connect()
            val code = conn.responseCode
            if (code !in 200..299 && code != HttpURLConnection.HTTP_PARTIAL) {
                if (code == 416) tempFile.delete()
                conn.disconnect()
                return false
            }

            val append = (code == HttpURLConnection.HTTP_PARTIAL && existingBytes > 0L)
            conn.inputStream.use { input ->
                FileOutputStream(tempFile, append).use { output ->
                    val buf = ByteArray(8 * 1024)
                    while (true) {
                        if (!currentCoroutineContext().isActive || pausedByPlayer || !isNetworkAllowed(appCtx)) {
                            conn.disconnect()
                            return false
                        }
                        val read = input.read(buf)
                        if (read == -1) break
                        output.write(buf, 0, read)
                    }
                }
            }
            conn.disconnect()

            if (tempFile.exists() && tempFile.length() > 0L) {
                if (targetFile.exists()) targetFile.delete()
                tempFile.renameTo(targetFile)
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }
}
