package com.streamplus.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AutoDownloadMode(val prefVal: Int, val label: String) {
    OFF(0, "Mati"),
    WIFI_ONLY(1, "Wi-Fi Saja"),
    ALL_NETWORKS(2, "Semua Jaringan");

    companion object {
        fun fromPref(v: Int): AutoDownloadMode =
            entries.firstOrNull { it.prefVal == v } ?: OFF
    }
}

object FavoriteDownloader {
    private const val PREF = "streamplus_fav_dl"
    private const val KEY_MODE = "auto_dl_mode"
    private const val DIR_NAME = "offline_favorites"
    /** Batas total penyimpanan unduhan otomatis; lewat dari ini unduhan latar berhenti. */
    private const val MAX_STORAGE_BYTES = 1024L * 1024L * 1024L
    private const val KEY_DOWNLOADED_TRACKS = "manual_downloaded_tracks_v1"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var workerJob: Job? = null
    private var cooldownJob: Job? = null

    @Volatile private var playbackBusy: Boolean = false
    @Volatile private var pendingFavorites: List<Track> = emptyList()

    // Default MATI: app ini fokus streaming; unduhan otomatis harus dipilih pengguna.
    val mode = MutableStateFlow(AutoDownloadMode.OFF)
    val downloadedUrls = MutableStateFlow<Set<String>>(emptySet())
    val downloadingUrl = MutableStateFlow<String?>(null)
    val totalStorageBytes = MutableStateFlow(0L)
    val downloadedTracks = MutableStateFlow<List<Track>>(emptyList())

    fun init(ctx: Context) {
        val appCtx = ctx.applicationContext
        val p = appCtx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        mode.value = AutoDownloadMode.fromPref(p.getInt(KEY_MODE, AutoDownloadMode.OFF.prefVal))
        loadDownloadedTracks(appCtx)
        refreshIndex(appCtx)
    }

    fun setMode(ctx: Context, newMode: AutoDownloadMode) {
        val appCtx = ctx.applicationContext
        mode.value = newMode
        appCtx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putInt(KEY_MODE, newMode.prefVal).apply()
        if (newMode == AutoDownloadMode.OFF) {
            workerJob?.cancel()
            downloadingUrl.value = null
        } else {
            syncFavorites(appCtx, pendingFavorites)
        }
    }

    /** Dipanggil PlaybackService agar download latar belakang berhenti sementara saat lagu utama sedang buffering/loading. */
    fun setPlaybackBusy(ctx: Context, busy: Boolean) {
        val appCtx = ctx.applicationContext
        cooldownJob?.cancel()
        if (busy) {
            playbackBusy = true
        } else {
            // Tunggu 3.5 detik setelah lagu utama siap agar tidak berebut CPU/bandwidth di awal pemutaran
            cooldownJob = scope.launch {
                delay(3500L)
                playbackBusy = false
                triggerWorkerIfNeeded(appCtx)
            }
        }
    }

    private fun folder(ctx: Context): File =
        File(ctx.applicationContext.filesDir, DIR_NAME).apply { if (!exists()) mkdirs() }

    private fun hashUrl(url: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(url.toByteArray()).joinToString("") { "%02x".format(it) }.take(32)
    }

    private fun targetFile(ctx: Context, url: String): File =
        File(folder(ctx), "${hashUrl(url)}.audio")

    fun getOfflineFile(ctx: Context, url: String): File? {
        if (url.isBlank()) return null
        val f = targetFile(ctx, url)
        return if (f.exists() && f.length() > 1024L) f else null
    }

    /** Unduh satu lagu secara langsung (dipakai saat ekspor ke folder Musik HP jika belum tersimpan offline). */
    fun ensureDownloadedNow(ctx: Context, url: String): File? {
        getOfflineFile(ctx, url)?.let { return it }
        val ok = downloadSingleTrack(ctx.applicationContext, url, ignorePolicy = true)
        refreshIndex(ctx.applicationContext)
        return if (ok) getOfflineFile(ctx, url) else null
    }

    private fun loadDownloadedTracks(ctx: Context) {
        val prefs = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        downloadedTracks.value = runCatching {
            val raw = prefs.getString(KEY_DOWNLOADED_TRACKS, null) ?: return@runCatching emptyList()
            val arr = org.json.JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                Track(
                    url = o.optString("url"),
                    title = o.optString("title", "Lagu"),
                    artist = o.optString("artist", ""),
                    durationSec = o.optLong("duration", 0L),
                    thumb = o.optString("thumb").takeIf { it.isNotBlank() },
                    viewCount = if (o.has("views") && !o.isNull("views")) o.optLong("views") else null
                ).takeIf { it.url.isNotBlank() && getOfflineFile(ctx, it.url) != null }
            }
        }.getOrDefault(emptyList())
        persistDownloadedTracks(ctx)
    }

    private fun persistDownloadedTracks(ctx: Context) {
        val arr = org.json.JSONArray()
        downloadedTracks.value.forEach { track ->
            arr.put(org.json.JSONObject().apply {
                put("url", track.url)
                put("title", track.title)
                put("artist", track.artist)
                put("duration", track.durationSec)
                put("thumb", track.thumb ?: "")
                if (track.viewCount != null) put("views", track.viewCount)
            })
        }
        ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_DOWNLOADED_TRACKS, arr.toString()).apply()
    }

    /** Unduh manual lagu yang dipilih ke penyimpanan privat aplikasi agar bisa diputar offline. */
    fun downloadTrackNow(ctx: Context, track: Track, audioSaver: Boolean): Boolean {
        val appCtx = ctx.applicationContext
        if (track.url.isBlank()) return false
        if (getOfflineFile(appCtx, track.url) == null) {
            downloadingUrl.value = track.url
            val ok = downloadSingleTrack(appCtx, track.url, ignorePolicy = true, requestedAudioSaver = audioSaver)
            downloadingUrl.value = null
            if (!ok) return false
        }
        val existing = downloadedTracks.value.filterNot { it.url == track.url }
        downloadedTracks.value = listOf(track) + existing
        persistDownloadedTracks(appCtx)
        refreshIndex(appCtx)
        return getOfflineFile(appCtx, track.url) != null
    }

    fun deleteDownloadedTrack(ctx: Context, track: Track) {
        val appCtx = ctx.applicationContext
        deleteOfflineForUrl(appCtx, track.url)
        downloadedTracks.value = downloadedTracks.value.filterNot { it.url == track.url }
        persistDownloadedTracks(appCtx)
    }

    fun refreshIndex(ctx: Context) {
        val dir = folder(ctx)
        val files = dir.listFiles().orEmpty()
        var bytes = 0L
        for (f in files) {
            if (f.name.endsWith(".audio")) bytes += f.length()
        }
        totalStorageBytes.value = bytes
        if (pendingFavorites.isNotEmpty()) {
            downloadedUrls.value = pendingFavorites
                .filter { getOfflineFile(ctx, it.url) != null }
                .map { it.url }
                .toSet()
        }
    }

    fun deleteOfflineForUrl(ctx: Context, url: String) {
        runCatching {
            val f = targetFile(ctx, url)
            if (f.exists()) f.delete()
            val tmp = File(folder(ctx), "${hashUrl(url)}.tmp")
            if (tmp.exists()) tmp.delete()
        }
        downloadedUrls.value = downloadedUrls.value - url
        refreshIndex(ctx)
    }

    fun clearAllOffline(ctx: Context) {
        workerJob?.cancel()
        downloadingUrl.value = null
        runCatching {
            folder(ctx).listFiles().orEmpty().forEach { it.delete() }
        }
        downloadedUrls.value = emptySet()
        downloadedTracks.value = emptyList()
        persistDownloadedTracks(ctx)
        totalStorageBytes.value = 0L
    }

    fun syncFavorites(ctx: Context, favorites: List<Track>) {
        val appCtx = ctx.applicationContext
        pendingFavorites = favorites
        refreshIndex(appCtx)
        triggerWorkerIfNeeded(appCtx)
    }

    private fun isNetworkAllowed(ctx: Context, currentMode: AutoDownloadMode): Boolean {
        if (currentMode == AutoDownloadMode.OFF) return false
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        if (!hasInternet) return false
        return when (currentMode) {
            AutoDownloadMode.OFF -> false
            AutoDownloadMode.WIFI_ONLY ->
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            AutoDownloadMode.ALL_NETWORKS -> true
        }
    }

    @Synchronized
    private fun triggerWorkerIfNeeded(ctx: Context) {
        if (mode.value == AutoDownloadMode.OFF) return
        if (workerJob?.isActive == true) return
        if (totalStorageBytes.value >= MAX_STORAGE_BYTES) return
        val hasMissing = pendingFavorites.any { getOfflineFile(ctx, it.url) == null }
        if (!hasMissing) return

        workerJob = scope.launch {
            while (isActive) {
                val currentMode = mode.value
                if (currentMode == AutoDownloadMode.OFF) break

                // Tunggu jika pemutar utama sedang loading/buffering atau jaringan belum sesuai
                while (isActive && (playbackBusy || !isNetworkAllowed(ctx, mode.value))) {
                    delay(1500L)
                }
                if (!isActive || mode.value == AutoDownloadMode.OFF) break
                if (totalStorageBytes.value >= MAX_STORAGE_BYTES) break

                val nextTrack = pendingFavorites.firstOrNull { getOfflineFile(ctx, it.url) == null }
                    ?: break

                downloadingUrl.value = nextTrack.url
                val ok = downloadSingleTrack(ctx, nextTrack.url, shouldContinue = { isActive })
                downloadingUrl.value = null
                refreshIndex(ctx)

                // Jika gagal (misal koneksi terputus), tunggu sebentar sebelum mencoba lagi
                delay(if (ok) 600L else 5000L)
            }
        }
    }

    private fun downloadSingleTrack(
        ctx: Context,
        trackUrl: String,
        ignorePolicy: Boolean = false,
        requestedAudioSaver: Boolean = true,
        shouldContinue: () -> Boolean = { true }
    ): Boolean {
        val outFile = targetFile(ctx, trackUrl)
        if (outFile.exists() && outFile.length() > 1024L) return true
        val tmpFile = File(folder(ctx), "${hashUrl(trackUrl)}.tmp")

        return runCatching {
            // Ikuti pilihan kualitas audio pengguna; unduhan otomatis favorit tetap memakai mode hemat kuota.
            val streamUrl = Engine.resolve(
                ctx = ctx,
                url = trackUrl,
                audioOnly = true,
                maxHeight = 720,
                audioSaver = requestedAudioSaver,
                silent = true
            )

            // Cek ulang sebelum mulai mengunduh byte audio
            if (!ignorePolicy && (playbackBusy || !isNetworkAllowed(ctx, mode.value))) return@runCatching false

            val conn = (URL(streamUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 20_000
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            conn.connect()
            if (conn.responseCode !in 200..299) {
                conn.disconnect()
                return@runCatching false
            }

            conn.inputStream.use { input ->
                FileOutputStream(tmpFile).use { output ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        if (!ignorePolicy && (mode.value == AutoDownloadMode.OFF || !isNetworkAllowed(ctx, mode.value))) {
                            tmpFile.delete()
                            return@runCatching false
                        }
                        // Jika lagu utama mulai buffering di tengah download, beri jeda agar bandwidth tidak terganggu
                        // Tunggu paling lama 60 dtk & berhenti bila pekerjaan dibatalkan (tidak menggantung selamanya)
                        var waited = 0L
                        while (!ignorePolicy && playbackBusy) {
                            if (!shouldContinue() || waited >= 60_000L) {
                                tmpFile.delete()
                                return@runCatching false
                            }
                            Thread.sleep(500L)
                            waited += 500L
                        }
                        if (!shouldContinue()) {
                            tmpFile.delete()
                            return@runCatching false
                        }
                        val read = input.read(buf)
                        if (read == -1) break
                        output.write(buf, 0, read)
                    }
                    output.flush()
                }
            }
            conn.disconnect()

            if (tmpFile.exists() && tmpFile.length() > 1024L) {
                if (outFile.exists()) outFile.delete()
                tmpFile.renameTo(outFile)
                true
            } else {
                tmpFile.delete()
                false
            }
        }.getOrElse {
            runCatching { if (tmpFile.exists()) tmpFile.delete() }
            false
        }
    }
}
